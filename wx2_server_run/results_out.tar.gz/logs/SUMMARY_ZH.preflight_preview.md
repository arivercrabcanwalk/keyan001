# WX-E 服务器实验汇总

写于 2026-11-13 09:38:25 JST。合成天气（σ0=1，κ=0.5，非 ERA5）。

## 三种子 G-b / G-c（pomo_v2）

- 种子 0：G-b=通过（J=4987.0079203568675，对 N1 ΔJ=-1.2623974718153022%，准时率 Δ=0.9057844932845005 pp；G_b_J=True G_b_ot=False）；G-c=未通过（KL=1.0515750236849715，动作差=0.037029720356467864，门槛 KL>0.01 且动作差≥5%）。
- 种子 1：尚无正式结果。
- 种子 2：尚无正式结果。

通过 0/1。官方 Test-A 解冻条件是至少 2/3 同时通过 G-b 和 G-c：不满足。

种子 0 是本机 2 worker、2 小时预算的正式结果（已随包附带）。种子 1、2 在本服务器上按预注册协议从零训练（完整 BC + 两轮 DAgger M=8 + 2 小时 POMO v2），没有从本机未完成的 DAgger r1 热启动，以保证可复现、与预注册一致。

## P3

文件不存在：`results_final/P3_ANALYSIS.md`。

## P4

文件不存在：`results_final/P4_ANALYSIS.md`。

## WX-H

尚未产出。

## 文件位置

- 闸门：`wx_e/GB_s*_pomo_v2.json`、`wx_e/GB_V2_TALLY.json`
- 评估：`wx_e/results/`
- 分析：`results_final/`
- 模型：`models/rl_s*_best_pomo_v2.npz`
- 打包：`results_out.tar.gz`
