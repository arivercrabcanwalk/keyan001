# Fresh-context handover pointer

The user has a downloadable file named:
Liu2026_CA-RL-TSALNS_详细任务交接书_20261101.md

Read that file first. Then read:
1. RESEARCH_EXECUTION_LEDGER_V5.md
2. RESEARCH_EXECUTION_LEDGER_V5_UPDATE_20261031.md
3. experiment_protocol.md
4. FINAL_EVALUATION_PROTOCOL_V3_DRAFT.md
5. baseline_audit.md
6. joint_neighborhood_design.md
7. NOVELTY_AUDIT_V5.md

Code root:
/root/rivermind-data/ca_rl_completion_v5_staging/code

SSH alias:
hn01-research

Last verified snapshot 2026-11-01 03:43:39 UTC:
- BC Global ablation: 1512/1944, seed 11 and 23 complete, seed 37 running.
- M2 Global NoJoint watcher waits for the BC completion marker.
- RL Global Transfer 2592/2592 complete.
- Global Joint 1920/1920 complete.
- Paper30 300/300 complete.
- formal_v3 generated and witness-validated only; no optimizer access.

Always re-check live status before action. Do not duplicate jobs or open formal_v3 before code/method/protocol freeze.
