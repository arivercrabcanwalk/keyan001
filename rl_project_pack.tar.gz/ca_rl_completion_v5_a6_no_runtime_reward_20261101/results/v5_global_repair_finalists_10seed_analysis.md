# Same-source global-repair finalist confirmation — 10 seeds

All finalists were run under one source version, global Assignment repair, 24 validation maps and solver seeds 101–110. Statistical unit: map; average ten runs within each map.

| Budget | Method | Mean cost | Median | SD | Feasibility | Solver s | End-to-end s | Steps |
|---:|---|---:|---:|---:|---:|---:|---:|---:|
| 6s | m1d_global_asg | 457.1694 | 361.5166 | 263.5550 | 100.0% | 6.000 | 6.011 | 18370.3 |
| 6s | m2_global_asg | 457.2439 | 361.5166 | 263.6956 | 100.0% | 6.000 | 6.009 | 14876.7 |
| 6s | m4_global_asg | 457.4772 | 361.8218 | 263.4049 | 100.0% | 6.000 | 6.009 | 10782.0 |
| 12s | m1d_global_asg | 456.9898 | 361.5166 | 263.3822 | 100.0% | 12.000 | 12.011 | 35858.7 |
| 12s | m2_global_asg | 456.8551 | 361.5166 | 263.1539 | 100.0% | 12.000 | 12.009 | 28644.6 |
| 12s | m4_global_asg | 457.1938 | 361.5254 | 263.0316 | 100.0% | 12.000 | 12.009 | 22148.7 |

## Paired comparisons vs M2 Global

Negative delta favors the candidate. Holm family includes every finalist except M2 Global at both budgets.

| Budget | Method | Mean delta % | 95% CI | W/L/T maps | Wilcoxon p | Holm p |
|---:|---|---:|---:|---:|---:|---:|
| 6s | m1d_global_asg | -0.0069% | [-0.0589, +0.0301] | 4/9/11 | 0.4548 | 0.4668 |
| 6s | m4_global_asg | +0.1027% | [+0.0146, +0.2462] | 4/17/3 | 0.0958 | 0.2874 |
| 12s | m1d_global_asg | +0.0171% | [-0.0086, +0.0446] | 4/8/12 | 0.2334 | 0.4668 |
| 12s | m4_global_asg | +0.1096% | [+0.0168, +0.2527] | 4/16/4 | 0.04405 | 0.1762 |

## Descriptive paired comparisons vs M1D Global (not a confirmatory family)

| Budget | Method | Mean delta % | 95% CI | W/L/T maps | Wilcoxon p (descriptive) |
|---:|---|---:|---:|---:|---:|
| 6s | m2_global_asg | +0.0070% | [-0.0300, +0.0605] | 9/4/11 | 0.4548 |
| 6s | m4_global_asg | +0.1098% | [+0.0039, +0.2646] | 8/13/3 | 0.2157 |
| 12s | m2_global_asg | -0.0171% | [-0.0445, +0.0090] | 8/4/12 | 0.2334 |
| 12s | m4_global_asg | +0.0926% | [-0.0134, +0.2419] | 6/14/4 | 0.33 |
