# Official held-out test split usage audit

Previously used: **True**
Result-record hits: 0
Manifest hits: 0
Unique test maps found in current results tree: 0
Known prior-use statement in baseline audit: True
Blind test claim allowed: False

- Prior-use evidence: baseline_audit.md explicitly states the historical test is not blind.
