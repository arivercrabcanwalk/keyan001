# Phase 1 — affected-subproblem vs global reconstruction

Validation maps: 24; proposal-generation seeds: 20; generated proposals: 2045; unavailable: 5155; candidate rows: 6135; task errors: 0.

The statistical unit is the map. Candidate proposals are averaged within map and are not treated as independent samples.

## Candidate repair-mode summary

| Operator | Generated proposals | Mode | Feasible / attempted | Feasibility % | Mean delta % (feasible) | Mean apply ms | Mean changed stations | Preservation pass % |
|---|---:|---|---:|---:|---:|---:|---:|---:|
| 12 joint_open_steal | 1260 | local_scoped | 1260/1260 | 100.0% | +12.0319 | 0.0209 | 2.57 | 100.0% |
| 12 joint_open_steal | 1260 | global_target_repair | 1260/1260 | 100.0% | +12.0309 | 0.0285 | 2.53 | — |
| 12 joint_open_steal | 1260 | full_system_greedy | 1260/1260 | 100.0% | +11.9720 | 0.0168 | 2.67 | — |
| 13 joint_close_shift | 120 | local_scoped | 120/120 | 100.0% | -4.3945 | 0.0521 | 4.50 | 100.0% |
| 13 joint_close_shift | 120 | global_target_repair | 120/120 | 100.0% | -4.3945 | 0.0500 | 4.50 | — |
| 13 joint_close_shift | 120 | full_system_greedy | 120/120 | 100.0% | -4.3125 | 0.1001 | 4.50 | — |
| 14 joint_upgrade_absorb | 300 | local_scoped | 300/300 | 100.0% | +4.7090 | 0.0176 | 2.25 | 100.0% |
| 14 joint_upgrade_absorb | 300 | global_target_repair | 300/300 | 100.0% | +4.4645 | 0.0590 | 2.09 | — |
| 14 joint_upgrade_absorb | 300 | full_system_greedy | 300/300 | 100.0% | +5.8568 | 0.0168 | 2.27 | — |
| 15 joint_downgrade_reallocate | 185 | local_scoped | 185/185 | 100.0% | -3.8353 | 0.0296 | 1.85 | 100.0% |
| 15 joint_downgrade_reallocate | 185 | global_target_repair | 185/185 | 100.0% | -4.0921 | 0.0323 | 2.90 | — |
| 15 joint_downgrade_reallocate | 185 | full_system_greedy | 185/185 | 100.0% | -4.0517 | 0.0189 | 1.85 | — |
| 16 joint_swap_absorb | 180 | local_scoped | 180/180 | 100.0% | +0.2343 | 0.0582 | 6.47 | 100.0% |
| 16 joint_swap_absorb | 180 | global_target_repair | 180/180 | 100.0% | +0.2343 | 0.0516 | 6.47 | — |
| 16 joint_swap_absorb | 180 | full_system_greedy | 180/180 | 100.0% | +0.0090 | 0.0310 | 6.04 | — |

## Paired map-level cost comparisons

Negative left-minus-right values favor the left repair mode. Conditional cost comparisons include only proposals feasible under both modes.

| Operator | Comparison | Common feasible proposals | Maps | Mean map difference (pp) | 95% bootstrap CI | W/L/T maps | Wilcoxon p | Holm p (10 comparisons) |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| op12 | local_scoped_vs_global_target_repair | 1260 | 21 | +0.0009 | [-0.2398, +0.2079] | 6/9/6 | 0.7197 | 1 |
| op12 | local_scoped_vs_full_system_greedy | 1260 | 21 | +0.0599 | [-0.3375, +0.4572] | 10/9/2 | 0.8596 | 1 |
| op13 | local_scoped_vs_global_target_repair | 120 | 2 | +0.0000 | [+nan, +nan] | 0/0/2 | 1 | 1 |
| op13 | local_scoped_vs_full_system_greedy | 120 | 2 | -0.0820 | [+nan, +nan] | 2/0/0 | 1 | 1 |
| op14 | local_scoped_vs_global_target_repair | 300 | 5 | +0.2445 | [+0.1087, +0.3755] | 0/4/1 | 0.125 | 1 |
| op14 | local_scoped_vs_full_system_greedy | 300 | 5 | -1.1478 | [-2.2226, -0.4225] | 5/0/0 | 0.0625 | 0.5625 |
| op15 | local_scoped_vs_global_target_repair | 185 | 8 | +0.3232 | [+0.1451, +0.5275] | 0/6/2 | 0.03125 | 0.3125 |
| op15 | local_scoped_vs_full_system_greedy | 185 | 8 | +0.3241 | [-0.1889, +0.6928] | 2/6/0 | 0.25 | 1 |
| op16 | local_scoped_vs_global_target_repair | 180 | 3 | +0.0000 | [+nan, +nan] | 0/0/3 | 1 | 1 |
| op16 | local_scoped_vs_full_system_greedy | 180 | 3 | +0.2253 | [+nan, +nan] | 1/2/0 | 1 | 1 |

## Interpretation limits

- This is a candidate-level mechanism experiment from a common greedy incumbent, not a full solver-budget comparison.
- Global-target repair preserves the same selected target IDs but expands receiver scope to all open stations/drones.
- Full-system greedy applies the same station-type changes but reconstructs every target; selected IDs are not hard destination constraints in that mode.
- The full-system greedy rebuild is a specific deterministic reconstruction baseline, not a global optimum.
- Local preservation was checked against the computed touched scope. It is not proof that the scope is the mathematically minimal dependency closure.
- Use these results to decide which operators can legitimately be described as affected-subproblem repair. Do not generalize beyond the tested operators and maps.
