# CA-RL-TSALNS A2C training artifact audit

PASS — all three seeds passed the strict audit.

| Seed | Updates | Validation checks | Best validation cost | Elapsed seconds |
|---:|---:|---:|---:|---:|
| 11 | 60 | 12 | 458.289064 | 171.46 |
| 23 | 60 | 12 | 457.969946 | 171.35 |
| 37 | 60 | 12 | 458.139163 | 171.22 |

A2C script SHA256: 8e66e61fc84ee61f078a5e18a585f89ccf4969f12134790d6a589ee1e1961294
All A2C checkpoints were loaded through the production model loader.
Each A2C seed was initialized from the matching audited BC checkpoint.
