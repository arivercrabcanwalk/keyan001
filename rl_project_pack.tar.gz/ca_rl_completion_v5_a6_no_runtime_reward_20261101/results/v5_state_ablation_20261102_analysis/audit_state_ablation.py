#!/usr/bin/env python3
"""Read-only receipt audit and map-paired statistics; never invokes an optimizer."""
import argparse,csv,gzip,hashlib,importlib.util,itertools,json,math,platform,statistics,sys
from collections import Counter,defaultdict
from dataclasses import asdict
from pathlib import Path

BUDGETS=(6,12)
METHODS=('m2_global_nojoint','m2_global_asg','m6_global_asg','m6_global_nojoint','m6_global_nomask','m6_global_zeroasg','m6_global_zerodrone','m6_global_zerohist','m6_global_zeroglobal','m6_global_nohighint')
SEEDS=(101,102,103)
BOOTSTRAP_SEED=20261102
BOOTSTRAP_REPLICATES=20000

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,obj):Path(p).write_text(json.dumps(obj,ensure_ascii=False,sort_keys=True,indent=2,allow_nan=False)+'\n')
def csvout(p,rows):
    if not rows:return
    with Path(p).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--root',required=True);ap.add_argument('--out',required=True);args=ap.parse_args()
    root=Path(args.root).resolve();out=Path(args.out).resolve();out.mkdir(parents=True,exist_ok=True)
    sys.path.insert(0,str(root))
    import numpy as np
    from lrphsd.problem import read_instance
    from lrphsd.evaluator import evaluate
    from carl.stats import wilcoxon_signed_rank,bootstrap_ci,holm
    from carl.runner import ABLATIONS
    issues=[];warnings=[];receipt=[];raw=[];maps={};manifests={};code_map={}
    for dirname in ('carl','lrphsd','native','scripts','configs'):
        for p in sorted((root/dirname).glob('*')):
            if p.is_file() and p.suffix in ('.py','.c','.so','.dylib','.dll'):code_map[str(p.relative_to(root))]=sha(p)
    for sd in ('official_source','instrumented_source'):
        for p in sorted((root/'reference/java'/sd).glob('*.java')):code_map[str(p.relative_to(root))]=sha(p)
    p=root/'reference/java/SOURCE_LOCK.json'
    if p.exists():code_map[str(p.relative_to(root))]=sha(p)
    current_code_hash=hashlib.sha256(json.dumps(code_map,sort_keys=True).encode()).hexdigest()
    dump(out/'source_file_hashes.json',{'code_hash':current_code_hash,'files':code_map})
    for b in BUDGETS:
        d=root/'results'/f'v5_state_ablation_20261102_{b}s';mp=d/'manifest.json';mf=json.loads(mp.read_text());manifests[str(b)]=mf
        if mf['methods']!=list(METHODS):issues.append(f'{b}:method_manifest_mismatch')
        if mf['seeds']!=list(SEEDS) or len(mf['instances'])!=24:issues.append(f'{b}:map_seed_manifest_mismatch')
        if mf.get('tasks')!=720 or mf.get('errors')!=0 or 'finished' not in mf:issues.append(f'{b}:manifest_completion')
        modelpath=Path(mf['argv'][mf['argv'].index('--ppo-model')+1]);modelhash=sha(modelpath)
        wanted={(Path(s).stem,m,seed) for s,m,seed in itertools.product(mf['instances'],METHODS,SEEDS)};seen=set()
        jsonfiles=sorted(d.glob('*.json'));solutionfiles=sorted(d.glob('*.solution.json.gz'))
        if len(solutionfiles)!=720:issues.append(f'{b}:solution_count:{len(solutionfiles)}')
        receipt.append({'path':str(mp),'sha256_at_receipt':sha(mp),'role':'run_manifest'})
        receipt.append({'path':str(modelpath),'sha256_at_receipt':modelhash,'role':'checkpoint_bytes_not_loaded'})
        for f in jsonfiles:
            if f.name=='manifest.json':continue
            r=json.loads(f.read_text());key=(r.get('instance'),r.get('method'),r.get('seed'))
            if key in seen:issues.append(f'duplicate:{b}:{key}')
            seen.add(key);rowissues=[]
            tag=f'{key[0]}__{key[1]}__s{key[2]}'
            if f.name!=tag+'.json':rowissues.append('filename_identity')
            if r.get('status')!='ok' or r.get('feasible') is not True:rowissues.append('status_or_claimed_feasible')
            if float(r.get('seconds',-1))!=b:rowissues.append('budget')
            if not isinstance(r.get('cost'),(float,int)) or not math.isfinite(r['cost']):rowissues.append('nonfinite_cost')
            prov=r.get('provenance',{})
            if hashlib.sha256(json.dumps(prov,sort_keys=True,default=str).encode()).hexdigest()!=r.get('task_identity'):rowissues.append('task_identity_hash')
            for field in ('method','instance','seed','seconds'):
                if prov.get(field)!=r.get(field):rowissues.append('provenance_'+field)
            if prov.get('code_sha256')!=current_code_hash:rowissues.append('current_source_digest')
            if prov.get('model_sha256')!=modelhash:rowissues.append('checkpoint_hash')
            ip=Path(r.get('instance_path',''));ih=sha(ip)
            if ih!=prov.get('instance_sha256'):rowissues.append('instance_hash')
            if str(ip) not in mf['instances']:rowissues.append('instance_not_in_manifest')
            if str(ip) not in maps:maps[str(ip)]=read_instance(ip)
            ins=maps[str(ip)]
            solpath=d/(tag+'.solution.json.gz')
            with gzip.open(solpath,'rt') as h:sol=json.load(h)
            if sol.get('instance')!=key[0] or sol.get('instance_sha256')!=ih:rowissues.append('solution_instance_identity')
            a=evaluate(ins,sol)
            if not a['feasible']:rowissues.append('independent_infeasible:'+','.join(a['issues']))
            err=abs(a['cost']-r['cost'])
            if err>1e-7:rowissues.append('independent_cost')
            if r.get('audit_issues'):rowissues.append('reported_audit_issue')
            abl=ABLATIONS.get(r['method'],{})
            eff={'controller':abl.get('controller',r['method']),'repair_scope_mode':abl.get('repair_scope_mode','local'),'families':list(abl.get('families',prov.get('families',[]))),'zero_groups':list(abl.get('zero_groups',prov.get('zero_groups',[]))),'mask_mode':abl.get('mask_mode',prov.get('mask_mode')),'intensities':list(abl.get('intensities',prov.get('intensities',[])))}
            if prov.get('resolved_controller')!=eff['controller'] or prov.get('resolved_repair_scope_mode')!=eff['repair_scope_mode']:rowissues.append('resolved_controller_or_scope')
            for msg in rowissues:issues.append(f'{b}:{tag}:{msg}')
            receipt.extend([{'path':str(f),'sha256_at_receipt':sha(f),'role':'result_json'},{'path':str(solpath),'sha256_at_receipt':sha(solpath),'role':'full_solution_gzip'}])
            raw.append({'budget_seconds':b,'instance':r['instance'],'method':r['method'],'solver_seed':r['seed'],'cost':r['cost'],'initial_cost':r['initial_cost'],'independent_cost':a['cost'],'cost_error':err,'feasible':a['feasible'],'solver_seconds':r['solver_seconds'],'end_to_end_seconds':r['end_to_end_seconds'],'budget_overrun_seconds':r.get('budget_overrun_seconds',0),'steps':r['steps'],'checkpoint_sha256':modelhash,'code_sha256':prov.get('code_sha256'),'solution_sha256_at_receipt':sha(solpath),'result_sha256_at_receipt':sha(f),'solution_hash_was_recorded_in_run':('solution_sha256' in r),'effective_config':eff,'audit_issues':rowissues})
        if seen!=wanted:issues.append(f'{b}:missing={len(wanted-seen)}:extra={len(seen-wanted)}')
    if len(raw)!=1440:issues.append(f'total_count:{len(raw)}')
    init=defaultdict(list)
    for r in raw:init[(r['budget_seconds'],r['instance'],r['solver_seed'])].append(r['initial_cost'])
    initial_group_pass=sum(max(v)-min(v)<=1e-8 for v in init.values())
    if initial_group_pass!=144:issues.append(f'initial_cost_match:{initial_group_pass}/144')
    if len({r['code_sha256'] for r in raw})!=1:issues.append('mixed_code')
    if {Path(x).stem for x in manifests['6']['instances']}!={Path(x).stem for x in manifests['12']['instances']}:issues.append('cross_budget_mapset')
    warnings += ['No result contains a recorded run-time solution hash. Receipt hashes freeze current files, not retroactively authenticate the original execution. Solution instance identity, independent feasibility and objective agreement are checked for every row.','All methods including M2 have an unused checkpoint binding in provenance because one CLI --ppo-model was passed. The matched source maps M2 to AdaptiveWeights without model loading; do not interpret this binding as learned inference.','One selected PPO model seed (23); no training-seed replication in this ablation matrix.','Zero-feature interventions are inference-time, not separately retrained policies.','Analysis multiplicity family was not fully enumerated in the pre-existing protocol: the 18-test global Holm family is explicitly exploratory and post hoc.','There are seven RL intervention variants, not eight: ten total methods = two M2 references + full PPO + seven variants.']
    audit={'status':'PASS' if not issues else 'FAIL','rows':len(raw),'independently_feasible':sum(r['feasible'] for r in raw),'issue_count':len(issues),'issues':issues,'warnings':warnings,'max_absolute_cost_error':max(r['cost_error'] for r in raw),'initial_groups_equal':initial_group_pass,'expected_initial_groups':144,'current_code_sha256':current_code_hash,'model_sha256':sorted({r['checkpoint_sha256'] for r in raw}),'has_run_time_solution_hash_rows':sum(r['solution_hash_was_recorded_in_run'] for r in raw),'receipt_hash_definition':'SHA256 computed at reception, not an original run-time binding','source_files':len(code_map),'solver_runs_launched':0,'training_runs_launched':0,'python':platform.python_version(),'numpy':np.__version__}
    dump(out/'audit.json',audit);dump(out/'receipt_hashes.json',receipt);dump(out/'raw_rows.json',raw)
    for s in manifests['6']['instances']:receipt.append({'path':s,'sha256_at_receipt':sha(s),'role':'instance'})
    dump(out/'receipt_hashes.json',receipt)
    if issues:print(json.dumps(audit,ensure_ascii=False));return 2
    maprows=[];summary=[];by=defaultdict(list)
    for r in raw:by[(r['budget_seconds'],r['instance'],r['method'])].append(r)
    for (b,ins,m),rs in sorted(by.items()):
        maprows.append({'budget_seconds':b,'instance':ins,'method':m,'n_solver_seeds':len(rs),'mean_cost':statistics.mean(r['cost'] for r in rs),'mean_solver_seconds':statistics.mean(r['solver_seconds'] for r in rs),'mean_end_to_end_seconds':statistics.mean(r['end_to_end_seconds'] for r in rs)})
    lookup={(r['budget_seconds'],r['instance'],r['method']):r['mean_cost'] for r in maprows}
    for b,m in itertools.product(BUDGETS,METHODS):
        rs=[r for r in raw if r['budget_seconds']==b and r['method']==m];vs=np.array([r['mean_cost'] for r in maprows if r['budget_seconds']==b and r['method']==m]);times=np.array([r['solver_seconds'] for r in rs])
        summary.append({'budget_seconds':b,'method':m,'n_maps':len(vs),'n_runs':len(rs),'mean_map_cost':float(vs.mean()),'median_map_cost':float(np.median(vs)),'sd_map_cost':float(vs.std(ddof=1)),'independently_feasible':sum(r['feasible'] for r in rs),'failure_rate':sum(not r['feasible'] for r in rs)/len(rs),'mean_solver_seconds':float(times.mean()),'p95_solver_seconds':float(np.quantile(times,.95)),'max_overrun_seconds':max(r['budget_overrun_seconds'] for r in rs),'mean_end_to_end_seconds':statistics.mean(r['end_to_end_seconds'] for r in rs),'mean_steps':statistics.mean(r['steps'] for r in rs)})
    comparisons=[]
    variants=METHODS[3:]
    for b in BUDGETS:
        configs=[(m,'m6_global_asg','within_RL') for m in variants]+[('m6_global_asg','m2_global_nojoint','RL_independent_contribution'),('m2_global_asg','m2_global_nojoint','Joint_family')]
        names=sorted({r['instance'] for r in maprows if r['budget_seconds']==b})
        for m,ref,family in configs:
            x=np.array([lookup[b,n,m] for n in names]);y=np.array([lookup[b,n,ref] for n in names]);d=x-y;delta=100*d/y
            st=wilcoxon_signed_rank(x,y);ci=bootstrap_ci(delta,np.zeros(len(delta)),n_boot=BOOTSTRAP_REPLICATES,seed=BOOTSTRAP_SEED+len(comparisons));sdd=float(d.std(ddof=1))
            comparisons.append({'budget_seconds':b,'method':m,'reference':ref,'family':family,'n_maps':len(names),'n_solver_seeds':3,'mean_delta_percent':float(delta.mean()),'median_delta_percent':float(np.median(delta)),'sd_delta_percent':float(delta.std(ddof=1)),'ci95_low_percent':ci['lo'],'ci95_high_percent':ci['hi'],'mean_delta_cost':float(d.mean()),'wins':int((d < -1e-9).sum()),'losses':int((d > 1e-9).sum()),'ties':int((np.abs(d)<=1e-9).sum()),'wilcoxon_p_raw':st['p_value'],'wilcoxon_statistic':st['statistic'],'wilcoxon_n_nonzero':st['n'],'wilcoxon_method':st['method'],'rank_biserial_worse_positive':st.get('rank_biserial',0.0),'cohen_dz_worse_positive':float(d.mean()/sdd) if sdd>1e-12 else None,'bootstrap_seed':BOOTSTRAP_SEED+len(comparisons)})
    assert len(comparisons)==18
    for r,pv in zip(comparisons,holm([r['wilcoxon_p_raw'] for r in comparisons])):r['holm_p_global18']=pv
    stats={'classification':'exploratory_development_validation_not_blind_not_confirmatory','independent_unit':'map; three paired solver seeds averaged within each map','model_training_seed':23,'relative_cost_definition':'100*(mean_cost_method-map - mean_cost_reference-map)/mean_cost_reference-map; positive means method worse','bootstrap_replicates':BOOTSTRAP_REPLICATES,'bootstrap_seed_base':BOOTSTRAP_SEED,'ci_type':'percentile paired-map bootstrap of mean map relative cost difference; pointwise 95%, not simultaneous','test':'two-sided exact tie-aware signed-rank on map-mean absolute cost differences; zero threshold 1e-12','holm_family':'all 18 prespecified-for-this-reanalysis contrasts, both budgets pooled; post-hoc exploratory family','run_summary':summary,'comparisons':comparisons}
    dump(out/'statistics.json',stats);csvout(out/'method_summary.csv',summary);csvout(out/'paired_comparisons.csv',comparisons);csvout(out/'map_means.csv',maprows)
    rawcsv=[{k:v for k,v in r.items() if k not in ('effective_config','audit_issues')} for r in raw];csvout(out/'validated_rows.csv',rawcsv)
    report=['# 当前源 CA-RL 消融：接收验收与配对统计','', '日期：2026-11-02。只处理已存在实验；未启动求解、训练或正式测试。', '', '## 验收结果',f'- 独立重评分 {len(raw)}/1440；可行 {audit["independently_feasible"]}/1440；验收错误 {len(issues)}；最大成本绝对误差 {audit["max_absolute_cost_error"]:.3g}。',f'- 6s/12s各720行与完整解；24地图×3求解种子×10方法；144个地图/种子/预算组初始成本一致。',f'- 当前源码汇总 SHA256：{current_code_hash}。',f'- PPO checkpoint SHA256：{audit["model_sha256"][0]}。','- 原运行记录没有完整解历史SHA字段；receipt_hashes.json仅固定接收时字节。每行已重核任务身份、实例/模型/当前源码哈希、完整解身份、独立物理可行性和总成本。','- M2记录中多余的模型身份绑定没有触发PPO推理；匹配源码的M2分支仍为AdaptiveWeights。','', '## 统计定义','- 独立单位为地图n=24，每地图先平均3个求解种子；本矩阵只有一个已选模型种子23。','- 相对差 = 100×(候选地图均值−参考地图均值)/参考地图均值；正数表示候选更差。','- 20,000次地图配对bootstrap，percentile点态95%CI；双侧精确tie-aware Wilcoxon使用地图平均绝对成本差；报告rank-biserial与Cohen dz。','- 总计7个RL干预×2预算 + PPO对NoJoint×2 + M2 Joint对NoJoint×2 =18项，全局Holm校正。原协议未事先枚举完整校正族，本次明确标为探索性开发再分析。','- 特征置零是推理期干预，不是去掉特征后重新训练，也不是因果机制的最终证明。','', '## 方法描述统计','|预算|方法|均值成本|地图SD|可行/运行|平均solver秒|','|---|---|---:|---:|---:|---:|']
    for r in summary:report.append(f'|{r["budget_seconds"]}s|{r["method"]}|{r["mean_map_cost"]:.6f}|{r["sd_map_cost"]:.6f}|{r["independently_feasible"]}/{r["n_runs"]}|{r["mean_solver_seconds"]:.5f}|')
    report+=['','## 全部配对比较','|预算|候选→参考|差异%|95%CI%|W/L/T|原始p|Holm18 p|rank-biserial|','|---|---|---:|---|---|---:|---:|---:|']
    for r in comparisons:report.append(f'|{r["budget_seconds"]}s|{r["method"]} → {r["reference"]}|{r["mean_delta_percent"]:+.6f}|[{r["ci95_low_percent"]:+.6f}, {r["ci95_high_percent"]:+.6f}]|{r["wins"]}/{r["losses"]}/{r["ties"]}|{r["wilcoxon_p_raw"]:.6g}|{r["holm_p_global18"]:.6g}|{r["rank_biserial_worse_positive"]:+.4f}|')
    report+=['','## 结论边界','- 接收与独立可行性门槛已通过，不需要重新运行这1,440项。','- 当前完整PPO在两个预算的平均成本均高于NoJoint；具体差异和不确定性见表，不支持将该模型包装为RL稳定优越性证据。','- 单个推理期干预显著或不显著，不能证明该状态组在正确匹配环境重训后必然有益/无益。','- 24张地图已用于checkpoint选择及开发；不能标为独立盲测或确认性证据，也不能外推RL普遍无效。','- 不按求解种子或1,440行把n放大；不删除失败任务，也不根据显著性选择比较族。','', '## 复查入口',f'    python3 -B audit_state_ablation.py --root {root} --out OUTPUT_DIR','', '统计函数逐字复用服务器carl/stats.py。source_file_hashes.json保存本次计算所用所有源文件/二进制哈希；receipt_hashes.json保存结果、完整解、实例和模型接收哈希；validated_rows.csv连接原始行与独立评估。']
    (out/'REPORT.md').write_text('\n'.join(report)+'\n')
    meta={'audit_script_sha256':sha(Path(__file__)),'audit_sha256':sha(out/'audit.json'),'statistics_sha256':sha(out/'statistics.json'),'receipt_hashes_sha256':sha(out/'receipt_hashes.json'),'report_sha256':sha(out/'REPORT.md'),'command':f'python3 -B {Path(__file__)} --root {root} --out {out}','exit_status':0,'result':'STATE_ABLATION PASS rows=1440 independently_feasible=1440 comparisons=18 solver_runs=0 training_runs=0'}
    dump(out/'VERIFICATION.json',meta)
    for f in ['audit.json','statistics.json','receipt_hashes.json','REPORT.md','method_summary.csv','paired_comparisons.csv','map_means.csv','validated_rows.csv']:assert (out/f).read_bytes()
    print(meta['result']);print('OUT',out)
    return 0
if __name__=='__main__':raise SystemExit(main())
