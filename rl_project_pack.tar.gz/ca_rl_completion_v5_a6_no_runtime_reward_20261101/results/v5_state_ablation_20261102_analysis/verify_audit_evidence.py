#!/usr/bin/env python3
"""No optimization: fixtures, source-bound reconstruction, recorded-counter checks."""
import argparse,collections,hashlib,json,sys
from pathlib import Path

def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2,sort_keys=True)+'\n')
ap=argparse.ArgumentParser();ap.add_argument('--root',required=True);ap.add_argument('--out',required=True);args=ap.parse_args();root=Path(args.root).resolve();out=Path(args.out).resolve();sys.path.insert(0,str(root))
import numpy as np
from carl.stats import wilcoxon_signed_rank,holm,bootstrap_ci
from carl.runner import ABLATIONS
fixtures=[]
for name,x,want in [('all_zero',[0,0,0,0],1.0),('all_positive_tied',[1,1,1,1],.125),('symmetric_tied',[-1,-1,1,1],1.0),('untied_positive',[1,2,3,4],.125)]:
    result=wilcoxon_signed_rank(x,[0]*len(x));assert abs(result['p_value']-want)<1e-14,(name,result,want);fixtures.append({'test':name,'input':x,'expected_p':want,'result':result,'status':'PASS'})
h=holm([.01,.04,.03,.002]);assert np.allclose(h,[.03,.06,.06,.008]);fixtures.append({'test':'Holm_known','input':[.01,.04,.03,.002],'expected':[.03,.06,.06,.008],'result':h,'status':'PASS'})
b=bootstrap_ci([0,0,0],[0,0,0],n_boot=1000,seed=20261102);assert b['lo']==0 and b['hi']==0;fixtures.append({'test':'zero_bootstrap','result':b,'status':'PASS'})
dump(out/'statistics_fixture_tests.json',fixtures)
issues=[];n=0;family_rows=0;intensity_rows=0;nominal_mismatches=collections.Counter();counts=collections.Counter();reconstructed={}
for budget in (6,12):
    for f in sorted((root/'results'/f'v5_state_ablation_20261102_{budget}s').glob('*.json')):
        if f.name=='manifest.json':continue
        r=json.loads(f.read_text());n+=1;m=r['method'];counts[m]+=1;abl=ABLATIONS[m];p=r['provenance'];cfg=r['config'];c=r['counters']
        expected={k:list(abl.get(k,p[k])) for k in ('families','zero_groups','intensities')};expected.update({k:abl.get(k,p[k]) for k in ('mask_mode','cross_exchange')});expected['repair_scope_mode']=abl.get('repair_scope_mode','local');reconstructed[m]=expected
        for k in ('families','zero_groups','intensities','mask_mode','cross_exchange'):
            if p[k]!=expected[k]:nominal_mismatches[m+':'+k]+=1
        if cfg.get('repair_scope_mode')!=expected['repair_scope_mode'] or r.get('repair_scope_mode')!=expected['repair_scope_mode']:issues.append(f.name+':scope')
        want_controller={'m2':'M2_adaptive_joint','m6':'M6_ppo_joint'}[abl['controller']]
        if r['controller']!=want_controller:issues.append(f.name+':controller')
        if cfg.get('n_actions')!=51 or cfg.get('n_operators')!=17 or len(c.get('family_attempts',[]))!=4 or len(c.get('action_counts',[]))!=51:issues.append(f.name+':counter_shape')
        for family,attempts in enumerate(c['family_attempts']):
            if family not in expected['families'] and attempts!=0:issues.append(f.name+':forbidden_family_counter')
        if expected['families']!=[0,1,2,3]:family_rows+=1
        for action,attempts in enumerate(c['action_counts']):
            if action%3 not in expected['intensities'] and attempts!=0:issues.append(f.name+':forbidden_intensity_counter')
        if expected['intensities']!=[0,1,2]:intensity_rows+=1
probe=out/'effective_config_audit.json'
if probe.exists():
    old=json.loads(probe.read_text())
    if old.get('provenance_note','').startswith('task provenance contains nominal CLI defaults'):
        old['interpretation']='Discarded analysis-schema probe: it incorrectly assumed result.config serializes five fields absent from all records; these nulls are not violations of the experiment. See source-bound reconstruction and partial runtime checks in effective_config_audit.json.'
        dump(out/'effective_config_schema_probe_failed.json',old)
report={'status':'PASS' if not issues and n==1440 else 'FAIL','rows':n,'issue_count':len(issues),'issues':issues,'derived_effective_config':reconstructed,'method_rows':dict(counts),'source_derived_not_directly_recorded_fields':['families','zero_groups','mask_mode','intensities','cross_exchange'],'source_files_sha256':{x:digest(root/x) for x in ('carl/runner.py','carl/search.py','carl/stats.py')},'nominal_vs_derived_mismatch_counts':dict(nominal_mismatches),'recorded_runtime_checks':{'scope_and_controller_rows':n,'forbidden_family_counter_rows':family_rows,'forbidden_intensity_counter_rows':intensity_rows},'boundary':'Method-specific overrides are reconstructed from unchanged hash-bound ABLATIONS and call sites. Only controller/scope plus family/intensity restrictions have per-record runtime corroboration. Zero-feature and mask interventions lack complete recorded effective fields/input-feature traces; no retroactive runtime attestation is claimed.','solver_runs_launched':0,'training_runs_launched':0}
dump(out/'effective_config_audit.json',report)
assert report['status']=='PASS',report
md=out/'REPORT.md';txt=md.read_text();marker='\n## 补充核查与关键解释\n'
if marker in txt:txt=txt.split(marker)[0]
txt+=marker+'- 六项统计函数已知样例通过：全零、同号tie、对称tie、无tie、已知Holm、零差bootstrap；未调用优化器。\n- 1,440行控制器/全局scope与源绑定方法映射匹配；288行NoJoint记录的禁止family计数为0；144行nohighint记录的强度2动作计数为0。\n- 原provenance的families/zero_groups/mask_mode/intensities是CLI名义默认值；runner在调用solve时用ABLATIONS覆盖。结果config没有序列化这五个完整有效字段。effective_config_audit.json明确标记静态源绑定推导与部分运行计数核证，不声称对mask或特征置零输入存在完整历史轨迹。\n- 12s去掉高强度动作相对fullPPO退化+0.061171%（点态95%CI +0.024328%~+0.109757%，全局Holm p=0.00439453）；其余13项RL干预对照未达到本次18项全局校正后的0.05门槛。该结果至多支持本已选模型的动作强度贡献，不证明跨层状态学习必要性。\n- 当前PPO对NoJoint：6s相对差+0.079127%（点态95%CI +0.013283%~+0.143807%，全局Holm p=0.228271）；12s +0.038654%（-0.008394%~+0.087140%，p=1）。点态CI和校正p针对不同估计/多重比较口径；不得拿点态CI绕过全局比较族。\n- 不显著不代表等价；当前开发矩阵不构成RL优越性证据。\n'
md.write_text(txt)
meta=json.loads((out/'VERIFICATION.json').read_text());meta.update({'supplement_script_sha256':digest(Path(__file__)),'statistics_fixture_tests_sha256':digest(out/'statistics_fixture_tests.json'),'effective_config_audit_sha256':digest(out/'effective_config_audit.json'),'report_sha256':digest(md),'supplement_command':f'/opt/conda/bin/python -B {Path(__file__)} --root {root} --out {out}','supplement_exit_status':0,'supplement_result':'SUPPLEMENT PASS statistical_fixtures=6 source_bound_configs=1440 forbidden_family_checks=288 forbidden_intensity_checks=144 solver_runs=0 training_runs=0'});dump(out/'VERIFICATION.json',meta)
print(meta['supplement_result'])
