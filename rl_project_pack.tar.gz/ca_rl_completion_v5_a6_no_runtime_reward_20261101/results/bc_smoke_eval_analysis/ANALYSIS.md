# Benchmark analysis: results/bc_smoke_eval

Runs: 12  Methods: m0, m1d, m6  Reference: m0

| method | mean cost | feasible | runtime s | steps | outer iters | vs ref % | wins/losses | p (Holm) | 95% CI |
|---|---|---|---|---|---|---|---|---|---|
| m0 | 268.8910 | 1.000 | 0.30 | - | 55 | - | - | - | - |
| m1d | 266.4052 | 1.000 | 0.30 | 1842 | - | - | - | - | - |
| m6 | 266.4647 | 1.000 | 0.30 | 1300 | - | - | - | - | - |

## Per-size mean % difference vs m0

| method | 3_10 | 5_35 |
|---|---|---|
| m1d | -2.15 | -0.48 |
| m6 | -2.15 | -0.45 |

## Anytime mean best cost

| method | 0.25 | 0.5 | 0.75 | 1.0 |
|---|---|---|---|---|
| m0 | 273.071 | 272.631 | 272.555 | 268.891 |
| m1d | 267.293 | 267.163 | 266.711 | 266.405 |
| m6 | 267.105 | 266.727 | 266.502 | 266.465 |
