# A6 no-runtime-reward PPO training audit

Overall: PASS

Source SHA256: 4b85702035da04972cc5cde4deea61f9f50b4e4e232bd66173a82dbe72d5ba29

| Seed | Audit | Best validation cost | Training seconds | Best checkpoint SHA256 |
|---:|---|---:|---:|---|
| 11 | PASS | 457.977217 | 178.402 | 364db5d86a10a97728bf47eff5019c61aed78c6f96bb42ef6976c7c660be264c |
| 23 | PASS | 458.153206 | 179.230 | fbf2e88385700acbcdd9338c951f3b5edec8fb5f66bdfbd2be39e2ab7bf3ae68 |
| 37 | PASS | 458.363747 | 178.256 | 8dbefeba3be0472c2a9cfd07b84e0d93d56e8b6b3ed5472364b5ca75f5de72dc |

All three runs used reward schema current-cost-delta-best-no-time-v3, the same 72/24 train/validation splits and the same BC warm-start checkpoints as reward-v2 PPO. Each has 60 updates, 60 hashed rollouts, 12 stochastic and 12 deterministic validation snapshots. The explicit operator-time reward penalty was removed; SMDP elapsed-time discounting remains.

Audit script SHA256: dadd2bdc56c9f011140e7c95bb4e36a6faf30459af781b93f768c67235e6868f
