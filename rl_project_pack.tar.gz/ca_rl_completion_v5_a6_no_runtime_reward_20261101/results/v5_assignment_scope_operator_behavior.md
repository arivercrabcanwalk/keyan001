# Assignment-scope operator behavior diagnostics

Counters are aggregated over 24 validation maps × 10 solver seeds. They are descriptive mechanism diagnostics, not independent-sample significance tests.

| Budget | Method | Operator | Attempts | Feasible % | Changed % | Accepted % | Improved % | Improved given changed % | Best updates |
|---:|---|---|---:|---:|---:|---:|---:|---:|---:|
| 6s | m1d | transfer | 515736 | 100.0% | 100.0% | 79.8% | 16.87% | 16.87% | 75 |
| 6s | m1d | drone_reassign | 319174 | 100.0% | 100.0% | 74.4% | 13.35% | 13.35% | 105 |
| 6s | m1d | joint_open | 122659 | 100.0% | 100.0% | 25.9% | 0.00% | 0.00% | 0 |
| 6s | m1d | joint_close | 33127 | 100.0% | 100.0% | 100.0% | 100.00% | 100.00% | 179 |
| 6s | m1d | joint_upgrade | 66260 | 100.0% | 100.0% | 37.9% | 0.00% | 0.00% | 0 |
| 6s | m1d | joint_downgrade | 29440 | 100.0% | 100.0% | 100.0% | 99.69% | 99.69% | 123 |
| 6s | m1d | joint_swap | 27803 | 100.0% | 100.0% | 83.4% | 26.67% | 26.68% | 5 |
| 6s | m1d_global_asg | transfer | 535509 | 100.0% | 58.9% | 57.0% | 24.93% | 42.36% | 515 |
| 6s | m1d_global_asg | drone_reassign | 332087 | 100.0% | 70.8% | 65.7% | 25.82% | 36.48% | 301 |
| 6s | m1d_global_asg | joint_open | 128388 | 100.0% | 100.0% | 26.0% | 0.00% | 0.00% | 0 |
| 6s | m1d_global_asg | joint_close | 34167 | 100.0% | 100.0% | 100.0% | 100.00% | 100.00% | 185 |
| 6s | m1d_global_asg | joint_upgrade | 67368 | 100.0% | 100.0% | 36.2% | 0.00% | 0.00% | 0 |
| 6s | m1d_global_asg | joint_downgrade | 28589 | 100.0% | 100.0% | 100.0% | 99.54% | 99.54% | 117 |
| 6s | m1d_global_asg | joint_swap | 28572 | 100.0% | 100.0% | 81.2% | 19.50% | 19.50% | 6 |
| 6s | m2 | transfer | 337326 | 100.0% | 100.0% | 69.2% | 10.33% | 10.33% | 31 |
| 6s | m2 | drone_reassign | 375712 | 100.0% | 100.0% | 67.2% | 10.85% | 10.85% | 86 |
| 6s | m2 | joint_open | 91589 | 100.0% | 100.0% | 35.2% | 0.00% | 0.00% | 0 |
| 6s | m2 | joint_close | 35320 | 100.0% | 100.0% | 100.0% | 100.00% | 100.00% | 205 |
| 6s | m2 | joint_upgrade | 63580 | 100.0% | 100.0% | 41.9% | 0.00% | 0.00% | 0 |
| 6s | m2 | joint_downgrade | 23162 | 100.0% | 100.0% | 100.0% | 99.35% | 99.35% | 129 |
| 6s | m2 | joint_swap | 21713 | 100.0% | 100.0% | 74.0% | 13.02% | 13.02% | 7 |
| 6s | m2_global_asg | transfer | 408604 | 100.0% | 59.7% | 55.9% | 19.32% | 32.35% | 275 |
| 6s | m2_global_asg | drone_reassign | 573769 | 100.0% | 73.7% | 62.3% | 18.56% | 25.20% | 293 |
| 6s | m2_global_asg | joint_open | 98092 | 100.0% | 100.0% | 33.8% | 0.00% | 0.00% | 0 |
| 6s | m2_global_asg | joint_close | 35290 | 100.0% | 100.0% | 100.0% | 100.00% | 100.00% | 178 |
| 6s | m2_global_asg | joint_upgrade | 63031 | 100.0% | 100.0% | 40.8% | 0.00% | 0.00% | 0 |
| 6s | m2_global_asg | joint_downgrade | 22921 | 100.0% | 100.0% | 99.9% | 99.18% | 99.18% | 121 |
| 6s | m2_global_asg | joint_swap | 20247 | 100.0% | 100.0% | 73.8% | 10.58% | 10.58% | 5 |
| 12s | m1d | transfer | 965387 | 100.0% | 100.0% | 80.2% | 16.84% | 16.84% | 71 |
| 12s | m1d | drone_reassign | 600846 | 100.0% | 100.0% | 75.0% | 13.45% | 13.45% | 105 |
| 12s | m1d | joint_open | 230061 | 100.0% | 100.0% | 26.3% | 0.00% | 0.00% | 0 |
| 12s | m1d | joint_close | 63388 | 100.0% | 100.0% | 100.0% | 100.00% | 100.00% | 185 |
| 12s | m1d | joint_upgrade | 125522 | 100.0% | 100.0% | 38.5% | 0.00% | 0.00% | 0 |
| 12s | m1d | joint_downgrade | 55745 | 100.0% | 100.0% | 99.9% | 99.66% | 99.66% | 119 |
| 12s | m1d | joint_swap | 52686 | 100.0% | 100.0% | 83.4% | 26.78% | 26.78% | 5 |
| 12s | m1d_global_asg | transfer | 1000282 | 100.0% | 59.2% | 57.5% | 25.18% | 42.53% | 515 |
| 12s | m1d_global_asg | drone_reassign | 624953 | 100.0% | 71.0% | 66.0% | 25.97% | 36.57% | 329 |
| 12s | m1d_global_asg | joint_open | 241150 | 100.0% | 100.0% | 26.2% | 0.00% | 0.00% | 0 |
| 12s | m1d_global_asg | joint_close | 65208 | 100.0% | 100.0% | 100.0% | 100.00% | 100.00% | 204 |
| 12s | m1d_global_asg | joint_upgrade | 125869 | 100.0% | 100.0% | 37.4% | 0.00% | 0.00% | 0 |
| 12s | m1d_global_asg | joint_downgrade | 54792 | 100.0% | 100.0% | 99.9% | 99.49% | 99.49% | 123 |
| 12s | m1d_global_asg | joint_swap | 53606 | 100.0% | 100.0% | 82.2% | 19.93% | 19.93% | 6 |
| 12s | m2 | transfer | 643312 | 100.0% | 100.0% | 70.1% | 10.47% | 10.47% | 35 |
| 12s | m2 | drone_reassign | 713151 | 100.0% | 100.0% | 67.8% | 10.83% | 10.83% | 84 |
| 12s | m2 | joint_open | 167048 | 100.0% | 100.0% | 36.1% | 0.00% | 0.00% | 0 |
| 12s | m2 | joint_close | 66437 | 100.0% | 100.0% | 100.0% | 100.00% | 100.00% | 209 |
| 12s | m2 | joint_upgrade | 115390 | 100.0% | 100.0% | 43.5% | 0.00% | 0.00% | 0 |
| 12s | m2 | joint_downgrade | 42236 | 100.0% | 100.0% | 99.9% | 99.24% | 99.24% | 123 |
| 12s | m2 | joint_swap | 42125 | 100.0% | 100.0% | 73.2% | 12.48% | 12.48% | 7 |
| 12s | m2_global_asg | transfer | 777260 | 100.0% | 60.1% | 56.4% | 19.40% | 32.30% | 276 |
| 12s | m2_global_asg | drone_reassign | 1089536 | 100.0% | 73.7% | 62.7% | 18.62% | 25.24% | 312 |
| 12s | m2_global_asg | joint_open | 179187 | 100.0% | 100.0% | 34.4% | 0.00% | 0.00% | 0 |
| 12s | m2_global_asg | joint_close | 66474 | 100.0% | 100.0% | 100.0% | 100.00% | 100.00% | 187 |
| 12s | m2_global_asg | joint_upgrade | 116340 | 100.0% | 100.0% | 42.0% | 0.00% | 0.00% | 0 |
| 12s | m2_global_asg | joint_downgrade | 42357 | 100.0% | 100.0% | 100.0% | 99.16% | 99.16% | 120 |
| 12s | m2_global_asg | joint_swap | 37411 | 100.0% | 100.0% | 74.2% | 10.51% | 10.51% | 5 |

## Global vs local Assignment improvement yield

| Budget | Controller | Operator | Local improved/attempt | Global improved/attempt | Yield ratio | Local changed % | Global changed % |
|---:|---|---|---:|---:|---:|---:|---:|
| 6s | m1d | transfer | 16.87% | 24.93% | 1.48x | 100.0% | 58.9% |
| 6s | m1d | drone_reassign | 13.35% | 25.82% | 1.93x | 100.0% | 70.8% |
| 6s | m2 | transfer | 10.33% | 19.32% | 1.87x | 100.0% | 59.7% |
| 6s | m2 | drone_reassign | 10.85% | 18.56% | 1.71x | 100.0% | 73.7% |
| 12s | m1d | transfer | 16.84% | 25.18% | 1.50x | 100.0% | 59.2% |
| 12s | m1d | drone_reassign | 13.45% | 25.97% | 1.93x | 100.0% | 71.0% |
| 12s | m2 | transfer | 10.47% | 19.40% | 1.85x | 100.0% | 60.1% |
| 12s | m2 | drone_reassign | 10.83% | 18.62% | 1.72x | 100.0% | 73.7% |

## Interpretation

- Improved/attempt is the fraction of selected operator attempts that produce an accepted incumbent-cost improvement; it is not the probability that an arbitrary candidate is globally optimal.
- Global receiver scope can increase improvement yield while also producing more no-change candidates, because a target may be reinserted into its original assignment.
- Joint open/upgrade actions may be accepted without immediate improvement because they alter fixed station costs and can create future structural opportunities. Do not interpret zero immediate improvement yield as proof that these actions are useless.
- Use the paired map-level cost analysis for statistical claims; use these counters only to explain search behavior.
