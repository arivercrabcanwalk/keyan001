# BC Global repair state/mask/family ablation (6s validation)

All methods use global Assignment repair. The BC checkpoints were trained under the local-scope regime; this is a transfer/ablation diagnostic, not a claim of matched-global training.

## Method summary

| Method | Mean cost | Median | SD | Feasibility | Solver s | End-to-end s | Tasks |
|---|---:|---:|---:|---:|---:|---:|---:|
| m2_global_asg | 457.2536 | 361.5166 | 263.8277 | 100.0% | 6.000 | 6.012 | 216 |
| m6_global_asg | 457.3798 | 361.5166 | 263.9668 | 100.0% | 6.000 | 6.071 | 216 |
| m6_global_nojoint | 457.7549 | 361.5166 | 264.2257 | 100.0% | 6.000 | 6.070 | 216 |
| m6_global_nomask | 457.4810 | 361.5166 | 264.0882 | 100.0% | 6.000 | 6.049 | 216 |
| m6_global_zeroasg | 457.4449 | 361.5166 | 263.9654 | 100.0% | 6.000 | 6.012 | 216 |
| m6_global_zerodrone | 457.5582 | 361.5166 | 264.1254 | 100.0% | 6.000 | 6.012 | 216 |
| m6_global_zerohist | 457.2581 | 361.5166 | 263.6967 | 100.0% | 6.000 | 6.012 | 216 |
| m6_global_zeroglobal | 457.4841 | 361.5166 | 263.9404 | 100.0% | 6.000 | 6.012 | 216 |
| m6_global_nohighint | 457.4797 | 361.5166 | 264.0764 | 100.0% | 6.000 | 6.012 | 216 |

## Paired comparisons

Positive delta means higher/worse cost. One 15-test Holm family covers seven ablations vs full BC and eight learned methods vs M2 Global.

| Candidate | Reference | Mean delta % | 95% CI | W/L/T | Wilcoxon p | Holm p |
|---|---|---:|---:|---:|---:|---:|
| m6_global_nojoint | m6_global_asg | +0.0585% | [-0.0091, +0.1655] | 5/8/11 | 0.3054 | 1 |
| m6_global_nomask | m6_global_asg | +0.0139% | [-0.0012, +0.0320] | 4/10/10 | 0.1189 | 1 |
| m6_global_zeroasg | m6_global_asg | +0.0131% | [-0.0119, +0.0428] | 4/9/11 | 0.3396 | 1 |
| m6_global_zerodrone | m6_global_asg | +0.0257% | [-0.0079, +0.0673] | 6/7/11 | 0.3396 | 1 |
| m6_global_zerohist | m6_global_asg | -0.0103% | [-0.0394, +0.0162] | 6/9/9 | 0.7197 | 1 |
| m6_global_zeroglobal | m6_global_asg | +0.0215% | [-0.0091, +0.0570] | 4/9/11 | 0.3054 | 1 |
| m6_global_nohighint | m6_global_asg | +0.0144% | [-0.0095, +0.0350] | 4/10/10 | 0.104 | 1 |
| m6_global_asg | m2_global_asg | +0.0185% | [-0.0266, +0.0615] | 4/9/11 | 0.3054 | 1 |
| m6_global_nojoint | m2_global_asg | +0.0770% | [-0.0014, +0.1960] | 5/7/12 | 0.2661 | 1 |
| m6_global_nomask | m2_global_asg | +0.0324% | [-0.0228, +0.0874] | 4/9/11 | 0.2163 | 1 |
| m6_global_zeroasg | m2_global_asg | +0.0315% | [+0.0010, +0.0644] | 2/11/11 | 0.05737 | 0.8032 |
| m6_global_zerodrone | m2_global_asg | +0.0441% | [+0.0054, +0.0848] | 3/9/12 | 0.05225 | 0.7837 |
| m6_global_zerohist | m2_global_asg | +0.0081% | [-0.0308, +0.0394] | 2/12/10 | 0.1189 | 1 |
| m6_global_zeroglobal | m2_global_asg | +0.0399% | [+0.0003, +0.0829] | 3/10/11 | 0.05737 | 0.8032 |
| m6_global_nohighint | m2_global_asg | +0.0328% | [-0.0101, +0.0744] | 2/11/11 | 0.09424 | 1 |

## Interpretation limits

- This experiment uses the 24-map development validation split, not a blind test set.
- BC models were trained with local repair; all evaluations here use global Assignment repair.
- Runtime reward ablation requires retraining under a different reward and is not included.
- GNN is deferred; no GNN superiority claim is made.
