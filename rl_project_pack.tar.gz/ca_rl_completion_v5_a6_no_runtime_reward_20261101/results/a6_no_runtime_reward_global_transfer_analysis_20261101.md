# A6 no-runtime-reward PPO — Global Assignment validation

24-map development validation only. Positive delta means A6 PPO has higher/worse cost.

## Training audit

- Seed 11: PASS; best stochastic validation cost=457.9772; training seconds=178.4; source=4b85702035da04972cc5cde4deea61f9f50b4e4e232bd66173a82dbe72d5ba29
- Seed 23: PASS; best stochastic validation cost=458.1532; training seconds=179.2; source=4b85702035da04972cc5cde4deea61f9f50b4e4e232bd66173a82dbe72d5ba29
- Seed 37: PASS; best stochastic validation cost=458.3637; training seconds=178.3; source=4b85702035da04972cc5cde4deea61f9f50b4e4e232bd66173a82dbe72d5ba29

## Paired comparisons

| Budget | Reference | Mean relative delta | 95% CI | W/L/T | Wilcoxon p | Holm p |
|---:|---|---:|---:|---:|---:|---:|
| 6s | M2_Global_Assignment | +0.0590% | [+0.0007, +0.1110]% | 1/12/11 | 0.02148 | 0.06445 |
| 6s | PPO_reward_v2 | -0.0056% | [-0.0397, +0.0203]% | 6/7/11 | 1 | 1 |
| 12s | M2_Global_Assignment | +0.0400% | [+0.0035, +0.0779]% | 1/11/12 | 0.01611 | 0.06445 |
| 12s | PPO_reward_v2 | -0.0160% | [-0.0413, +0.0064]% | 7/5/12 | 0.2661 | 0.5322 |

## Interpretation

- A6 removes only the explicit operator-time reward penalty; elapsed-time SMDP GAE remains.
- The policy is trained on the same 72 train maps and selected on the same 24 validation maps as reward-v2 PPO.
- A6 is compared with M2 Global Assignment using the same A6 source, evaluator, initial-solution protocol, paired solver seeds and wall-clock budget. M2 is run without a PPO model path; the first mixed batch's M2 rows are preserved but excluded.
- A6 vs reward-v2 PPO is paired by the same maps and solver seeds; source hashes differ for the intentional reward/training-schema intervention and the explicit BC warm-start schema gate.
- This validation result does not establish RL independent contribution unless A6 beats M2 with meaningful corrected evidence.
