# V5 BC/PPO training artifact audit

Result: PASS

- Training maps per seed: 72
- Validation maps per seed: 24
- Shared training source SHA256: ba402a4d96d176cf3264790540f2882384a6deb161efe628efc892fa4fa339d8

| Seed | BC records | PPO updates | Validation checks | Best validation cost | Best iteration | Final validation cost |
|---:|---:|---:|---:|---:|---:|---:|
| 11 | 1177444 | 60 | 12 | 458.038650 | 20 | 458.789845 |
| 23 | 1245492 | 60 | 12 | 458.010150 | 5 | 458.626042 |
| 37 | 1235708 | 60 | 12 | 458.267774 | 55 | 458.699836 |
