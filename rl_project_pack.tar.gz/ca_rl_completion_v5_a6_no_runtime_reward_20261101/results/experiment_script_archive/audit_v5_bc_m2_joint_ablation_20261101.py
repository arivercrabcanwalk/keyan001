#!/usr/bin/env python3
"""Independent strict audit for BC Global ablations and M2 Global NoJoint."""
import collections
import hashlib
import json
from pathlib import Path

ROOT = Path("/root/rivermind-data/ca_rl_completion_v5_staging/code")
RES = ROOT / "results"
BC_METHODS = [
    "m2_global_asg", "m6_global_asg", "m6_global_nojoint",
    "m6_global_nomask", "m6_global_zeroasg", "m6_global_zerodrone",
    "m6_global_zerohist", "m6_global_zeroglobal", "m6_global_nohighint",
]
BC_SEEDS = {11: [101, 102, 103], 23: [104, 105, 106], 37: [107, 108, 109]}
M2_METHODS = ["m2_global_asg", "m2_global_nojoint"]
M2_SEEDS = list(range(201, 211))


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def task_rows(directory):
    return sorted(
        p for p in directory.glob("*.json")
        if p.name != "manifest.json" and not p.name.endswith(".error.json")
    )


def audit_bc():
    batches = {}
    all_code = set()
    total = 0
    for model_seed, solver_seeds in BC_SEEDS.items():
        d = RES / f"v5_bc_global_ablation_6s_s{model_seed}"
        manifest = json.loads((d / "manifest.json").read_text())
        rows = task_rows(d)
        errors = list(d.glob("*.error.json"))
        solutions = list(d.glob("*.solution.json.gz"))
        counts = collections.Counter()
        by_method = collections.Counter()
        by_seed = collections.Counter()
        maps, task_ids, code_hashes, model_hashes = set(), set(), set(), set()
        for path in rows:
            row = json.loads(path.read_text())
            prov = row.get("provenance") or {}
            counts["status_ok"] += row.get("status") == "ok"
            counts["feasible"] += row.get("feasible") is True
            counts["global_assignment"] += row.get("repair_scope_mode") == "global_assignment"
            counts["solver_seed_valid"] += row.get("seed") in solver_seeds
            counts["model_hash_present"] += bool(prov.get("model_sha256"))
            counts["code_hash_present"] += bool(prov.get("code_sha256"))
            by_method[row.get("method")] += 1
            by_seed[row.get("seed")] += 1
            maps.add(row.get("instance"))
            task_ids.add(row.get("task_identity"))
            if prov.get("code_sha256"):
                code_hashes.add(prov["code_sha256"])
            if prov.get("model_sha256"):
                model_hashes.add(prov["model_sha256"])
        checkpoint = ROOT.parent / "training_runs_v5_final72" / f"BC_seed{model_seed}" / "bc.pt"
        checkpoint_hash = sha(checkpoint)
        manifest_ok = (
            manifest.get("methods") == BC_METHODS
            and manifest.get("seeds") == solver_seeds
            and len(manifest.get("instances", [])) == 24
            and manifest.get("tasks") == 648
            and manifest.get("seconds") == 6.0
            and manifest.get("errors") == 0
            and bool(manifest.get("finished"))
        )
        checks_ok = (
            len(rows) == 648 and len(solutions) == 648 and not errors
            and len(maps) == 24 and len(task_ids) == 648
            and len(code_hashes) == 1 and model_hashes == {checkpoint_hash}
            and all(counts[k] == 648 for k in (
                "status_ok", "feasible", "global_assignment",
                "solver_seed_valid", "model_hash_present", "code_hash_present"
            ))
            and by_method == collections.Counter({m: 72 for m in BC_METHODS})
            and manifest_ok
        )
        batches[str(model_seed)] = {
            "pass": checks_ok, "manifest_pass": manifest_ok,
            "rows": len(rows), "solution_files": len(solutions),
            "error_files": len(errors), "map_count": len(maps),
            "unique_task_ids": len(task_ids), "row_checks": dict(counts),
            "method_counts": dict(by_method), "solver_seed_counts": dict(by_seed),
            "code_sha256": sorted(code_hashes),
            "model_sha256": sorted(model_hashes),
            "checkpoint_sha256": checkpoint_hash,
            "model_hash_matches_checkpoint": model_hashes == {checkpoint_hash},
        }
        all_code |= code_hashes
        total += len(rows)
    analysis = json.loads((RES / "v5_bc_global_ablation_6s_analysis.json").read_text())
    analysis_ok = (
        analysis.get("status") == "development_validation_only"
        and analysis.get("tasks") == 1944
        and analysis.get("code_sha256") in all_code
        and all(v.get("n_tasks") == 216 and v.get("feasibility_rate") == 1.0
                for v in analysis.get("methods", {}).values())
        and len(analysis.get("comparisons", [])) == 15
    )
    return {
        "pass": total == 1944 and len(all_code) == 1
                and all(x["pass"] for x in batches.values()) and analysis_ok,
        "total_rows": total, "unique_code_hashes": sorted(all_code),
        "batches": batches, "analysis_pass": analysis_ok,
        "analysis_json_sha256": sha(RES / "v5_bc_global_ablation_6s_analysis.json"),
        "analysis_markdown_sha256": sha(RES / "v5_bc_global_ablation_6s_analysis.md"),
    }


def audit_m2():
    batches = {}
    all_code = set()
    for budget in (6, 12):
        d = RES / f"v5_m2_global_nojoint_10seed_{budget}s"
        manifest = json.loads((d / "manifest.json").read_text())
        rows = task_rows(d)
        errors = list(d.glob("*.error.json"))
        solutions = list(d.glob("*.solution.json.gz"))
        counts = collections.Counter()
        methods = collections.Counter()
        seeds = collections.Counter()
        maps, task_ids, code_hashes = set(), set(), set()
        family_totals = {
            method: {k: [0, 0, 0, 0] for k in (
                "family_attempts", "family_feasible", "family_accepted", "family_improved"
            )} | {"joint_selected_operator_count": 0, "joint_tagged_operator_attempts": 0}
            for method in M2_METHODS
        }
        for path in rows:
            row = json.loads(path.read_text())
            prov = row.get("provenance") or {}
            method = row.get("method")
            counters = row.get("counters") or {}
            counts["status_ok"] += row.get("status") == "ok"
            counts["feasible"] += row.get("feasible") is True
            counts["global_assignment"] += row.get("repair_scope_mode") == "global_assignment"
            counts["solver_seed_valid"] += row.get("seed") in M2_SEEDS
            counts["code_hash_present"] += bool(prov.get("code_sha256"))
            methods[method] += 1
            seeds[row.get("seed")] += 1
            maps.add(row.get("instance"))
            task_ids.add(row.get("task_identity"))
            if prov.get("code_sha256"):
                code_hashes.add(prov["code_sha256"])
            if method in family_totals:
                agg = family_totals[method]
                for key in ("family_attempts", "family_feasible", "family_accepted", "family_improved"):
                    values = counters.get(key, [])
                    if len(values) != 4:
                        counts["invalid_family_vector"] += 1
                    else:
                        agg[key] = [a + int(b) for a, b in zip(agg[key], values)]
                selected = counters.get("selected_operator_counts", [])
                if len(selected) != 17:
                    counts["invalid_operator_vector"] += 1
                else:
                    agg["joint_selected_operator_count"] += sum(selected[12:17])
                agg["joint_tagged_operator_attempts"] += sum(
                    int(v) for k, v in (counters.get("operator_attempts") or {}).items()
                    if str(k).startswith("joint_")
                )
        manifest_ok = (
            manifest.get("methods") == M2_METHODS
            and manifest.get("seeds") == M2_SEEDS
            and len(manifest.get("instances", [])) == 24
            and manifest.get("tasks") == 480
            and manifest.get("seconds") == float(budget)
            and manifest.get("errors") == 0
            and bool(manifest.get("finished"))
        )
        nojoint = family_totals["m2_global_nojoint"]
        full = family_totals["m2_global_asg"]
        nojoint_excluded = (
            nojoint["family_attempts"][3] == 0
            and nojoint["family_feasible"][3] == 0
            and nojoint["family_accepted"][3] == 0
            and nojoint["family_improved"][3] == 0
            and nojoint["joint_selected_operator_count"] == 0
            and nojoint["joint_tagged_operator_attempts"] == 0
        )
        full_joint_active = (
            full["family_attempts"][3] > 0
            and full["joint_selected_operator_count"] > 0
            and full["joint_tagged_operator_attempts"] > 0
        )
        batch_pass = (
            manifest_ok and len(rows) == 480 and len(solutions) == 480 and not errors
            and len(maps) == 24 and len(task_ids) == 480 and len(seeds) == 10
            and methods == collections.Counter({m: 240 for m in M2_METHODS})
            and len(code_hashes) == 1
            and all(counts[k] == 480 for k in (
                "status_ok", "feasible", "global_assignment",
                "solver_seed_valid", "code_hash_present"
            ))
            and nojoint_excluded and full_joint_active
            and not counts["invalid_family_vector"] and not counts["invalid_operator_vector"]
        )
        batches[str(budget)] = {
            "pass": batch_pass, "manifest_pass": manifest_ok,
            "rows": len(rows), "solution_files": len(solutions),
            "error_files": len(errors), "map_count": len(maps),
            "unique_task_ids": len(task_ids), "unique_solver_seeds": len(seeds),
            "row_checks": dict(counts), "method_counts": dict(methods),
            "code_sha256": sorted(code_hashes),
            "effective_family_totals": family_totals,
            "nojoint_excludes_family_3": nojoint_excluded,
            "full_m2_uses_family_3": full_joint_active,
        }
        all_code |= code_hashes
    analysis_path = RES / "v5_m2_global_nojoint_10seed_analysis.json"
    analysis = json.loads(analysis_path.read_text())
    analysis_ok = (
        analysis.get("status") == "development_validation_only"
        and analysis.get("source_sha256") in all_code
        and len(analysis.get("comparisons", [])) == 2
        and all(c.get("n_maps") == 24 and c.get("holm_adjusted_p_2_test_family") is not None
                for c in analysis.get("comparisons", []))
    )
    return {
        "pass": len(all_code) == 1 and all(x["pass"] for x in batches.values())
                and analysis_ok,
        "unique_code_hashes_6s_12s": sorted(all_code),
        "batches": batches, "analysis_pass": analysis_ok,
        "analysis_json_sha256": sha(analysis_path),
        "analysis_markdown_sha256": sha(RES / "v5_m2_global_nojoint_10seed_analysis.md"),
    }


def main():
    import datetime
    payload = {
        "schema": "v5_bc_m2_joint_ablation_acceptance_audit_v1",
        "audit_timestamp_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "script_sha256": sha(Path(__file__)),
        "bc_global_ablation": audit_bc(),
        "m2_global_nojoint": audit_m2(),
    }
    payload["overall_pass"] = (
        payload["bc_global_ablation"]["pass"]
        and payload["m2_global_nojoint"]["pass"]
    )
    out_json = RES / "v5_bc_m2_joint_ablation_acceptance_audit_20261101.json"
    out_md = RES / "v5_bc_m2_joint_ablation_acceptance_audit_20261101.md"
    out_json.write_text(json.dumps(payload, indent=2) + "\n")
    lines = [
        "# BC Global + M2 Global NoJoint — independent acceptance audit",
        "",
        f"Audit UTC: {payload['audit_timestamp_utc']}",
        f"Overall: {'PASS' if payload['overall_pass'] else 'FAIL'}",
        "",
        "## BC Global ablation",
        "",
        f"- Status: {'PASS' if payload['bc_global_ablation']['pass'] else 'FAIL'}",
        f"- Rows: {payload['bc_global_ablation']['total_rows']}/1944",
        f"- Source hashes: {payload['bc_global_ablation']['unique_code_hashes']}",
        "- Three model seeds each passed manifest, 648-row, 648-solution, feasibility, repair-scope, task-identity and checkpoint-hash checks.",
        "",
        "## M2 Global NoJoint",
        "",
        f"- Status: {'PASS' if payload['m2_global_nojoint']['pass'] else 'FAIL'}",
        f"- Source hashes across 6s/12s: {payload['m2_global_nojoint']['unique_code_hashes_6s_12s']}",
        "- Both budgets passed 480-row, 480-solution, 24-map, 10-seed, feasibility, status and repair-scope checks.",
        "- Effective NoJoint exclusion was verified from raw counters: family-3 attempts/feasible/accepted/improved and operator IDs 12–16 were all zero.",
        "- Full M2 Global Assignment retained nonzero family-3 activity in both budgets.",
        "",
        "## Paired development results",
        "",
        "| Budget | NoJoint relative cost delta | 95% CI | Wilcoxon p | Holm p |",
        "|---:|---:|---:|---:|---:|",
    ]
    a = json.loads((RES / "v5_m2_global_nojoint_10seed_analysis.json").read_text())
    for c in a["comparisons"]:
        ci = c["bootstrap95_delta_percent"]
        lines.append(
            f"| {c['budget_seconds']}s | {c['mean_delta_percent']:+.4f}% "
            f"| [{ci[0]:+.4f}, {ci[1]:+.4f}]% | {c['wilcoxon_p_raw']:.4g} "
            f"| {c['holm_adjusted_p_2_test_family']:.4g} |"
        )
    lines += [
        "",
        "## Interpretation boundary",
        "",
        "- These are 24-map development-validation results, not formal blind-test evidence.",
        "- BC checkpoints were trained under Local repair and evaluated with Global Assignment repair; BC feature zeroing is inference-time sensitivity analysis, not retrained causal ablation.",
        "- M2 NoJoint is a true family-3 exclusion according to raw execution counters, but its paired cost contrasts do not establish a significant Joint-family marginal benefit.",
        "- No RL independent gain is established by these experiments.",
        "",
        f"Audit script SHA256: {payload['script_sha256']}",
    ]
    out_md.write_text("\n".join(lines) + "\n")
    print(out_md.read_text())
    print("JSON:", out_json)
    print("OVERALL_PASS:", payload["overall_pass"])
    if not payload["overall_pass"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
