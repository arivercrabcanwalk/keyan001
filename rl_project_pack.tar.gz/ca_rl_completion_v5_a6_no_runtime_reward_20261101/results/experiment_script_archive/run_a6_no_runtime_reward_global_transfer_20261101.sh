#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
OUT="../training_runs_v5_a6_no_runtime_reward_20261101"
[ -f "$OUT/A6_TRAINING_COMPLETED" ] || { echo "A6 training marker missing" >&2; exit 20; }
for budget in 6 12; do
  for seed in 11 23 37; do
    case "$seed" in
      11) solver_seeds=101,102,103 ;;
      23) solver_seeds=104,105,106 ;;
      37) solver_seeds=107,108,109 ;;
    esac
    model="$OUT/PPO_seed$seed/best.pt"
    if [ "$budget" = "6" ] && [ "$seed" = "11" ]; then
      mixed="results/a6_no_runtime_reward_global_transfer_6s_s11_mixed_unused_m2_model_binding"
      [ -d "$mixed" ] || { echo "preserved first batch missing: $mixed" >&2; exit 23; }
      /opt/conda/bin/python - "$mixed" <<'PY'
import json,sys
from pathlib import Path
d=Path(sys.argv[1]); m=json.loads((d/"manifest.json").read_text())
rows=[json.loads(p.read_text()) for p in d.glob("*.json") if p.name!="manifest.json" and not p.name.endswith(".error.json")]
assert m.get("finished") is not None and m.get("errors")==0 and m.get("seconds")==6.0
assert m.get("methods")==["m2_global_asg","m6_global_asg"] and m.get("tasks")==144
assert sum(r.get("method")=="m6_global_asg" for r in rows)==72
assert all(r.get("status")=="ok" and r.get("feasible") is True for r in rows)
print("Reusing 72 A6 PPO rows from preserved first batch; mixed M2 rows excluded.")
PY
    else
      ppo_out="results/a6_no_runtime_reward_ppo_global_transfer_${budget}s_s${seed}"
      [ ! -e "$ppo_out" ] || { echo "PPO output exists; inspect: $ppo_out" >&2; exit 24; }
      echo "[A6_PPO_EVAL] budget=${budget}s model_seed=${seed} solver_seeds=$solver_seeds"
      /opt/conda/bin/python -B scripts/run_bench.py \
        --instances val --methods m6_global_asg \
        --seeds "$solver_seeds" --seconds "$budget" --workers 8 \
        --ppo-model "$model" --out "$ppo_out"
    fi
    m2_out="results/a6_no_runtime_reward_m2_global_transfer_${budget}s_s${seed}"
    [ ! -e "$m2_out" ] || { echo "M2 output exists; inspect: $m2_out" >&2; exit 25; }
    echo "[A6_M2_EVAL] budget=${budget}s model_seed=${seed} solver_seeds=$solver_seeds"
    /opt/conda/bin/python -B scripts/run_bench.py \
      --instances val --methods m2_global_asg \
      --seeds "$solver_seeds" --seconds "$budget" --workers 8 \
      --out "$m2_out"
  done
done
echo "A6_EVALUATION_BATCHES_COMPLETED"
