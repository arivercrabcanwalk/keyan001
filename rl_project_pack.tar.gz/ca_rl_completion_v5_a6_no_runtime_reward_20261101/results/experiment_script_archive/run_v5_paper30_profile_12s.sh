#!/usr/bin/env bash
set -euo pipefail
ROOT=/root/rivermind-data/ca_rl_completion_v5_staging/code
cd "$ROOT"
PY=/opt/conda/bin/python
OUT=results/v5_paper30_profile_12s
MANIFEST=results/paper30_original_case_manifest.json
[ ! -e "$OUT" ] || { echo "output exists; preserve and inspect: $OUT" >&2; exit 10; }
[ -f "$MANIFEST" ] || { echo "paper30 instance manifest missing" >&2; exit 11; }
INSTANCES=$("$PY" - "$MANIFEST" <<'PY'
import json,sys,hashlib
from pathlib import Path
root=Path("/root/rivermind-data/ca_rl_completion_v5_staging/code")
m=json.load(open(sys.argv[1]))
rows=m.get("rows",[])
if len(rows)!=30: raise SystemExit("paper30 manifest must have exactly 30 cases")
for r in rows:
 p=root/"external/LRPHSD/data/Instances_Alg"/(r["name"]+".txt")
 if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=r["sha256"]:
  raise SystemExit("paper30 instance hash mismatch: "+r["name"])
print(",".join(r["name"] for r in rows))
PY
)
echo "[PAPER30] 30 original cases x 2 parameter profiles x 5 seeds = 300 tasks; 12s budget"
"$PY" -B scripts/run_bench.py --instances "$INSTANCES" --methods m0paper,m0frozen \
  --seeds 1,2,3,4,5 --seconds 12 --workers 8 --out "$OUT"
"$PY" -B results/experiment_script_archive/analyze_v5_paper30_profile.py
printf "V5_PAPER30_PROFILE_COMPLETE\n" > results/V5_PAPER30_PROFILE_COMPLETE
echo "V5_PAPER30_PROFILE_COMPLETE"
