#!/usr/bin/env python3
"""Full-search comparison of local, Assignment-global, Joint-global and all-global repair."""
import json
import sys
from pathlib import Path
from collections import defaultdict

import numpy as np

ROOT = Path("/root/rivermind-data/ca_rl_completion_v5_staging/code")
RESULTS = ROOT / "results"
sys.path.insert(0, str(ROOT))
from carl.stats import wilcoxon_signed_rank, holm

METHODS = (
    "m1d", "m1d_global_asg", "m1d_global_joint", "m1d_global_all",
    "m2", "m2_global_asg", "m2_global_joint", "m2_global_all",
)
SEEDS = list(range(101, 106))
CONTROLLERS = ("m1d", "m2")
MODES = ("local", "global_assignment", "global_joint", "global_assignment_joint")
METHOD_BY = {
    ("m1d", "local"): "m1d",
    ("m1d", "global_assignment"): "m1d_global_asg",
    ("m1d", "global_joint"): "m1d_global_joint",
    ("m1d", "global_assignment_joint"): "m1d_global_all",
    ("m2", "local"): "m2",
    ("m2", "global_assignment"): "m2_global_asg",
    ("m2", "global_joint"): "m2_global_joint",
    ("m2", "global_assignment_joint"): "m2_global_all",
}


def read_rows(directory):
    rows = []
    for p in sorted(Path(directory).glob("*__s*.json")):
        with open(p) as f:
            rows.append(json.load(f))
    return rows


def aggregate(rows, method):
    grouped = defaultdict(list)
    for r in rows:
        if r["method"] == method:
            grouped[r["instance"]].append(float(r["cost"]))
    return {k: float(np.mean(v)) for k, v in grouped.items()}


def bootstrap_ci(delta, seed, n_boot=20000):
    x = np.asarray(delta, dtype=float)
    rng = np.random.default_rng(seed)
    idx = rng.integers(0, len(x), size=(n_boot, len(x)))
    m = x[idx].mean(axis=1)
    return [float(np.quantile(m, .025)), float(np.quantile(m, .975))]


def compare(candidate, reference, seed):
    names = sorted(set(candidate) & set(reference))
    x = np.asarray([candidate[n] for n in names], dtype=float)
    y = np.asarray([reference[n] for n in names], dtype=float)
    d = 100.0 * (x / y - 1.0)
    st = wilcoxon_signed_rank(x, y)
    return {
        "n_maps": len(names),
        "mean_delta_percent": float(d.mean()),
        "median_delta_percent": float(np.median(d)),
        "wins_candidate_lower": int((d < -1e-9).sum()),
        "wins_reference_lower": int((d > 1e-9).sum()),
        "ties": int((np.abs(d) <= 1e-9).sum()),
        "wilcoxon_p_raw": float(st["p_value"]),
        "rank_biserial": float(st.get("rank_biserial", 0.0)),
        "bootstrap95_delta_percent": bootstrap_ci(d, seed),
    }


def joint_operator_diagnostics(rows, method):
    fields = ("operator_attempts", "operator_feasible", "operator_changed",
              "operator_no_change", "operator_accepted", "operator_improved",
              "operator_best")
    totals = {field: defaultdict(int) for field in fields}
    selected = [0] * 17
    for row in rows:
        if row["method"] != method:
            continue
        counters = row.get("counters") or {}
        for i, value in enumerate(counters.get("selected_operator_counts", [])):
            if i < 17:
                selected[i] += int(value)
        for field in fields:
            for tag, value in (counters.get(field) or {}).items():
                if tag.startswith("joint_"):
                    totals[field][tag] += int(value)
    tags = sorted(totals["operator_attempts"])
    summary = {}
    for tag in tags:
        attempts = totals["operator_attempts"][tag]
        record = {"attempts": attempts}
        for field in fields[1:]:
            record[field.replace("operator_", "")] = totals[field][tag]
        record["improved_rate_percent"] = (
            100.0 * record["improved"] / attempts if attempts else None)
        record["changed_rate_percent"] = (
            100.0 * record["changed"] / attempts if attempts else None)
        summary[tag] = record
    return {
        "selected_operator_counts_12_to_16": selected[12:17],
        "tags": summary,
    }


def load_budget(budget):
    d = RESULTS / f"v5_joint_scope_full_search_{budget}s"
    m = json.loads((d / "manifest.json").read_text())
    if (m.get("finished") is None or m.get("errors") != 0
            or m.get("methods") != list(METHODS)
            or m.get("seeds") != SEEDS
            or len(m.get("instances", [])) != 24
            or m.get("tasks") != 24 * 5 * len(METHODS)
            or float(m.get("seconds", -1)) != float(budget)):
        raise RuntimeError(f"manifest mismatch: {d}")
    rows = read_rows(d)
    if len(rows) != 24 * 5 * len(METHODS):
        raise RuntimeError(f"wrong result count: {d}")
    hashes = set()
    for r in rows:
        if r.get("status") != "ok" or r.get("feasible") is not True:
            raise RuntimeError(f"invalid/infeasible result in {d}")
        expected = {
            "m1d": "local", "m2": "local",
            "m1d_global_asg": "global_assignment", "m2_global_asg": "global_assignment",
            "m1d_global_joint": "global_joint", "m2_global_joint": "global_joint",
            "m1d_global_all": "global_assignment_joint", "m2_global_all": "global_assignment_joint",
        }[r["method"]]
        if r.get("repair_scope_mode") != expected:
            raise RuntimeError(f"wrong repair mode in {d}: {r['method']} {r.get('repair_scope_mode')}")
        hashes.add((r.get("provenance") or {}).get("code_sha256"))
    if len(hashes) != 1 or None in hashes:
        raise RuntimeError(f"mixed source hashes in {d}")
    return rows, next(iter(hashes)), m


def main():
    payload = {
        "schema": "v5_global_joint_scope_full_search_analysis_v1",
        "methods": list(METHODS),
        "statistical_unit": "map; five solver seeds averaged within each map",
        "budgets": {},
        "scope_comparisons": [],
        "controller_comparisons": [],
    }
    p_scope, p_controller = [], []
    for budget in (6, 12):
        rows, code_hash, manifest = load_budget(budget)
        info = {"source_sha256": code_hash, "manifest": manifest, "methods": {}}
        maps = {m: aggregate(rows, m) for m in METHODS}
        for method in METHODS:
            mr = [r for r in rows if r["method"] == method]
            info["methods"][method] = {
                "mean_cost": float(np.mean([r["cost"] for r in mr])),
                "median_cost": float(np.median([r["cost"] for r in mr])),
                "std_cost": float(np.std([r["cost"] for r in mr], ddof=1)),
                "feasibility_rate": float(np.mean([r["feasible"] for r in mr])),
                "mean_solver_seconds": float(np.mean([r["solver_seconds"] for r in mr])),
                "mean_end_to_end_seconds": float(np.mean([r["end_to_end_seconds"] for r in mr])),
                "mean_steps": float(np.mean([r["steps"] for r in mr])),
            }
        info["joint_operator_behavior"] = {
            method: joint_operator_diagnostics(rows, method) for method in METHODS
        }
        payload["budgets"][str(budget)] = info

        for ci, controller in enumerate(CONTROLLERS):
            base = maps[METHOD_BY[(controller, "local")]]
            asg = maps[METHOD_BY[(controller, "global_assignment")]]
            joint = maps[METHOD_BY[(controller, "global_joint")]]
            all_scope = maps[METHOD_BY[(controller, "global_assignment_joint")]]
            pairs = (
                ("global_assignment_vs_local", asg, base),
                ("global_joint_vs_local", joint, base),
                ("global_assignment_joint_vs_local", all_scope, base),
                ("global_assignment_joint_vs_global_assignment", all_scope, asg),
                ("global_assignment_joint_vs_global_joint", all_scope, joint),
            )
            for pi, (label, cand, ref) in enumerate(pairs):
                c = compare(cand, ref, 20261031 + budget * 100 + ci * 10 + pi)
                c.update({"budget_seconds": budget, "controller": controller, "comparison": label})
                payload["scope_comparisons"].append(c)
                p_scope.append(c["wilcoxon_p_raw"])

        for mode_i, mode in enumerate(MODES):
            c = compare(
                maps[METHOD_BY[("m1d", mode)]],
                maps[METHOD_BY[("m2", mode)]],
                20261101 + budget * 100 + mode_i)
            c.update({"budget_seconds": budget, "repair_mode": mode, "comparison": "M1D_vs_M2"})
            payload["controller_comparisons"].append(c)
            p_controller.append(c["wilcoxon_p_raw"])

    for records, pvals, field in (
        (payload["scope_comparisons"], p_scope, "holm_adjusted_p_20_test_family"),
        (payload["controller_comparisons"], p_controller, "holm_adjusted_p_8_test_family"),
    ):
        for r, p in zip(records, holm(pvals)):
            r[field] = float(p)

    out_json = RESULTS / "v5_global_joint_scope_analysis.json"
    out_md = RESULTS / "v5_global_joint_scope_analysis.md"
    out_json.write_text(json.dumps(payload, indent=2) + "\n")
    lines = [
        "# Full-search Joint-family receiver-scope experiment",
        "",
        "All eight methods were run under one source version. Only Assignment and/or Joint family receiver masks differ. All final outputs passed the independent evaluator.",
        "",
        "## Mean cost and feasibility",
        "",
        "| Budget | Method | Mean cost | Median | SD | Feasibility | Solver s | End-to-end s | Steps |",
        "|---:|---|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for b in (6, 12):
        for method in METHODS:
            s = payload["budgets"][str(b)]["methods"][method]
            lines.append(
                f"| {b}s | {method} | {s['mean_cost']:.4f} | {s['median_cost']:.4f} | "
                f"{s['std_cost']:.4f} | {s['feasibility_rate']:.1%} | "
                f"{s['mean_solver_seconds']:.3f} | {s['mean_end_to_end_seconds']:.3f} | "
                f"{s['mean_steps']:.1f} |")
    lines += [
        "",
        "## Joint operator behavior (descriptive counters)",
        "",
        "| Budget | Method | Selected op12–16 | Joint tag | Attempts | Changed % | Improved % |",
        "|---:|---|---|---|---:|---:|---:|",
    ]
    for b in (6, 12):
        for method in METHODS:
            diag = payload["budgets"][str(b)]["joint_operator_behavior"][method]
            selected = diag["selected_operator_counts_12_to_16"]
            for tag, stats in diag["tags"].items():
                lines.append(
                    f"| {b}s | {method} | {selected} | {tag} | {stats['attempts']} | "
                    f"{stats['changed_rate_percent']:.1f}% | "
                    f"{stats['improved_rate_percent']:.2f}% |")
    lines += [
        "",
        "## Repair-scope comparisons within each controller",
        "",
        "Negative delta favors the candidate mode. Twenty-test Holm family.",
        "",
        "| Budget | Controller | Comparison | Mean delta % | 95% CI | W/L/T maps | Wilcoxon p | Holm p |",
        "|---:|---|---|---:|---:|---:|---:|---:|",
    ]
    for c in payload["scope_comparisons"]:
        ci = c["bootstrap95_delta_percent"]
        lines.append(
            f"| {c['budget_seconds']}s | {c['controller']} | {c['comparison']} | "
            f"{c['mean_delta_percent']:+.4f}% | [{ci[0]:+.4f}, {ci[1]:+.4f}] | "
            f"{c['wins_candidate_lower']}/{c['wins_reference_lower']}/{c['ties']} | "
            f"{c['wilcoxon_p_raw']:.4g} | {c['holm_adjusted_p_20_test_family']:.4g} |")
    lines += [
        "",
        "## M1D vs M2 under each repair mode",
        "",
        "Negative delta means M1D has lower cost. Eight-test Holm family.",
        "",
        "| Budget | Repair mode | Mean delta % | 95% CI | W/L/T maps | Wilcoxon p | Holm p |",
        "|---:|---|---:|---:|---:|---:|---:|",
    ]
    for c in payload["controller_comparisons"]:
        ci = c["bootstrap95_delta_percent"]
        lines.append(
            f"| {c['budget_seconds']}s | {c['repair_mode']} | {c['mean_delta_percent']:+.4f}% | "
            f"[{ci[0]:+.4f}, {ci[1]:+.4f}] | {c['wins_candidate_lower']}/"
            f"{c['wins_reference_lower']}/{c['ties']} | {c['wilcoxon_p_raw']:.4g} | "
            f"{c['holm_adjusted_p_8_test_family']:.4g} |")
    out_md.write_text("\n".join(lines) + "\n")
    print("\n".join(lines))


if __name__ == "__main__":
    main()
