#!/usr/bin/env bash
set -euo pipefail
ROOT=/root/rivermind-data/ca_rl_completion_v5_staging/code
cd "$ROOT"
PY=/opt/conda/bin/python
METHODS=m2_global_asg,m2_global_nojoint
SEEDS=201,202,203,204,205,206,207,208,209,210
for budget in 6 12; do
  out="results/v5_m2_global_nojoint_10seed_${budget}s"
  [ ! -e "$out" ] || { echo "output exists; preserve and inspect: $out" >&2; exit 30; }
  echo "[M2_GLOBAL_NOJOINT] budget=${budget}s seeds=$SEEDS"
  "$PY" -B scripts/run_bench.py --instances val --methods "$METHODS" \
    --seeds "$SEEDS" --seconds "$budget" --workers 8 --out "$out"
done
"$PY" -B results/experiment_script_archive/analyze_v5_m2_global_nojoint_10seed.py
printf "V5_M2_GLOBAL_NOJOINT_10SEED_COMPLETE\n" > results/V5_M2_GLOBAL_NOJOINT_10SEED_COMPLETE
echo "V5_M2_GLOBAL_NOJOINT_10SEED_COMPLETE"
