#!/usr/bin/env python3
"""Strict paired validation analysis for A6 reward-v3 PPO versus reward-v2 PPO and M2."""
import collections
import hashlib
import json
import sys
from pathlib import Path

import numpy as np

ROOT = Path("/root/rivermind-data/ca_rl_completion_v5_a6_no_runtime_reward_20261101")
MAIN = Path("/root/rivermind-data/ca_rl_completion_v5_staging/code")
RES = ROOT / "results"
TRAIN = Path("/root/rivermind-data/training_runs_v5_a6_no_runtime_reward_20261101")
BASE_TRAIN = MAIN.parent / "training_runs_v5_final72"
sys.path.insert(0, str(ROOT))
from carl.stats import wilcoxon_signed_rank, holm

METHODS = ["m2_global_asg", "m6_global_asg"]
SEED_GROUPS = {11: [101, 102, 103], 23: [104, 105, 106], 37: [107, 108, 109]}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read_rows(d):
    return [json.loads(p.read_text()) for p in sorted(d.glob("*.json"))
            if p.name != "manifest.json" and not p.name.endswith(".error.json")]


def bootstrap_ci(x, seed, n=20000):
    x = np.asarray(x, dtype=float)
    rng = np.random.default_rng(seed)
    idx = rng.integers(0, len(x), size=(n, len(x)))
    means = x[idx].mean(axis=1)
    return [float(np.quantile(means, 0.025)), float(np.quantile(means, 0.975))]


def compare(candidate, reference, seed):
    names = sorted(set(candidate) & set(reference))
    if len(names) != 24:
        raise RuntimeError(f"paired map count must be 24, got {len(names)}")
    x = np.asarray([candidate[n] for n in names], dtype=float)
    y = np.asarray([reference[n] for n in names], dtype=float)
    delta = 100.0 * (x / y - 1.0)
    stat = wilcoxon_signed_rank(x, y)
    return {
        "n_maps": len(names),
        "candidate_mean_cost": float(x.mean()),
        "reference_mean_cost": float(y.mean()),
        "mean_relative_delta_percent": float(delta.mean()),
        "median_relative_delta_percent": float(np.median(delta)),
        "wins_candidate_lower": int((delta < -1e-9).sum()),
        "wins_reference_lower": int((delta > 1e-9).sum()),
        "ties": int((np.abs(delta) <= 1e-9).sum()),
        "wilcoxon_p_raw": float(stat["p_value"]),
        "rank_biserial": float(stat.get("rank_biserial", 0.0)),
        "bootstrap95_relative_delta_percent": bootstrap_ci(delta, seed),
        "map_deltas": {n: float(v) for n, v in zip(names, delta)},
    }


def aggregate(rows, predicate):
    grouped = collections.defaultdict(list)
    selected = [r for r in rows if predicate(r)]
    for r in selected:
        grouped[r["instance"]].append(float(r["cost"]))
    return {k: float(np.mean(v)) for k, v in grouped.items()}, selected


def audit_training():
    result = {}
    code_hashes = set()
    for seed in SEED_GROUPS:
        d = TRAIN / f"PPO_seed{seed}"
        manifest = json.loads((d / "run_manifest.json").read_text())
        summary = json.loads((d / "summary.json").read_text())
        history = json.loads((d / "history.json").read_text())
        baseline_manifest = json.loads((BASE_TRAIN / f"PPO_seed{seed}" / "run_manifest.json").read_text())
        bc_meta = json.loads((BASE_TRAIN / f"BC_seed{seed}" / "bc_meta.json").read_text())
        checkpoint = d / "best.pt"
        checkpoint_hash = sha(checkpoint)
        code_hashes.add(manifest.get("code_sha256"))
        rollout_files = sorted((d / "rollouts").glob("iteration_*.npz"))
        episode_files = sorted((d / "rollouts").glob("iteration_*_episodes.json"))
        recorded_hashes = {int(x["iter"]): x.get("rollout_sha256") for x in history}
        rollouts_ok = (
            len(rollout_files) == 60 and len(episode_files) == 60
            and all(recorded_hashes.get(i) == sha(d / "rollouts" / f"iteration_{i:04d}.npz")
                    for i in range(1, 61))
        )
        val_files = list(d.glob("validation_*_stochastic.json"))
        det_files = list(d.glob("validation_*_deterministic.json"))
        checks = {
            "reward_schema": manifest.get("reward_schema") == "current-cost-delta-best-no-time-v3",
            "reward_ablation": manifest.get("reward_ablation") == "remove_explicit_runtime_penalty",
            "seed": manifest.get("seed") == seed,
            "iterations": len(history) == 60 and summary.get("iters") == 60,
            "same_train_split": manifest.get("train_instances") == baseline_manifest.get("train_instances"),
            "same_validation_split": manifest.get("validation_instances") == baseline_manifest.get("validation_instances"),
            "bc_warmstart_hash": manifest.get("resume_checkpoint_sha256") == bc_meta.get("teacher_checkpoint_sha256"),
            "same_model_state_action": manifest.get("model_schema") == baseline_manifest.get("model_schema")
                and manifest.get("state_schema") == baseline_manifest.get("state_schema")
                and manifest.get("action_schema") == baseline_manifest.get("action_schema"),
            "rollouts_complete_and_hashed": rollouts_ok,
            "validation_checkpoints": len(val_files) == 12 and len(det_files) == 12,
            "best_checkpoint_hash": summary.get("best_checkpoint_sha256") == checkpoint_hash,
            "training_time_positive": float(summary.get("elapsed", 0)) > 0,
        }
        import torch
        ckpt = torch.load(checkpoint, map_location="cpu")
        checks["checkpoint_reward_schema"] = ckpt.get("reward_schema") == "current-cost-delta-best-no-time-v3"
        result[str(seed)] = {
            "pass": all(checks.values()), "checks": checks,
            "best_val": summary.get("best_val"), "elapsed_seconds": summary.get("elapsed"),
            "best_checkpoint_sha256": checkpoint_hash,
            "source_sha256": manifest.get("code_sha256"),
            "rollout_count": len(rollout_files), "validation_stochastic_count": len(val_files),
        }
    return result, code_hashes


def load_a6_evaluation(budget):
    all_rows = []
    code_hashes = set()
    batch_meta = {}
    for seed, solver_seeds in SEED_GROUPS.items():
        if budget == 6 and seed == 11:
            d = RES / "a6_no_runtime_reward_global_transfer_6s_s11_mixed_unused_m2_model_binding"
            expected_methods = ["m2_global_asg", "m6_global_asg"]
            expected_tasks = 144
        else:
            d = RES / f"a6_no_runtime_reward_ppo_global_transfer_{budget}s_s{seed}"
            expected_methods = ["m6_global_asg"]
            expected_tasks = 72
        manifest = json.loads((d / "manifest.json").read_text())
        rows = read_rows(d)
        errors = list(d.glob("*.error.json"))
        solutions = list(d.glob("*.solution.json.gz"))
        method_counts = collections.Counter(r.get("method") for r in rows)
        if (manifest.get("finished") is None or manifest.get("errors") != 0
                or manifest.get("methods") != expected_methods
                or manifest.get("seeds") != solver_seeds
                or len(manifest.get("instances", [])) != 24
                or manifest.get("tasks") != expected_tasks
                or float(manifest.get("seconds", -1)) != float(budget)
                or len(rows) != expected_tasks or len(solutions) != expected_tasks or errors):
            raise RuntimeError(f"A6 PPO eval manifest/count failure: {d}")
        if budget == 6 and seed == 11:
            if method_counts != collections.Counter({"m2_global_asg": 72, "m6_global_asg": 72}):
                raise RuntimeError(f"preserved first mixed batch has wrong method counts: {d}")
        elif method_counts != collections.Counter({"m6_global_asg": 72}):
            raise RuntimeError(f"A6 PPO batch has wrong method counts: {d}")
        selected = [r for r in rows if r.get("method") == "m6_global_asg"]
        if len(selected) != 72:
            raise RuntimeError(f"A6 PPO row count must be 72: {d}")
        for row in selected:
            if row.get("status") != "ok" or row.get("feasible") is not True:
                raise RuntimeError(f"failed/infeasible A6 PPO row: {d}")
            if row.get("repair_scope_mode") != "global_assignment" or row.get("seed") not in solver_seeds:
                raise RuntimeError(f"wrong scope/seed in {d}")
            prov = row.get("provenance") or {}
            if not prov.get("code_sha256"):
                raise RuntimeError(f"missing A6 PPO source hash in {d}")
            expected = sha(TRAIN / f"PPO_seed{seed}" / "best.pt")
            if prov.get("model_sha256") != expected:
                raise RuntimeError(f"A6 model hash mismatch in {d}")
            code_hashes.add(prov["code_sha256"])
            row["model_seed"] = seed
            all_rows.append(row)
        batch_meta[str(seed)] = {
            "rows_in_batch": len(rows), "a6_ppo_rows_used": len(selected),
            "solution_files": len(solutions), "errors": len(errors),
            "manifest_finished": manifest.get("finished"),
            "method_counts": dict(method_counts),
            "unused_m2_rows": int(method_counts.get("m2_global_asg", 0)),
        }
    if len(code_hashes) != 1:
        raise RuntimeError(f"mixed A6 source hashes: {code_hashes}")
    if len({r["instance"] for r in all_rows}) != 24:
        raise RuntimeError("A6 PPO eval did not cover 24 maps")
    return all_rows, next(iter(code_hashes)), batch_meta


def load_m2_evaluation(budget):
    all_rows = []
    code_hashes = set()
    for seed, solver_seeds in SEED_GROUPS.items():
        d = RES / f"a6_no_runtime_reward_m2_global_transfer_{budget}s_s{seed}"
        manifest = json.loads((d / "manifest.json").read_text())
        rows = read_rows(d)
        errors = list(d.glob("*.error.json"))
        solutions = list(d.glob("*.solution.json.gz"))
        if (manifest.get("finished") is None or manifest.get("errors") != 0
                or manifest.get("methods") != ["m2_global_asg"]
                or manifest.get("seeds") != solver_seeds
                or len(manifest.get("instances", [])) != 24
                or manifest.get("tasks") != 72
                or float(manifest.get("seconds", -1)) != float(budget)
                or len(rows) != 72 or len(solutions) != 72 or errors):
            raise RuntimeError(f"M2 eval manifest/count failure: {d}")
        for row in rows:
            prov = row.get("provenance") or {}
            if (row.get("status") != "ok" or row.get("feasible") is not True
                    or row.get("repair_scope_mode") != "global_assignment"
                    or row.get("seed") not in solver_seeds
                    or row.get("controller") != "M2_adaptive_joint"
                    or prov.get("model_sha256") is not None):
                raise RuntimeError(f"invalid M2 eval row or unexpected model dependency: {d}")
            code_hashes.add(prov.get("code_sha256"))
            row["model_seed"] = seed
            all_rows.append(row)
    if len(code_hashes) != 1 or None in code_hashes:
        raise RuntimeError(f"mixed M2 source hashes: {code_hashes}")
    if len({r["instance"] for r in all_rows}) != 24:
        raise RuntimeError("M2 eval did not cover 24 maps")
    return all_rows, next(iter(code_hashes))


def load_reward_v2_ppo(budget):
    rows = []
    code_hashes = set()
    for seed, solver_seeds in SEED_GROUPS.items():
        d = MAIN / "results" / f"v5_rl_global_transfer_{budget}s_ppo_s{seed}_global"
        manifest = json.loads((d / "manifest.json").read_text())
        batch = read_rows(d)
        expected_model = sha(BASE_TRAIN / f"PPO_seed{seed}" / "best.pt")
        if (manifest.get("finished") is None or manifest.get("errors") != 0
                or manifest.get("methods") != ["m6_global_asg"]
                or manifest.get("seeds") != solver_seeds
                or len(manifest.get("instances", [])) != 24
                or manifest.get("tasks") != 72
                or float(manifest.get("seconds", -1)) != float(budget)
                or len(batch) != 72):
            raise RuntimeError(f"reward-v2 PPO manifest mismatch: {d}")
        for row in batch:
            prov = row.get("provenance") or {}
            if (row.get("status") != "ok" or row.get("feasible") is not True
                    or row.get("repair_scope_mode") != "global_assignment"
                    or row.get("seed") not in solver_seeds
                    or prov.get("model_sha256") != expected_model):
                raise RuntimeError(f"invalid reward-v2 PPO row: {d}")
            code_hashes.add(prov.get("code_sha256"))
            row["model_seed"] = seed
            rows.append(row)
    if len(code_hashes) != 1 or None in code_hashes:
        raise RuntimeError(f"mixed reward-v2 PPO source hashes: {code_hashes}")
    return rows, next(iter(code_hashes))


def main():
    training, training_hashes = audit_training()
    if len(training_hashes) != 1 or None in training_hashes or not all(x["pass"] for x in training.values()):
        raise RuntimeError("A6 training provenance audit failed")
    payload = {
        "schema": "a6_no_runtime_reward_global_transfer_analysis_v1",
        "interpretation": "24-map development validation only; not formal-test evidence",
        "training": training,
        "training_source_sha256": sorted(training_hashes),
        "budgets": {},
        "comparisons": [],
        "holm_family": "four paired tests: A6 vs M2 and A6 vs reward-v2 PPO at 6s and 12s",
    }
    pvals = []
    for budget in (6, 12):
        a6_rows, a6_code, batches = load_a6_evaluation(budget)
        m2_rows, m2_code = load_m2_evaluation(budget)
        v2_rows, v2_code = load_reward_v2_ppo(budget)
        if m2_code != a6_code:
            raise RuntimeError(f"A6 PPO and M2 source hashes differ: {a6_code} vs {m2_code}")
        a6, a6_selected = aggregate(a6_rows, lambda r: True)
        m2, m2_selected = aggregate(m2_rows, lambda r: True)
        v2, v2_selected = aggregate(v2_rows, lambda r: True)
        c1 = compare(a6, m2, 20261101 + budget)
        c1.update({"budget_seconds": budget, "candidate": "A6_PPO_no_runtime_reward",
                   "reference": "M2_Global_Assignment", "reference_source_sha256": a6_code})
        c2 = compare(a6, v2, 20261201 + budget)
        c2.update({"budget_seconds": budget, "candidate": "A6_PPO_no_runtime_reward",
                   "reference": "PPO_reward_v2", "reference_source_sha256": v2_code})
        payload["comparisons"].extend([c1, c2])
        pvals.extend([c1["wilcoxon_p_raw"], c2["wilcoxon_p_raw"]])
        payload["budgets"][str(budget)] = {
            "a6_source_sha256": a6_code, "m2_source_sha256": m2_code,
            "reward_v2_source_sha256": v2_code,
            "a6_batches": batches,
            "tasks": {"a6_ppo": len(a6_selected), "m2_global": len(m2_selected),
                      "reward_v2_ppo": len(v2_selected)},
            "feasibility": {
                "a6_ppo": float(np.mean([r["feasible"] for r in a6_selected])),
                "m2_global": float(np.mean([r["feasible"] for r in m2_selected])),
                "reward_v2_ppo": float(np.mean([r["feasible"] for r in v2_selected])),
            },
            "mean_runtime_seconds": {
                "a6_ppo_solver": float(np.mean([r["solver_seconds"] for r in a6_selected])),
                "a6_ppo_end_to_end": float(np.mean([r["end_to_end_seconds"] for r in a6_selected])),
                "m2_solver": float(np.mean([r["solver_seconds"] for r in m2_selected])),
                "reward_v2_ppo_solver": float(np.mean([r["solver_seconds"] for r in v2_selected])),
            },
        }
    adjusted = holm(pvals)
    for record, p in zip(payload["comparisons"], adjusted):
        record["holm_adjusted_p_4_test_family"] = float(p)
    payload["overall_pass"] = True
    out_json = RES / "a6_no_runtime_reward_global_transfer_analysis_20261101.json"
    out_md = RES / "a6_no_runtime_reward_global_transfer_analysis_20261101.md"
    out_json.write_text(json.dumps(payload, indent=2) + "\n")
    lines = [
        "# A6 no-runtime-reward PPO — Global Assignment validation",
        "",
        "24-map development validation only. Positive delta means A6 PPO has higher/worse cost.",
        "",
        "## Training audit",
        "",
    ]
    for seed, rec in training.items():
        lines.append(f"- Seed {seed}: {'PASS' if rec['pass'] else 'FAIL'}; best stochastic validation cost={rec['best_val']:.4f}; training seconds={rec['elapsed_seconds']:.1f}; source={rec['source_sha256']}")
    lines += [
        "",
        "## Paired comparisons",
        "",
        "| Budget | Reference | Mean relative delta | 95% CI | W/L/T | Wilcoxon p | Holm p |",
        "|---:|---|---:|---:|---:|---:|---:|",
    ]
    for c in payload["comparisons"]:
        ci = c["bootstrap95_relative_delta_percent"]
        lines.append(
            f"| {c['budget_seconds']}s | {c['reference']} | {c['mean_relative_delta_percent']:+.4f}% "
            f"| [{ci[0]:+.4f}, {ci[1]:+.4f}]% | "
            f"{c['wins_candidate_lower']}/{c['wins_reference_lower']}/{c['ties']} | "
            f"{c['wilcoxon_p_raw']:.4g} | {c['holm_adjusted_p_4_test_family']:.4g} |"
        )
    lines += [
        "",
        "## Interpretation",
        "",
        "- A6 removes only the explicit operator-time reward penalty; elapsed-time SMDP GAE remains.",
        "- The policy is trained on the same 72 train maps and selected on the same 24 validation maps as reward-v2 PPO.",
        "- A6 is compared with M2 Global Assignment using the same A6 source, evaluator, initial-solution protocol, paired solver seeds and wall-clock budget. M2 is run without a PPO model path; the first mixed batch's M2 rows are preserved but excluded.",
        "- A6 vs reward-v2 PPO is paired by the same maps and solver seeds; source hashes differ for the intentional reward/training-schema intervention and the explicit BC warm-start schema gate.",
        "- This validation result does not establish RL independent contribution unless A6 beats M2 with meaningful corrected evidence.",
    ]
    out_md.write_text("\n".join(lines) + "\n")
    print(out_md.read_text())
    print("JSON:", out_json)


if __name__ == "__main__":
    main()
