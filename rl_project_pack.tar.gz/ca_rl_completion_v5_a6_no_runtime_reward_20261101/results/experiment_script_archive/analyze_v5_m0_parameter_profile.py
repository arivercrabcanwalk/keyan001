#!/usr/bin/env python3
"""Budget-matched M0 profile validation against the selected non-PPO baseline."""
import json
import sys
from pathlib import Path
from collections import defaultdict

import numpy as np

ROOT = Path("/root/rivermind-data/ca_rl_completion_v5_staging/code")
RESULTS = ROOT / "results"
sys.path.insert(0, str(ROOT))
from carl.stats import wilcoxon_signed_rank, holm

METHODS = ["m0", "m0frozen", "m0paper"]
SEEDS = list(range(101, 111))
PROTOCOLS = {
    "m0": "research-budget",
    "m0frozen": "frozen-v6-code-profile",
    "m0paper": "paper-parameters-on-v6",
}


def bootstrap_ci(delta, seed, n_boot=20000):
    x = np.asarray(delta, dtype=float)
    rng = np.random.default_rng(seed)
    idx = rng.integers(0, len(x), size=(n_boot, len(x)))
    means = x[idx].mean(axis=1)
    return [float(np.quantile(means, .025)), float(np.quantile(means, .975))]


def aggregate(rows, method):
    g = defaultdict(list)
    for r in rows:
        if r["method"] == method:
            g[r["instance"]].append(float(r["cost"]))
    if any(len(v) != len(SEEDS) for v in g.values()) or len(g) != 24:
        raise RuntimeError(f"wrong map/seed coverage for {method}")
    return {k: float(np.mean(v)) for k, v in g.items()}


def paired(candidate, reference, seed):
    names = sorted(set(candidate) & set(reference))
    x = np.asarray([candidate[n] for n in names], dtype=float)
    y = np.asarray([reference[n] for n in names], dtype=float)
    d = 100.0 * (x / y - 1.0)
    stat = wilcoxon_signed_rank(x, y)
    return {
        "n_maps": len(names),
        "candidate_mean_cost": float(x.mean()),
        "reference_mean_cost": float(y.mean()),
        "mean_delta_percent": float(d.mean()),
        "median_delta_percent": float(np.median(d)),
        "wins_candidate_lower": int((d < -1e-9).sum()),
        "wins_reference_lower": int((d > 1e-9).sum()),
        "ties": int((np.abs(d) <= 1e-9).sum()),
        "wilcoxon_p_raw": float(stat["p_value"]),
        "rank_biserial": float(stat.get("rank_biserial", 0.0)),
        "bootstrap95_delta_percent": bootstrap_ci(d, seed),
    }


def load_m0_budget(budget):
    d = RESULTS / f"v5_m0_parameter_profile_10seed_{budget}s"
    manifest = json.loads((d / "manifest.json").read_text())
    if (manifest.get("finished") is None or manifest.get("errors") != 0
            or manifest.get("methods") != METHODS
            or manifest.get("seeds") != SEEDS
            or len(manifest.get("instances", [])) != 24
            or manifest.get("tasks") != 24 * len(SEEDS) * len(METHODS)
            or float(manifest.get("seconds", -1)) != float(budget)):
        raise RuntimeError(f"M0 manifest mismatch: {d}")
    rows = [json.loads(p.read_text()) for p in sorted(d.glob("*__s*.json"))]
    if len(rows) != 24 * len(SEEDS) * len(METHODS):
        raise RuntimeError(f"M0 row count mismatch: {d}")
    hashes = set()
    for r in rows:
        if r.get("status") != "ok" or r.get("feasible") is not True:
            raise RuntimeError(f"M0 invalid/infeasible result: {r.get('file')}")
        if r.get("method") not in METHODS or int(r.get("seed", -1)) not in SEEDS:
            raise RuntimeError("unexpected M0 task identity")
        if r.get("protocol") != PROTOCOLS[r["method"]]:
            raise RuntimeError(f"wrong M0 protocol metadata for {r['method']}")
        hashes.add((r.get("provenance") or {}).get("code_sha256"))
    if len(hashes) != 1 or None in hashes:
        raise RuntimeError(f"mixed/missing M0 source hashes for {budget}s")
    return rows, manifest, next(iter(hashes))


def load_selected_baseline(budget, expected_hash):
    d = RESULTS / f"v5_global_repair_finalists_10seed_{budget}s"
    manifest = json.loads((d / "manifest.json").read_text())
    methods = [x.strip() for x in (RESULTS / "v5_global_repair_finalists.txt").read_text().splitlines()
               if x.strip() and not x.lstrip().startswith("#")]
    selected = [x.strip() for x in (RESULTS / "v5_final_nonppo_baseline.txt").read_text().splitlines()
                if x.strip() and not x.lstrip().startswith("#")]
    if len(selected) != 1 or selected[0] not in methods:
        raise RuntimeError("selected non-PPO baseline missing/not in finalist matrix")
    method = selected[0]
    if (manifest.get("finished") is None or manifest.get("errors") != 0
            or manifest.get("methods") != methods or manifest.get("seeds") != SEEDS
            or len(manifest.get("instances", [])) != 24
            or manifest.get("tasks") != 24 * len(SEEDS) * len(methods)
            or float(manifest.get("seconds", -1)) != float(budget)):
        raise RuntimeError(f"finalist baseline manifest mismatch: {d}")
    rows = [json.loads(p.read_text()) for p in sorted(d.glob("*__s*.json"))]
    selected_rows = [r for r in rows if r["method"] == method]
    if len(selected_rows) != 24 * len(SEEDS):
        raise RuntimeError("selected baseline result count mismatch")
    if any(r.get("status") != "ok" or r.get("feasible") is not True
           or r.get("repair_scope_mode") != "global_assignment" for r in selected_rows):
        raise RuntimeError("selected baseline contains invalid/wrong-scope results")
    hashes = {(r.get("provenance") or {}).get("code_sha256") for r in selected_rows}
    if len(hashes) != 1 or None in hashes or next(iter(hashes)) != expected_hash:
        raise RuntimeError("M0 and selected baseline source hashes do not match")
    return aggregate(selected_rows, method), method


def main():
    payload = {
        "schema": "v5_m0_parameter_profile_10seed_analysis_v1",
        "methods": METHODS,
        "solver_seeds": SEEDS,
        "statistical_unit": "map; ten solver seeds averaged within each map",
        "selected_nonppo_baseline": None,
        "source_sha256": None,
        "budgets": {},
        "baseline_vs_m0_profiles": [],
        "m0paper_vs_m0frozen": [],
        "m0_research_budget_descriptive": [],
    }
    source_hashes = set()
    p_primary, p_parameter = [], []
    for budget in (6, 12):
        rows, manifest, code_hash = load_m0_budget(budget)
        source_hashes.add(code_hash)
        baseline, baseline_method = load_selected_baseline(budget, code_hash)
        if payload["selected_nonppo_baseline"] is None:
            payload["selected_nonppo_baseline"] = baseline_method
        elif payload["selected_nonppo_baseline"] != baseline_method:
            raise RuntimeError("selected non-PPO baseline changed between budgets")
        info = {"manifest": manifest, "code_sha256": code_hash, "methods": {}}
        for method in METHODS:
            mr = [r for r in rows if r["method"] == method]
            info["methods"][method] = {
                "tasks": len(mr),
                "mean_cost": float(np.mean([r["cost"] for r in mr])),
                "median_cost": float(np.median([r["cost"] for r in mr])),
                "std_cost": float(np.std([r["cost"] for r in mr], ddof=1)),
                "feasibility_rate": float(np.mean([r["feasible"] for r in mr])),
                "mean_solver_seconds": float(np.mean([r["solver_seconds"] for r in mr])),
                "mean_end_to_end_seconds": float(np.mean([r["end_to_end_seconds"] for r in mr])),
                "mean_outer_iterations": float(np.mean([
                    r.get("outer_iterations_attempted") or 0 for r in mr])),
            }
        payload["budgets"][str(budget)] = info

        for method in ("m0frozen", "m0paper"):
            c = paired(baseline, aggregate(rows, method),
                       20261031 + budget * 100 + len(method))
            c.update({"budget_seconds": budget, "candidate": baseline_method,
                      "reference": method})
            payload["baseline_vs_m0_profiles"].append(c)
            p_primary.append(c["wilcoxon_p_raw"])

        c = paired(aggregate(rows, "m0paper"), aggregate(rows, "m0frozen"),
                   20261101 + budget * 100)
        c.update({"budget_seconds": budget, "candidate": "m0paper", "reference": "m0frozen"})
        payload["m0paper_vs_m0frozen"].append(c)
        p_parameter.append(c["wilcoxon_p_raw"])

        c = paired(baseline, aggregate(rows, "m0"),
                   20261102 + budget * 100)
        c.update({"budget_seconds": budget, "candidate": baseline_method,
                  "reference": "m0_research_budget"})
        payload["m0_research_budget_descriptive"].append(c)

    if len(source_hashes) != 1:
        raise RuntimeError("6s/12s M0 matrices do not share one source hash")
    payload["source_sha256"] = next(iter(source_hashes))
    for c, p in zip(payload["baseline_vs_m0_profiles"], holm(p_primary)):
        c["holm_adjusted_p_4_test_family"] = float(p)
    for c, p in zip(payload["m0paper_vs_m0frozen"], holm(p_parameter)):
        c["holm_adjusted_p_2_test_family"] = float(p)

    out_json = RESULTS / "v5_m0_parameter_profile_analysis.json"
    out_md = RESULTS / "v5_m0_parameter_profile_analysis.md"
    out_json.write_text(json.dumps(payload, indent=2) + "\n")
    lines = [
        "# M0 parameter-profile validation — 10 solver seeds",
        "",
        f"Selected non-PPO reference: {payload['selected_nonppo_baseline']}. "
        "M0 profiles are V6 Python implementations under the one-SD SABS physical evaluator, not byte-for-byte Java execution.",
        "",
        "| Budget | M0 method | Mean cost | Median | SD | Feasibility | Solver s | End-to-end s | Mean outer iterations |",
        "|---:|---|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for b in (6, 12):
        for method in METHODS:
            s = payload["budgets"][str(b)]["methods"][method]
            lines.append(
                f"| {b}s | {method} | {s['mean_cost']:.4f} | {s['median_cost']:.4f} | "
                f"{s['std_cost']:.4f} | {s['feasibility_rate']:.1%} | "
                f"{s['mean_solver_seconds']:.3f} | {s['mean_end_to_end_seconds']:.3f} | "
                f"{s['mean_outer_iterations']:.1f} |")
    lines += [
        "",
        "## Primary: selected non-PPO baseline vs corrected M0 profiles",
        "",
        "Negative delta means the selected joint-search baseline has lower cost than the M0 profile. Holm family covers two M0 profiles × two budgets.",
        "",
        "| Budget | Baseline | M0 profile | Mean delta % | 95% CI | W/L/T maps | Wilcoxon p | Holm p |",
        "|---:|---|---|---:|---:|---:|---:|---:|",
    ]
    for c in payload["baseline_vs_m0_profiles"]:
        ci = c["bootstrap95_delta_percent"]
        lines.append(
            f"| {c['budget_seconds']}s | {c['candidate']} | {c['reference']} | "
            f"{c['mean_delta_percent']:+.4f}% | [{ci[0]:+.4f}, {ci[1]:+.4f}] | "
            f"{c['wins_candidate_lower']}/{c['wins_reference_lower']}/{c['ties']} | "
            f"{c['wilcoxon_p_raw']:.4g} | {c['holm_adjusted_p_4_test_family']:.4g} |")
    lines += [
        "",
        "## Parameter-profile comparison: paper Table A1 vs released Java profile",
        "",
        "| Budget | Candidate | Reference | Mean delta % | 95% CI | Wilcoxon p | Holm p (2 tests) |",
        "|---:|---|---|---:|---:|---:|---:|",
    ]
    for c in payload["m0paper_vs_m0frozen"]:
        ci = c["bootstrap95_delta_percent"]
        lines.append(
            f"| {c['budget_seconds']}s | m0paper | m0frozen | {c['mean_delta_percent']:+.4f}% | "
            f"[{ci[0]:+.4f}, {ci[1]:+.4f}] | {c['wilcoxon_p_raw']:.4g} | "
            f"{c['holm_adjusted_p_2_test_family']:.4g} |")
    lines += [
        "",
        "## Legacy research-budget variant (descriptive only)",
        "",
        "| Budget | Baseline vs m0 research-budget delta % | 95% CI | Wilcoxon p (descriptive) |",
        "|---:|---:|---:|---:|",
    ]
    for c in payload["m0_research_budget_descriptive"]:
        ci = c["bootstrap95_delta_percent"]
        lines.append(
            f"| {c['budget_seconds']}s | {c['mean_delta_percent']:+.4f}% | "
            f"[{ci[0]:+.4f}, {ci[1]:+.4f}] | {c['wilcoxon_p_raw']:.4g} |")
    out_md.write_text("\n".join(lines) + "\n")
    print("\n".join(lines))


if __name__ == "__main__":
    main()
