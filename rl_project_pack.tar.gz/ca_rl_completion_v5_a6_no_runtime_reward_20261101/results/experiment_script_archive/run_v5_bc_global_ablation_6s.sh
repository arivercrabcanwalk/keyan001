#!/usr/bin/env bash
set -euo pipefail
ROOT=/root/rivermind-data/ca_rl_completion_v5_staging/code
cd "$ROOT"
PY=/opt/conda/bin/python
METHODS=m2_global_asg,m6_global_asg,m6_global_nojoint,m6_global_nomask,m6_global_zeroasg,m6_global_zerodrone,m6_global_zerohist,m6_global_zeroglobal,m6_global_nohighint
for model_seed in 11 23 37; do
  case "$model_seed" in
    11) solver_seeds=101,102,103 ;;
    23) solver_seeds=104,105,106 ;;
    37) solver_seeds=107,108,109 ;;
  esac
  model="../training_runs_v5_final72/BC_seed${model_seed}/bc.pt"
  [ -f "$model" ] || { echo "missing BC checkpoint: $model" >&2; exit 21; }
  out="results/v5_bc_global_ablation_6s_s${model_seed}"
  [ ! -e "$out" ] || { echo "output exists; preserve and inspect: $out" >&2; exit 22; }
  echo "[BC_GLOBAL_ABLATION] model_seed=$model_seed solver_seeds=$solver_seeds"
  "$PY" -B scripts/run_bench.py --instances val --methods "$METHODS" \
    --seeds "$solver_seeds" --seconds 6 --workers 8 \
    --ppo-model "$model" --out "$out"
done
"$PY" -B results/experiment_script_archive/analyze_v5_bc_global_ablation_6s.py
printf "V5_BC_GLOBAL_ABLATION_6S_COMPLETE\n" > results/V5_BC_GLOBAL_ABLATION_6S_COMPLETE
echo "V5_BC_GLOBAL_ABLATION_6S_COMPLETE"
