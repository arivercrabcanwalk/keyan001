#!/usr/bin/env python3
"""10-seed same-source M2 Global vs M2 Global without Joint-family operators."""
import json,sys
from pathlib import Path
from collections import defaultdict
import numpy as np
ROOT=Path("/root/rivermind-data/ca_rl_completion_v5_staging/code")
RES=ROOT/"results"
sys.path.insert(0,str(ROOT))
from carl.stats import wilcoxon_signed_rank,holm
METHODS=("m2_global_asg","m2_global_nojoint")
SEEDS=list(range(201,211))
def ci(x,seed,n=20000):
 x=np.asarray(x,float);rng=np.random.default_rng(seed)
 ix=rng.integers(0,len(x),size=(n,len(x)))
 y=x[ix].mean(axis=1)
 return [float(np.quantile(y,.025)),float(np.quantile(y,.975))]
def compare(a,b,seed):
 names=sorted(set(a)&set(b))
 x=np.asarray([a[n] for n in names],float);y=np.asarray([b[n] for n in names],float)
 d=100*(x/y-1);st=wilcoxon_signed_rank(x,y)
 return {"n_maps":len(names),"mean_delta_percent":float(d.mean()),
  "median_delta_percent":float(np.median(d)),
  "wins_candidate_lower":int((d < -1e-9).sum()),
  "wins_reference_lower":int((d > 1e-9).sum()),
  "ties":int((np.abs(d)<=1e-9).sum()),
  "wilcoxon_p_raw":float(st["p_value"]),
  "rank_biserial":float(st.get("rank_biserial",0)),
  "bootstrap95_delta_percent":ci(d,seed),
  "map_deltas":{n:float(v) for n,v in zip(names,d)}}
payload={"schema":"v5_m2_global_joint_family_leaveout_10seed_v1",
 "status":"development_validation_only","statistical_unit":"map; ten solver seeds averaged within each map",
 "methods":{},"comparisons":[],"source_sha256":None}
pvals=[]
for budget in (6,12):
 d=RES/f"v5_m2_global_nojoint_10seed_{budget}s"
 m=json.loads((d/"manifest.json").read_text())
 if (m.get("finished") is None or m.get("errors")!=0 or m.get("methods")!=list(METHODS)
     or m.get("seeds")!=SEEDS or len(m.get("instances",[]))!=24
     or m.get("tasks")!=24*2*10 or float(m.get("seconds",-1))!=float(budget)):
  raise RuntimeError(f"manifest mismatch {d}")
 files=sorted(d.glob("*__s*.json"))
 if len(files)!=480 or list(d.glob("*.error.json")):raise RuntimeError(f"row count mismatch {d}")
 rows=[json.loads(f.read_text()) for f in files]
 hashes=set()
 grouped={x:defaultdict(list) for x in METHODS}
 for r in rows:
  pr=r.get("provenance") or {}; hashes.add(pr.get("code_sha256"))
  if r.get("status")!="ok" or r.get("feasible") is not True:raise RuntimeError(f"invalid row {d} {r.get('instance')}")
  if r.get("repair_scope_mode")!="global_assignment":raise RuntimeError("wrong scope")
  if int(r.get("seed",-1)) not in SEEDS:raise RuntimeError("wrong seed")
  grouped[r["method"]][r["instance"]].append(float(r["cost"]))
 if len(hashes)!=1 or None in hashes:raise RuntimeError(f"mixed source hashes in {d}: {hashes}")
 code_hash=next(iter(hashes))
 if payload["source_sha256"] is None:payload["source_sha256"]=code_hash
 elif payload["source_sha256"]!=code_hash:raise RuntimeError("source hash changed between budgets")
 means={}
 for method in METHODS:
  if len(grouped[method])!=24 or any(len(v)!=10 for v in grouped[method].values()):
   raise RuntimeError(f"map/seed coverage mismatch: {method}")
  means[method]={k:float(np.mean(v)) for k,v in grouped[method].items()}
  mr=[r for r in rows if r["method"]==method]
  payload["methods"][f"{budget}s:{method}"]={
   "n_tasks":len(mr),"mean_cost":float(np.mean([r["cost"] for r in mr])),
   "median_cost":float(np.median([r["cost"] for r in mr])),
   "std_cost":float(np.std([r["cost"] for r in mr],ddof=1)),
   "feasibility_rate":float(np.mean([r["feasible"] for r in mr])),
   "mean_solver_seconds":float(np.mean([r["solver_seconds"] for r in mr])),
   "mean_end_to_end_seconds":float(np.mean([r["end_to_end_seconds"] for r in mr]))}
 c=compare(means["m2_global_nojoint"],means["m2_global_asg"],20261101+budget)
 c.update({"budget_seconds":budget,"candidate":"m2_global_nojoint","reference":"m2_global_asg"})
 payload["comparisons"].append(c);pvals.append(c["wilcoxon_p_raw"])
for r,p in zip(payload["comparisons"],holm(pvals)):r["holm_adjusted_p_2_test_family"]=float(p)
(RES/"v5_m2_global_nojoint_10seed_analysis.json").write_text(json.dumps(payload,indent=2)+"\n")
lines=["# M2 Global Joint-family leave-out confirmation (10 seeds)","","All methods use Global Assignment repair and one common source version. Positive delta means removing the Joint family is worse than full M2 Global.","",
"| Budget | Method | Mean cost | Median | SD | Feasibility | Solver s | End-to-end s |",
"|---:|---|---:|---:|---:|---:|---:|---:|"]
for b in (6,12):
 for method in METHODS:
  s=payload["methods"][f"{b}s:{method}"]
  lines.append(f"| {b}s | {method} | {s['mean_cost']:.4f} | {s['median_cost']:.4f} | {s['std_cost']:.4f} | {s['feasibility_rate']:.1%} | {s['mean_solver_seconds']:.3f} | {s['mean_end_to_end_seconds']:.3f} |")
lines += ["","## Paired map-level comparison","","| Budget | Mean delta % | 95% CI | W/L/T | Wilcoxon p | Holm p |","|---:|---:|---:|---:|---:|---:|"]
for r in payload["comparisons"]:
 x=r["bootstrap95_delta_percent"]
 lines.append(f"| {r['budget_seconds']}s | {r['mean_delta_percent']:+.4f}% | [{x[0]:+.4f}, {x[1]:+.4f}] | {r['wins_candidate_lower']}/{r['wins_reference_lower']}/{r['ties']} | {r['wilcoxon_p_raw']:.4g} | {r['holm_adjusted_p_2_test_family']:.4g} |")
lines += ["","Development validation only; do not use this result as blind-test evidence."]
(RES/"v5_m2_global_nojoint_10seed_analysis.md").write_text("\n".join(lines)+"\n")
print("\n".join(lines))
