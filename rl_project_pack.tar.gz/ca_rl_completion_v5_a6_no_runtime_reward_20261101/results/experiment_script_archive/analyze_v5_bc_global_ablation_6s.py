#!/usr/bin/env python3
"""Validation-only BC Global ablations, paired by map and corrected over 15 tests."""
import hashlib, json, sys
from pathlib import Path
from collections import defaultdict
import numpy as np

ROOT=Path("/root/rivermind-data/ca_rl_completion_v5_staging/code")
RES=ROOT/"results"
sys.path.insert(0,str(ROOT))
from carl.stats import wilcoxon_signed_rank, holm

METHODS=("m2_global_asg","m6_global_asg","m6_global_nojoint","m6_global_nomask",
         "m6_global_zeroasg","m6_global_zerodrone","m6_global_zerohist",
         "m6_global_zeroglobal","m6_global_nohighint")
MODEL_SEEDS=(11,23,37)
SOLVER_SEEDS={11:(101,102,103),23:(104,105,106),37:(107,108,109)}
ABLATIONS=("m6_global_nojoint","m6_global_nomask","m6_global_zeroasg",
           "m6_global_zerodrone","m6_global_zerohist","m6_global_zeroglobal",
           "m6_global_nohighint")

def boot(x,seed,n=20000):
    x=np.asarray(x,float); rng=np.random.default_rng(seed)
    ix=rng.integers(0,len(x),size=(n,len(x)))
    y=x[ix].mean(axis=1)
    return [float(np.quantile(y,.025)),float(np.quantile(y,.975))]

def compare(a,b,seed):
    names=sorted(set(a)&set(b))
    x=np.asarray([a[n] for n in names],float)
    y=np.asarray([b[n] for n in names],float)
    d=100*(x/y-1)
    st=wilcoxon_signed_rank(x,y)
    return {"n_maps":len(names),"mean_delta_percent":float(d.mean()),
            "median_delta_percent":float(np.median(d)),
            "wins_candidate_lower":int((d < -1e-9).sum()),
            "wins_reference_lower":int((d > 1e-9).sum()),
            "ties":int((np.abs(d)<=1e-9).sum()),
            "wilcoxon_p_raw":float(st["p_value"]),
            "rank_biserial":float(st.get("rank_biserial",0)),
            "bootstrap95_delta_percent":boot(d,seed),
            "map_deltas":{n:float(v) for n,v in zip(names,d)}}

rows=[]; code_hashes=set(); model_hashes={}
for ms in MODEL_SEEDS:
    d=RES/f"v5_bc_global_ablation_6s_s{ms}"
    m=json.loads((d/"manifest.json").read_text())
    expected=list(SOLVER_SEEDS[ms])
    if (m.get("finished") is None or m.get("errors")!=0
        or m.get("methods")!=list(METHODS) or m.get("seeds")!=expected
        or len(m.get("instances",[]))!=24 or m.get("tasks")!=24*len(METHODS)*3
        or float(m.get("seconds",-1))!=6.0):
        raise RuntimeError(f"manifest mismatch: {d}")
    model_rel=ROOT/f"../training_runs_v5_final72/BC_seed{ms}/bc.pt"
    mh=hashlib.sha256(model_rel.read_bytes()).hexdigest()
    model_hashes[str(ms)]=mh
    fs=sorted(d.glob("*__s*.json"))
    if len(fs)!=m["tasks"] or list(d.glob("*.error.json")):
        raise RuntimeError(f"row/error count mismatch: {d}")
    for f in fs:
        r=json.loads(f.read_text())
        pr=r.get("provenance") or {}
        if (r.get("status")!="ok" or r.get("feasible") is not True
            or r.get("repair_scope_mode")!="global_assignment"
            or int(r.get("seed",-1)) not in expected
            or pr.get("model_sha256")!=mh or not pr.get("code_sha256")):
            raise RuntimeError(f"invalid feasibility/scope/seed/model row: {f}")
        code_hashes.add(pr["code_sha256"])
        r["model_seed"]=ms
        rows.append(r)
if len(code_hashes)!=1:
    raise RuntimeError(f"mixed source hash across ablation batches: {code_hashes}")
if len({r["instance"] for r in rows})!=24:
    raise RuntimeError("not all 24 validation maps covered")
for method in METHODS:
    if sum(r["method"]==method for r in rows)!=24*9:
        raise RuntimeError(f"wrong task count for {method}")

map_cost={}
method_stats={}
for method in METHODS:
    grouped=defaultdict(list)
    selected=[r for r in rows if r["method"]==method]
    for r in selected: grouped[r["instance"]].append(float(r["cost"]))
    map_cost[method]={k:float(np.mean(v)) for k,v in grouped.items()}
    method_stats[method]={
      "n_tasks":len(selected),
      "mean_cost":float(np.mean([r["cost"] for r in selected])),
      "median_cost":float(np.median([r["cost"] for r in selected])),
      "std_cost":float(np.std([r["cost"] for r in selected],ddof=1)),
      "feasibility_rate":float(np.mean([r["feasible"] for r in selected])),
      "mean_solver_seconds":float(np.mean([r["solver_seconds"] for r in selected])),
      "mean_end_to_end_seconds":float(np.mean([r["end_to_end_seconds"] for r in selected])),
    }

records=[]
for i,method in enumerate(ABLATIONS):
    c=compare(map_cost[method],map_cost["m6_global_asg"],20261101+i)
    c.update({"candidate":method,"reference":"m6_global_asg","family":"ablation_vs_full_BC"})
    records.append(c)
for i,method in enumerate([x for x in METHODS if x!="m2_global_asg"]):
    c=compare(map_cost[method],map_cost["m2_global_asg"],20261201+i)
    c.update({"candidate":method,"reference":"m2_global_asg","family":"learned_vs_M2_Global"})
    records.append(c)
for rec,p in zip(records,holm([x["wilcoxon_p_raw"] for x in records])):
    rec["holm_adjusted_p_15_test_family"]=float(p)

payload={"schema":"v5_bc_global_state_mask_family_ablation_6s_v1",
 "status":"development_validation_only","budget_seconds":6,
 "statistical_unit":"map; 3 BC model seeds x 3 solver seeds averaged within each map",
 "code_sha256":next(iter(code_hashes)),"model_sha256_by_seed":model_hashes,
 "tasks":len(rows),"methods":method_stats,"comparisons":records}
(RES/"v5_bc_global_ablation_6s_analysis.json").write_text(json.dumps(payload,indent=2)+"\n")
lines=["# BC Global repair state/mask/family ablation (6s validation)","","All methods use global Assignment repair. The BC checkpoints were trained under the local-scope regime; this is a transfer/ablation diagnostic, not a claim of matched-global training.","",
"## Method summary","","| Method | Mean cost | Median | SD | Feasibility | Solver s | End-to-end s | Tasks |","|---|---:|---:|---:|---:|---:|---:|---:|"]
for method in METHODS:
 s=method_stats[method]
 lines.append(f"| {method} | {s['mean_cost']:.4f} | {s['median_cost']:.4f} | {s['std_cost']:.4f} | {s['feasibility_rate']:.1%} | {s['mean_solver_seconds']:.3f} | {s['mean_end_to_end_seconds']:.3f} | {s['n_tasks']} |")
lines += ["","## Paired comparisons","","Positive delta means higher/worse cost. One 15-test Holm family covers seven ablations vs full BC and eight learned methods vs M2 Global.","",
"| Candidate | Reference | Mean delta % | 95% CI | W/L/T | Wilcoxon p | Holm p |","|---|---|---:|---:|---:|---:|---:|"]
for c in records:
 ci=c["bootstrap95_delta_percent"]
 lines.append(f"| {c['candidate']} | {c['reference']} | {c['mean_delta_percent']:+.4f}% | [{ci[0]:+.4f}, {ci[1]:+.4f}] | {c['wins_candidate_lower']}/{c['wins_reference_lower']}/{c['ties']} | {c['wilcoxon_p_raw']:.4g} | {c['holm_adjusted_p_15_test_family']:.4g} |")
lines += ["","## Interpretation limits","","- This experiment uses the 24-map development validation split, not a blind test set.",
"- BC models were trained with local repair; all evaluations here use global Assignment repair.",
"- Runtime reward ablation requires retraining under a different reward and is not included.",
"- GNN is deferred; no GNN superiority claim is made."]
(RES/"v5_bc_global_ablation_6s_analysis.md").write_text("\n".join(lines)+"\n")
print("\n".join(lines))
