#!/usr/bin/env python3
"""Analyze BC/PPO/A2C transfer under local vs global Assignment repair."""
import glob
import hashlib
import json
import sys
from pathlib import Path
from collections import defaultdict

import numpy as np

ROOT = Path("/root/rivermind-data/ca_rl_completion_v5_staging/code")
RESULTS = ROOT / "results"
sys.path.insert(0, str(ROOT))
from carl.stats import wilcoxon_signed_rank, holm

CONTROLLERS = ("bc", "ppo", "a2c")
MODEL_SEEDS = (11, 23, 37)
SOLVER_SEEDS = {
    11: (101, 102, 103),
    23: (104, 105, 106),
    37: (107, 108, 109),
}
SCOPES = ("local", "global")
METHOD_BY_SCOPE = {"local": "m6_local_scope", "global": "m6_global_asg"}


def read_jsonl_or_json_files(directory):
    rows = []
    for path in sorted(Path(directory).glob("*__s*.json")):
        with open(path) as f:
            rows.append(json.load(f))
    return rows


def bootstrap_ci(delta, seed, n_boot=20000):
    x = np.asarray(delta, dtype=float)
    rng = np.random.default_rng(seed)
    idx = rng.integers(0, len(x), size=(n_boot, len(x)))
    means = x[idx].mean(axis=1)
    return [float(np.quantile(means, 0.025)),
            float(np.quantile(means, 0.975))]


def load_rl_results(budget):
    rows = []
    code_hashes = set()
    for controller in CONTROLLERS:
        for model_seed in MODEL_SEEDS:
            for scope in SCOPES:
                method = METHOD_BY_SCOPE[scope]
                directory = RESULTS / (
                    f"v5_rl_global_transfer_{budget}s_{controller}_s{model_seed}_{scope}")
                model_rel = {
                    "bc": f"../training_runs_v5_final72/BC_seed{model_seed}/bc.pt",
                    "ppo": f"../training_runs_v5_final72/PPO_seed{model_seed}/best.pt",
                    "a2c": f"../training_runs_v5_a2c_final72/A2C_seed{model_seed}/best.pt",
                }[controller]
                model_path = (ROOT / model_rel).resolve()
                expected_model_hash = hashlib.sha256(model_path.read_bytes()).hexdigest()
                manifest_path = directory / "manifest.json"
                if not manifest_path.is_file():
                    raise RuntimeError(f"missing manifest: {manifest_path}")
                manifest = json.loads(manifest_path.read_text())
                expected_seeds = list(SOLVER_SEEDS[model_seed])
                if (manifest.get("finished") is None or manifest.get("errors") != 0
                        or manifest.get("methods") != [method]
                        or manifest.get("seeds") != expected_seeds
                        or len(manifest.get("instances", [])) != 24
                        or manifest.get("tasks") != 72
                        or float(manifest.get("seconds", -1)) != float(budget)):
                    raise RuntimeError(f"manifest mismatch: {directory}")
                task_rows = read_jsonl_or_json_files(directory)
                if len(task_rows) != 72:
                    raise RuntimeError(
                        f"wrong result count in {directory}: {len(task_rows)}")
                for row in task_rows:
                    if row.get("status") != "ok" or row.get("feasible") is not True:
                        raise RuntimeError(f"failed/infeasible result in {directory}")
                    if row.get("repair_scope_mode") != (
                            "global_assignment" if scope == "global" else "local"):
                        raise RuntimeError(f"repair scope metadata mismatch in {directory}")
                    if int(row["seed"]) not in expected_seeds:
                        raise RuntimeError(f"unexpected solver seed in {directory}")
                    provenance = row.get("provenance") or {}
                    code_hash = provenance.get("code_sha256")
                    model_hash = provenance.get("model_sha256")
                    if not code_hash or not model_hash:
                        raise RuntimeError(f"missing provenance in {directory}")
                    if model_hash != expected_model_hash:
                        raise RuntimeError(
                            f"model checkpoint hash mismatch in {directory}: "
                            f"{model_hash} != {expected_model_hash}")
                    code_hashes.add(code_hash)
                    row["controller_group"] = controller
                    row["model_seed"] = model_seed
                    row["scope"] = scope
                    rows.append(row)
    if len({r["instance"] for r in rows}) != 24:
        raise RuntimeError("RL transfer matrix does not cover 24 maps")
    if len(code_hashes) != 1:
        raise RuntimeError(f"mixed source versions in RL transfer matrix: {len(code_hashes)}")
    return rows, next(iter(code_hashes))


def load_selected_nonppo_baseline(budget):
    directory = RESULTS / f"v5_global_repair_finalists_10seed_{budget}s"
    manifest = json.loads((directory / "manifest.json").read_text())
    methods = [
        x.strip() for x in (RESULTS / "v5_global_repair_finalists.txt").read_text().splitlines()
        if x.strip() and not x.lstrip().startswith("#")
    ]
    selected_file = RESULTS / "v5_final_nonppo_baseline.txt"
    selected = [x.strip() for x in selected_file.read_text().splitlines()
                if x.strip() and not x.lstrip().startswith("#")]
    if len(selected) != 1 or selected[0] not in methods:
        raise RuntimeError("selected non-PPO baseline is missing or not in the finalist matrix")
    baseline_method = selected[0]
    if (manifest.get("finished") is None or manifest.get("errors") != 0
            or manifest.get("tasks") != 24 * 10 * len(methods)
            or manifest.get("methods") != methods
            or manifest.get("seeds") != list(range(101, 111))
            or len(manifest.get("instances", [])) != 24
            or float(manifest.get("seconds", -1)) != float(budget)):
        raise RuntimeError(f"same-source 10-seed finalist matrix incomplete: {directory}")
    all_rows = read_jsonl_or_json_files(directory)
    rows = [
        r for r in all_rows
        if r["method"] == baseline_method and int(r["seed"]) in range(101, 110)
    ]
    if len(rows) != 24 * 9:
        raise RuntimeError(
            f"selected baseline {baseline_method} should have 216 matched rows, got {len(rows)}")
    if any(r.get("status") != "ok" or r.get("feasible") is not True
           or r.get("repair_scope_mode") != "global_assignment" for r in rows):
        raise RuntimeError("selected non-PPO baseline contains invalid/infeasible/wrong-scope results")
    code_hashes = {(r.get("provenance") or {}).get("code_sha256") for r in rows}
    if len(code_hashes) != 1 or None in code_hashes:
        raise RuntimeError("selected non-PPO baseline has mixed/missing source hashes")
    return rows, next(iter(code_hashes)), baseline_method


def load_m1d_sensitivity(budget, expected_hash):
    directory = RESULTS / f"v5_global_repair_finalists_10seed_{budget}s"
    manifest = json.loads((directory / "manifest.json").read_text())
    methods = [
        x.strip() for x in (RESULTS / "v5_global_repair_finalists.txt").read_text().splitlines()
        if x.strip() and not x.lstrip().startswith("#")
    ]
    if ("m1d_global_asg" not in methods
            or manifest.get("finished") is None or manifest.get("errors") != 0
            or manifest.get("methods") != methods
            or manifest.get("seeds") != list(range(101, 111))
            or len(manifest.get("instances", [])) != 24
            or manifest.get("tasks") != 24 * 10 * len(methods)
            or float(manifest.get("seconds", -1)) != float(budget)):
        raise RuntimeError("M1D Global sensitivity matrix manifest mismatch")
    all_rows = read_jsonl_or_json_files(directory)
    rows = [r for r in all_rows
            if r["method"] == "m1d_global_asg" and int(r["seed"]) in range(101, 110)]
    if len(rows) != 24 * 9:
        raise RuntimeError(f"M1D Global sensitivity should have 216 rows, got {len(rows)}")
    if any(r.get("status") != "ok" or r.get("feasible") is not True
           or r.get("repair_scope_mode") != "global_assignment" for r in rows):
        raise RuntimeError("M1D Global sensitivity contains invalid/wrong-scope results")
    hashes = {(r.get("provenance") or {}).get("code_sha256") for r in rows}
    if len(hashes) != 1 or None in hashes or next(iter(hashes)) != expected_hash:
        raise RuntimeError("M1D Global sensitivity source hash mismatch")
    return rows


def aggregate_map(rows, predicate):
    grouped = defaultdict(list)
    for row in rows:
        if predicate(row):
            grouped[row["instance"]].append(float(row["cost"]))
    return {name: float(np.mean(values)) for name, values in grouped.items()}


def compare(candidate, reference, seed):
    names = sorted(set(candidate) & set(reference))
    x = np.asarray([candidate[n] for n in names], dtype=float)
    y = np.asarray([reference[n] for n in names], dtype=float)
    delta = 100.0 * (x / y - 1.0)
    stat = wilcoxon_signed_rank(x, y)
    return {
        "n_maps": len(names),
        "candidate_mean_cost": float(x.mean()),
        "reference_mean_cost": float(y.mean()),
        "mean_relative_delta_percent": float(delta.mean()),
        "median_relative_delta_percent": float(np.median(delta)),
        "wins_candidate_lower": int((delta < -1e-9).sum()),
        "wins_reference_lower": int((delta > 1e-9).sum()),
        "ties": int((np.abs(delta) <= 1e-9).sum()),
        "wilcoxon_p_raw": float(stat["p_value"]),
        "rank_biserial": float(stat.get("rank_biserial", 0.0)),
        "bootstrap95_relative_delta_percent": bootstrap_ci(delta, seed),
        "map_deltas": {name: float(v) for name, v in zip(names, delta)},
    }


def main():
    payload = {
        "schema": "v5_rl_global_assignment_transfer_analysis_v2",
        "interpretation": "transfer diagnostic; learned checkpoints were trained with local repair",
        "selected_nonppo_baseline": None,
        "statistical_unit": "map; nine learned runs (3 model seeds x 3 solver seeds) averaged within each map",
        "controllers": list(CONTROLLERS),
        "model_seeds": list(MODEL_SEEDS),
        "solver_seed_groups": {str(k): list(v) for k, v in SOLVER_SEEDS.items()},
        "budgets": {},
        "primary_comparisons": [],
        "secondary_comparisons": [],
        "exploratory_local_vs_baseline": [],
        "secondary_vs_m1d_global_descriptive": [],
    }
    primary_p = []
    secondary_p = []
    exploratory_p = []

    for budget in (6, 12):
        rows, code_hash = load_rl_results(budget)
        baseline_rows, baseline_code_hash, baseline_method = load_selected_nonppo_baseline(budget)
        if baseline_code_hash != code_hash:
            raise RuntimeError(
                f"RL transfer and selected non-PPO baseline use different source hashes: "
                f"{code_hash} vs {baseline_code_hash}")
        baseline = aggregate_map(baseline_rows, lambda r: True)
        m1d_rows = load_m1d_sensitivity(budget, code_hash)
        m1d_baseline = aggregate_map(m1d_rows, lambda r: True)
        if payload["selected_nonppo_baseline"] is None:
            payload["selected_nonppo_baseline"] = baseline_method
        elif payload["selected_nonppo_baseline"] != baseline_method:
            raise RuntimeError("selected non-PPO baseline changed between budgets")
        budget_info = {
            "rl_code_sha256": code_hash,
            "baseline_method": baseline_method,
            "baseline_tasks": len(baseline_rows),
            "learned_controller_tasks": len(rows),
            "controllers": {},
        }
        for controller in CONTROLLERS:
            global_map = aggregate_map(
                rows, lambda r: r["controller_group"] == controller and r["scope"] == "global")
            local_map = aggregate_map(
                rows, lambda r: r["controller_group"] == controller and r["scope"] == "local")
            g_vs_baseline = compare(global_map, baseline, 20261031 + budget * 100 + len(controller))
            l_vs_g = compare(local_map, global_map, 20261101 + budget * 100 + len(controller))
            l_vs_baseline = compare(local_map, baseline, 20261102 + budget * 100 + len(controller))
            g_vs_baseline.update({
                "budget_seconds": budget, "controller": controller,
                "candidate_scope": "global", "reference": baseline_method,
            })
            l_vs_g.update({
                "budget_seconds": budget, "controller": controller,
                "candidate_scope": "local", "reference": "same_controller_global",
            })
            l_vs_baseline.update({
                "budget_seconds": budget, "controller": controller,
                "candidate_scope": "local", "reference": baseline_method,
            })
            payload["primary_comparisons"].append(g_vs_baseline)
            payload["secondary_comparisons"].append(l_vs_g)
            payload["exploratory_local_vs_baseline"].append(l_vs_baseline)
            g_vs_m1d = compare(
                global_map, m1d_baseline,
                20261103 + budget * 100 + len(controller))
            g_vs_m1d.update({
                "budget_seconds": budget, "controller": controller,
                "candidate_scope": "global", "reference": "m1d_global_asg",
            })
            payload["secondary_vs_m1d_global_descriptive"].append(g_vs_m1d)
            primary_p.append(g_vs_baseline["wilcoxon_p_raw"])
            secondary_p.append(l_vs_g["wilcoxon_p_raw"])
            exploratory_p.append(l_vs_baseline["wilcoxon_p_raw"])

            budget_info["controllers"][controller] = {
                "global_mean_cost": float(np.mean(list(global_map.values()))),
                "local_mean_cost": float(np.mean(list(local_map.values()))),
                "baseline_mean_cost": float(np.mean(list(baseline.values()))),
                "global_mean_solver_seconds": float(np.mean([
                    r["solver_seconds"] for r in rows
                    if r["controller_group"] == controller and r["scope"] == "global"
                ])),
                "local_mean_solver_seconds": float(np.mean([
                    r["solver_seconds"] for r in rows
                    if r["controller_group"] == controller and r["scope"] == "local"
                ])),
            }
        payload["budgets"][str(budget)] = budget_info

    for key, pvals in (
        ("primary_holm_adjusted_p", primary_p),
        ("secondary_holm_adjusted_p", secondary_p),
        ("exploratory_holm_adjusted_p", exploratory_p),
    ):
        adjusted = holm(pvals)
        for record, p in zip(
            payload[
                "primary_comparisons" if key.startswith("primary")
                else "secondary_comparisons" if key.startswith("secondary")
                else "exploratory_local_vs_baseline"
            ], adjusted
        ):
            record[key] = float(p)

    out_json = RESULTS / "v5_rl_global_transfer_analysis.json"
    out_md = RESULTS / "v5_rl_global_transfer_analysis.md"
    out_json.write_text(json.dumps(payload, indent=2) + "\n")

    lines = [
        "# BC/PPO/A2C transfer under global Assignment repair",
        "",
        "This is a transfer diagnostic: all learned checkpoints were trained with local Assignment repair. Global-scope evaluation changes the repair dynamics but keeps the same 75-D state, 51-action space, objective and non-Assignment operators.",
        "",
        "## Mean costs",
        "",
        "| Budget | Controller | Local repair | Global repair | Selected non-PPO baseline |",
        "|---:|---|---:|---:|---:|",
    ]
    for budget in (6, 12):
        for controller in CONTROLLERS:
            s = payload["budgets"][str(budget)]["controllers"][controller]
            lines.append(
                f"| {budget}s | {controller.upper()} | {s['local_mean_cost']:.4f} | "
                f"{s['global_mean_cost']:.4f} | {s['baseline_mean_cost']:.4f} |"
            )

    lines += [
        "",
        "## Primary: global-repair learned controller vs selected non-PPO baseline",
        "",
        "Negative delta means the learned controller has lower cost. Six-test Holm family (3 controllers × 2 budgets). The selected baseline is recorded in the JSON and must be identical at both budgets.",
        "",
        "| Budget | Controller | Mean delta % | 95% CI | W/L/T maps | Wilcoxon p | Holm p |",
        "|---:|---|---:|---:|---:|---:|---:|",
    ]
    for c in payload["primary_comparisons"]:
        ci = c["bootstrap95_relative_delta_percent"]
        lines.append(
            f"| {c['budget_seconds']}s | {c['controller'].upper()} | "
            f"{c['mean_relative_delta_percent']:+.4f}% | [{ci[0]:+.4f}, {ci[1]:+.4f}] | "
            f"{c['wins_candidate_lower']}/{c['wins_reference_lower']}/{c['ties']} | "
            f"{c['wilcoxon_p_raw']:.4g} | {c['primary_holm_adjusted_p']:.4g} |"
        )

    lines += [
        "",
        "## Secondary: global vs local repair for the same learned checkpoint family",
        "",
        "Negative delta means local repair is lower cost. Six-test Holm family.",
        "",
        "| Budget | Controller | Mean local-minus-global delta % | 95% CI | W/L/T maps | Wilcoxon p | Holm p |",
        "|---:|---|---:|---:|---:|---:|---:|",
    ]
    for c in payload["secondary_comparisons"]:
        ci = c["bootstrap95_relative_delta_percent"]
        lines.append(
            f"| {c['budget_seconds']}s | {c['controller'].upper()} | "
            f"{c['mean_relative_delta_percent']:+.4f}% | [{ci[0]:+.4f}, {ci[1]:+.4f}] | "
            f"{c['wins_candidate_lower']}/{c['wins_reference_lower']}/{c['ties']} | "
            f"{c['wilcoxon_p_raw']:.4g} | {c['secondary_holm_adjusted_p']:.4g} |"
        )

    lines += [
        "",
        "## Interpretation limits",
        "",
        "- BC/PPO/A2C were trained under local repair. The global-scope results are transfer evidence, not matched-environment training evidence.",
        "- A positive result should trigger matched global-scope BC teacher generation and PPO/A2C retraining before a final RL claim.",
        "- The selected non-RL baseline is chosen only from the same-source 10-seed finalist confirmation; it may be M1D Global, M2 Global or LinUCB Global.",
        "- This is development validation on the 24-map validation split, not blind-test evidence.",
    ]
    lines += [
        "",
        "## Descriptive sensitivity: global learned controllers vs M1D Global",
        "",
        "M1D Global was statistically tied with the selected M2 Global baseline in the same-source finalist confirmation. These comparisons are descriptive sensitivity checks and are not part of the primary six-test Holm family.",
        "",
        "| Budget | Controller | Mean delta % | 95% CI | W/L/T maps | Wilcoxon p (descriptive) |",
        "|---:|---|---:|---:|---:|---:|",
    ]
    for c in payload["secondary_vs_m1d_global_descriptive"]:
        ci = c["bootstrap95_relative_delta_percent"]
        lines.append(
            f"| {c['budget_seconds']}s | {c['controller'].upper()} | {c['mean_relative_delta_percent']:+.4f}% | "
            f"[{ci[0]:+.4f}, {ci[1]:+.4f}] | {c['wins_candidate_lower']}/"
            f"{c['wins_reference_lower']}/{c['ties']} | {c['wilcoxon_p_raw']:.4g} |")
    out_md.write_text("\n".join(lines) + "\n")
    print("\n".join(lines))


if __name__ == "__main__":
    main()
