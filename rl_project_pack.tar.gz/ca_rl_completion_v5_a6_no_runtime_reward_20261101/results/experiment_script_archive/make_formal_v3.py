#!/usr/bin/env python3
"""Create the locked 30-main + 6-stress formal suite with constructive witnesses.

This script only creates maps, hashes and feasible witnesses. It does not call
any optimizer and must not be used for tuning or map selection after results.
"""
import hashlib, json, math, random, sys
from pathlib import Path

ROOT=Path("/root/rivermind-data/ca_rl_completion_v5_staging/code")
OUT=ROOT/"datasets/formal_v3"
sys.path.insert(0,str(ROOT))
from lrphsd.problem import read_instance, empty_solution
from lrphsd.evaluator import evaluate

if OUT.exists():
    raise SystemExit(f"formal_v3 already exists; preserve it: {OUT}")
OUT.mkdir(parents=True)

def station_xy(ns, spacing):
    cols=math.ceil(math.sqrt(ns))
    return [((i%cols)*spacing,(i//cols)*spacing) for i in range(ns)]

def radial_point(rng, center, lo, hi, angle=None):
    theta=rng.uniform(0,2*math.pi) if angle is None else angle
    radius=rng.uniform(lo,hi)
    return (center[0]+radius*math.cos(theta),center[1]+radius*math.sin(theta))

def make_map(name, role, ns, nt, seed, distribution, spacing,
             energy_mode="normal", service=10.0, radius_band=(200.0,3600.0),
             clustered_angles=False):
    rng=random.Random(seed)
    stations=station_xy(ns,spacing)
    targets=[]
    owners=[]
    drones=[]
    owner_counts=[0]*ns
    for j in range(nt):
        si=j%ns
        local_index=owner_counts[si]
        owner_counts[si]+=1
        if distribution=="uniform":
            xy=radial_point(rng,stations[si],0.0,radius_band[1])
        elif distribution=="clustered":
            xy=radial_point(rng,stations[si],radius_band[0],radius_band[1])
        elif distribution=="boundary":
            xy=radial_point(rng,stations[si],radius_band[0],radius_band[1])
        elif distribution=="sparse":
            xy=radial_point(rng,stations[si],radius_band[0],radius_band[1])
        elif distribution=="tight_coverage":
            xy=radial_point(rng,stations[si],radius_band[0],radius_band[1])
        elif distribution=="load_imbalance":
            xy=radial_point(rng,stations[si],radius_band[0],radius_band[1])
        elif distribution=="combined":
            xy=radial_point(rng,stations[si],radius_band[0],radius_band[1])
        else:
            raise ValueError(distribution)

        if energy_mode=="normal":
            energy=0.2
            drone= local_index%2
        elif energy_mode=="imbalanced":
            # 40% high-energy targets are feasible only on the LD at this range.
            high=(j%5 in (0,1))
            energy=0.65 if high else 0.2
            drone=0 if high else 1
        elif energy_mode=="ld_only":
            energy=0.68
            drone=0
        else:
            raise ValueError(energy_mode)
        targets.append((xy[0],xy[1],energy,service))
        owners.append(si)
        drones.append(drone)

    lines=["CUST_NO XCOORD YCOORD ENERGY SERVICE"]
    for j,(x,y,e,s) in enumerate(targets,1):
        lines.append(f"{j} {x:.6f} {y:.6f} {e:.6f} {s:.6f}")
    for i,(x,y) in enumerate(stations,nt+1):
        lines.append(f"{i} {x:.6f} {y:.6f} 0 0")
    path=OUT/(name+".txt")
    path.write_text("\n".join(lines)+"\n",encoding="utf-8")

    ins=read_instance(path)
    # DABS is used for the feasibility witness; optimizer may choose other types.
    sol=empty_solution(ins,[2]*ns)
    for j,si in enumerate(owners):
        sol["routes"][si][drones[j]].append([j+1])
    audit=evaluate(ins,sol)
    if not audit["feasible"]:
        raise RuntimeError(f"{name} witness infeasible: {audit['issues'][:20]}")
    # Quantify assignment-transfer opportunity without running an optimizer.
    dabs_counts=[]
    sabs_counts=[]
    for target in ins.targets:
        dabs_counts.append(sum(
            math.hypot(target.x-st.x,target.y-st.y) <= ins.params.large_radius + 1e-7
            for st in ins.stations))
        sabs_counts.append(sum(
            math.hypot(target.x-st.x,target.y-st.y) <= ins.params.small_radius + 1e-7
            for st in ins.stations))
    witness_path=OUT/(name+".witness.json")
    witness_path.write_text(json.dumps(sol,separators=(",",":"))+"\n")
    return {
        "name":name,"role":role,"stations":ns,"targets":nt,
        "distribution":distribution,"generation_seed":seed,
        "station_spacing_m":spacing,"target_energy_mode":energy_mode,
        "service_minutes_per_target":service,
        "target_radius_band_m":[float(radius_band[0]),float(radius_band[1])],
        "instance_sha256":hashlib.sha256(path.read_bytes()).hexdigest(),
        "witness_sha256":hashlib.sha256(witness_path.read_bytes()).hexdigest(),
        "witness_cost":float(audit["cost"]),
        "witness_feasible":bool(audit["feasible"]),
        "mean_dabs_receivers":float(sum(dabs_counts)/len(dabs_counts)),
        "targets_with_multiple_dabs_receivers":int(sum(x>1 for x in dabs_counts)),
        "targets_with_multiple_sabs_receivers":int(sum(x>1 for x in sabs_counts)),
    }

rows=[]
# Main set: 5 size strata x 3 spatial distributions x 2 independent seeds = 30.
sizes=((8,50),(12,100),(16,150),(24,200),(32,300))
distributions=("uniform","clustered","boundary")
for ns,nt in sizes:
    for dist in distributions:
        for seed in (21001,21002):
            band={"uniform":(0,3600),"clustered":(250,1200),"boundary":(4600,4900)}[dist]
            rows.append(make_map(
                f"main_ns{ns:02d}_nt{nt:03d}_{dist}_s{seed}",
                "main",ns,nt,seed+ns*100+nt,dist,7500,
                "normal",10.0,band))

# Six structurally distinct extension stress cases.
stress_specs=[
    dict(name="stress_high_density_route",ns=8,nt=300,seed=31001,dist="uniform",
         spacing=7500,energy="normal",service=15.0,band=(0,3900)),
    dict(name="stress_sparse_long_distance",ns=8,nt=64,seed=31002,dist="sparse",
         spacing=22000,energy="normal",service=10.0,band=(4500,4950)),
    dict(name="stress_tight_receiver_coverage",ns=16,nt=160,seed=31003,dist="tight_coverage",
         spacing=12000,energy="normal",service=10.0,band=(4850,4980)),
    dict(name="stress_sd_ld_work_imbalance",ns=8,nt=160,seed=31004,dist="load_imbalance",
         spacing=10000,energy="imbalanced",service=10.0,band=(4500,4900)),
    dict(name="stress_boundary_concentration",ns=24,nt=192,seed=31005,dist="boundary",
         spacing=9000,energy="normal",service=10.0,band=(4800,4980)),
    dict(name="stress_joint_coverage_energy",ns=12,nt=120,seed=31006,dist="combined",
         spacing=11000,energy="ld_only",service=10.0,band=(4900,4990)),
]
for s in stress_specs:
    rows.append(make_map(s["name"],"stress",s["ns"],s["nt"],s["seed"],s["dist"],
                         s["spacing"],s["energy"],s["service"],s["band"]))

if len(rows)!=36 or sum(r["role"]=="main" for r in rows)!=30 or sum(r["role"]=="stress" for r in rows)!=6:
    raise RuntimeError("formal suite cardinality mismatch")
if len({r["instance_sha256"] for r in rows})!=36:
    raise RuntimeError("duplicate map hashes in formal suite")

# Prove byte-level independence from official, historical and older locked maps.
existing_hashes=set()
for base in (ROOT/"external/LRPHSD/data/Instances_Alg",ROOT/"datasets/locked_v2"):
    if base.exists():
        for p in base.glob("*.txt"):
            if p.is_file():
                existing_hashes.add(hashlib.sha256(p.read_bytes()).hexdigest())
overlap=existing_hashes & {r["instance_sha256"] for r in rows}
if overlap:
    raise RuntimeError(f"formal map hash overlaps existing data: {len(overlap)}")

generator_path=Path(__file__)
manifest={
 "schema":"CA-RL-TSALNS-formal-v3",
 "status":"GENERATED_WITNESS_VALIDATED_AND_RECEIVER_DIVERSITY_AUDITED_NOT_OPENED_TO_SOLVER",
 "purpose":"independent formal evaluation; not Liu original data",
 "generator_sha256":hashlib.sha256(generator_path.read_bytes()).hexdigest(),
 "counts":{"main":30,"stress":6,"total":36},
 "independence":{"hash_overlap_with_official_or_locked_v2":0,
                 "source_directories":["external/LRPHSD/data/Instances_Alg","datasets/locked_v2"]},
 "selection_policy":"all predeclared maps retained; no result-dependent exclusion",
 "witness_policy":"each target is served exactly once by a feasible one-target trip; independent evaluator used",
 "receiver_diversity_policy":"main strata deliberately vary alternative DABS/SABS coverage; stress strata include both overlapping and tight single-receiver cases",
 "solver_policy":"do not run any optimizer on this suite before algorithm/source/protocol freeze",
 "rows":rows,
}
mp=OUT/"manifest.json"
mp.write_text(json.dumps(manifest,indent=2)+"\n")
print("FORMAL_V3_GENERATED",manifest["counts"])
print("MAIN_STRATA",[(r["stations"],r["targets"],r["distribution"]) for r in rows if r["role"]=="main"][::2])
print("STRESS",[(r["name"],r["stations"],r["targets"],r["target_energy_mode"],r["target_radius_band_m"]) for r in rows if r["role"]=="stress"])
print("ALL_WITNESSES_FEASIBLE",all(r["witness_feasible"] for r in rows))
print("MAIN_RECEIVER_DIVERSITY",[(r["stations"],r["targets"],r["distribution"],r["targets_with_multiple_dabs_receivers"],r["targets_with_multiple_sabs_receivers"]) for r in rows if r["role"]=="main"])
print("STRESS_RECEIVER_DIVERSITY",[(r["name"],r["targets_with_multiple_dabs_receivers"]) for r in rows if r["role"]=="stress"])
print("HASH_OVERLAP",len(overlap))
print("MANIFEST_SHA256",hashlib.sha256(mp.read_bytes()).hexdigest())
