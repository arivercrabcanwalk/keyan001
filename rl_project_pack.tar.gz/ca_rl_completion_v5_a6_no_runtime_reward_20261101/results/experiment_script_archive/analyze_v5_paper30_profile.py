#!/usr/bin/env python3
"""Analyze the 30 original Liu cases under separate paper-A1 and Java-code profiles."""
import json
from pathlib import Path
from collections import Counter, defaultdict

import numpy as np

ROOT = Path("/root/rivermind-data/ca_rl_completion_v5_staging/code")
RESULTS = ROOT / "results"
OUT = RESULTS / "v5_paper30_profile_12s"
MANIFEST = RESULTS / "paper30_original_case_manifest.json"

import sys
sys.path.insert(0, str(ROOT))
from carl.stats import wilcoxon_signed_rank


def bootstrap_ci(values, seed, n_boot=20000):
    x = np.asarray(values, dtype=float)
    rng = np.random.default_rng(seed)
    idx = rng.integers(0, len(x), size=(n_boot, len(x)))
    means = x[idx].mean(axis=1)
    return [float(np.quantile(means, 0.025)), float(np.quantile(means, 0.975))]


def main():
    expected = json.loads(MANIFEST.read_text())
    expected_names = [r["name"] for r in expected["rows"]]
    run_manifest = json.loads((OUT / "manifest.json").read_text())
    if (run_manifest.get("finished") is None or run_manifest.get("errors") != 0
            or run_manifest.get("tasks") != 300
            or run_manifest.get("methods") != ["m0paper", "m0frozen"]
            or run_manifest.get("seeds") != [1, 2, 3, 4, 5]
            or float(run_manifest.get("seconds", -1)) != 12.0
            or len(run_manifest.get("instances", [])) != 30):
        raise RuntimeError("paper30 run manifest mismatch/incomplete")

    rows = [json.loads(p.read_text()) for p in sorted(OUT.glob("*__s*.json"))]
    if len(rows) != 300:
        raise RuntimeError(f"expected 300 rows, got {len(rows)}")
    code_hashes = set()
    instance_rows = defaultdict(dict)
    terminations = {m: Counter() for m in ("m0paper", "m0frozen")}
    full_iterations = {m: True for m in ("m0paper", "m0frozen")}
    for r in rows:
        if r.get("status") != "ok" or r.get("feasible") is not True:
            raise RuntimeError(f"invalid/infeasible result: {r.get('instance')} {r.get('method')} {r.get('seed')}")
        if r.get("protocol") != ("paper-parameters-on-v6" if r["method"] == "m0paper" else "frozen-v6-code-profile"):
            raise RuntimeError(f"wrong parameter profile tag: {r.get('method')} {r.get('protocol')}")
        provenance = r.get("provenance") or {}
        code_hash = provenance.get("code_sha256")
        if not code_hash:
            raise RuntimeError("missing source hash")
        code_hashes.add(code_hash)
        method = r["method"]
        terminations[method][r.get("termination_reason")] += 1
        if r.get("termination_reason") != "outer_limit" or int(r.get("outer_iterations_attempted") or 0) != 500:
            full_iterations[method] = False
        instance_rows[r["instance"]].setdefault(method, []).append(r)

    if len(code_hashes) != 1:
        raise RuntimeError(f"mixed source hashes: {code_hashes}")
    if sorted(instance_rows) != sorted(expected_names):
        raise RuntimeError("paper30 instance set does not match locked original-case manifest")
    for name in expected_names:
        for method in ("m0paper", "m0frozen"):
            got = instance_rows[name].get(method, [])
            if len(got) != 5 or sorted(int(x["seed"]) for x in got) != [1, 2, 3, 4, 5]:
                raise RuntimeError(f"missing seed rows: {name} {method}")

    summary = {}
    for method in ("m0paper", "m0frozen"):
        method_rows = [r for r in rows if r["method"] == method]
        costs = np.asarray([float(r["cost"]) for r in method_rows])
        summary[method] = {
            "n_tasks": len(method_rows),
            "mean_cost": float(costs.mean()),
            "median_cost": float(np.median(costs)),
            "std_cost": float(costs.std(ddof=1)),
            "feasibility_rate": float(np.mean([r["feasible"] for r in method_rows])),
            "mean_solver_seconds": float(np.mean([r["solver_seconds"] for r in method_rows])),
            "mean_end_to_end_seconds": float(np.mean([r["end_to_end_seconds"] for r in method_rows])),
            "termination_reasons": dict(terminations[method]),
            "all_500_outer_iterations_completed": bool(full_iterations[method]),
        }

    map_costs = {}
    for name in expected_names:
        map_costs[name] = {}
        for method in ("m0paper", "m0frozen"):
            map_costs[name][method] = float(np.mean([float(r["cost"]) for r in instance_rows[name][method]]))
    names = sorted(map_costs)
    paper = np.asarray([map_costs[n]["m0paper"] for n in names])
    frozen = np.asarray([map_costs[n]["m0frozen"] for n in names])
    delta = 100.0 * (paper / frozen - 1.0)
    stat = wilcoxon_signed_rank(paper, frozen)
    paired = {
        "n_maps": len(names),
        "mean_relative_delta_percent": float(delta.mean()),
        "median_relative_delta_percent": float(np.median(delta)),
        "paper_lower_cost_wins": int((delta < -1e-9).sum()),
        "frozen_lower_cost_wins": int((delta > 1e-9).sum()),
        "ties": int((np.abs(delta) <= 1e-9).sum()),
        "wilcoxon_p_raw": float(stat["p_value"]),
        "rank_biserial": float(stat.get("rank_biserial", 0.0)),
        "bootstrap95_relative_delta_percent": bootstrap_ci(delta, 20261031),
        "map_deltas": {n: float(v) for n, v in zip(names, delta)},
    }

    small_groups = {"3_10", "3_15", "3_20", "4_20", "4_25", "4_30", "5_35"}
    group_summary = []
    for prefix in sorted({ "_".join(n.split("_")[:2]) for n in names }):
        group_names = [n for n in names if n.startswith(prefix + "_")]
        group_d = [map_costs[n]["m0paper"] / map_costs[n]["m0frozen"] - 1.0 for n in group_names]
        group_summary.append({
            "size_group": prefix,
            "paper_table": "Table 1 small" if prefix in small_groups else "Table 2 medium/large",
            "n_maps": len(group_names),
            "paper_mean_cost": float(np.mean([map_costs[n]["m0paper"] for n in group_names])),
            "frozen_mean_cost": float(np.mean([map_costs[n]["m0frozen"] for n in group_names])),
            "mean_relative_delta_percent": float(100.0 * np.mean(group_d)),
        })

    payload = {
        "schema": "v5_paper30_parameter_profile_comparison_v1",
        "interpretation": "corrected V6 Python engine under separate Table A1 and released-Java parameter profiles; not byte-for-byte Java execution",
        "instance_manifest_sha256": __import__("hashlib").sha256(MANIFEST.read_bytes()).hexdigest(),
        "source_sha256": next(iter(code_hashes)),
        "run_manifest": run_manifest,
        "methods": summary,
        "paired_comparison": paired,
        "by_size_group": group_summary,
        "full_iteration_gate_pass": all(full_iterations.values()),
        "caveat": "The 1.12% statement in the paper refers to the 21 small Table 1 cases, not all 30 cases. The official Java source physical-model defect remains separately documented.",
    }
    (OUT / "analysis.json").write_text(json.dumps(payload, indent=2) + "\n")

    lines = [
        "# Liu original 30-case parameter-profile comparison",
        "",
        "This is a controlled comparison of the paper Table A1 profile and the released-Java parameter profile using the corrected V6 Python engine. It is not byte-for-byte execution of the official Java source.",
        "",
        "## Run integrity",
        "",
        f"- Tasks: {len(rows)}/300; all feasible: yes",
        f"- Common source hash: {payload['source_sha256']}",
        f"- All 500 outer iterations completed for both profiles: {payload['full_iteration_gate_pass']}",
        "",
        "| Profile | Mean cost | Median | SD | Feasibility | Mean solver s | Termination |",
        "|---|---:|---:|---:|---:|---:|---|",
    ]
    for method, label in (("m0paper", "Paper Table A1"), ("m0frozen", "Released Java profile")):
        s = summary[method]
        lines.append(
            f"| {label} | {s['mean_cost']:.4f} | {s['median_cost']:.4f} | {s['std_cost']:.4f} | "
            f"{s['feasibility_rate']:.1%} | {s['mean_solver_seconds']:.3f} | {s['termination_reasons']} |")
    ci = paired["bootstrap95_relative_delta_percent"]
    lines += [
        "",
        "## Paired map-level comparison",
        "",
        "Positive delta means Paper Table A1 has higher/worse cost than the released-Java parameter profile.",
        "",
        f"- Mean relative delta: {paired['mean_relative_delta_percent']:+.4f}%",
        f"- 95% bootstrap CI: [{ci[0]:+.4f}, {ci[1]:+.4f}]%",
        f"- W/L/T (Paper lower / Frozen lower / tie): {paired['paper_lower_cost_wins']}/{paired['frozen_lower_cost_wins']}/{paired['ties']}",
        f"- Wilcoxon p: {paired['wilcoxon_p_raw']:.6g}",
        f"- Rank-biserial effect: {paired['rank_biserial']:+.4f}",
        "",
        "## By original paper size group",
        "",
        "| Group | Paper table | Maps | Paper mean | Frozen mean | Delta % |",
        "|---|---|---:|---:|---:|---:|",
    ]
    for r in group_summary:
        lines.append(
            f"| {r['size_group']} | {r['paper_table']} | {r['n_maps']} | {r['paper_mean_cost']:.4f} | "
            f"{r['frozen_mean_cost']:.4f} | {r['mean_relative_delta_percent']:+.4f}% |")
    lines += [
        "",
        "## Interpretation boundary",
        "",
        "The 30 original cases comprise 21 small Table 1 cases and 9 medium/large Table 2 cases. This run compares two parameter profiles; it does not reproduce the paper's Gurobi comparison or validate the official Java source's SABS physical behavior. Keep those claims separate.",
    ]
    (OUT / "analysis.md").write_text("\n".join(lines) + "\n")
    print("\n".join(lines))
    if not payload["full_iteration_gate_pass"]:
        raise SystemExit("one or more runs hit the time budget before 500 outer iterations; do not label this a full-iteration profile comparison")


if __name__ == "__main__":
    main()
