#!/usr/bin/env bash
set -euo pipefail
ROOT=/root/rivermind-data/ca_rl_completion_v5_staging/code
cd "$ROOT"
while [ ! -f results/V5_BC_GLOBAL_ABLATION_6S_COMPLETE ]; do sleep 30; done
[ ! -e results/V5_M2_GLOBAL_NOJOINT_10SEED_COMPLETE ] || exit 0
for d in results/v5_m2_global_nojoint_10seed_6s results/v5_m2_global_nojoint_10seed_12s; do
  [ ! -e "$d" ] || { echo "Existing output requires inspection: $d" >&2; exit 40; }
done
cp carl/runner.py results/experiment_script_archive/runner_pre_m2_global_nojoint_20261101.py
/opt/conda/bin/python - <<'PY'
from pathlib import Path
p=Path("carl/runner.py")
s=p.read_text()
anchor='''    "m2_global_asg": {"controller": "m2", "repair_scope_mode": "global_assignment"},
'''
addition='''    "m2_global_nojoint": {"controller": "m2", "repair_scope_mode": "global_assignment",
                          "families": (0, 1, 2)},
'''
if s.count(anchor)!=1:
    raise SystemExit(f"expected one m2_global_asg registry entry, found {s.count(anchor)}")
if '"m2_global_nojoint"' in s:
    raise SystemExit("m2_global_nojoint already registered; inspect before proceeding")
p.write_text(s.replace(anchor,anchor+addition))
PY
/opt/conda/bin/python -m py_compile carl/runner.py
bash results/experiment_script_archive/run_v5_m2_global_nojoint_10seed.sh
