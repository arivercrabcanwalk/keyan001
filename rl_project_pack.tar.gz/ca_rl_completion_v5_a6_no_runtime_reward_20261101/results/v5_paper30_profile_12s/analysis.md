# Liu original 30-case parameter-profile comparison

This is a controlled comparison of the paper Table A1 profile and the released-Java parameter profile using the corrected V6 Python engine. It is not byte-for-byte execution of the official Java source.

## Run integrity

- Tasks: 300/300; all feasible: yes
- Common source hash: eb6738811b96c15313600fea757eb060521181b7be55da914af3ab945b40ed48
- All 500 outer iterations completed for both profiles: True

| Profile | Mean cost | Median | SD | Feasibility | Mean solver s | Termination |
|---|---:|---:|---:|---:|---:|---|
| Paper Table A1 | 374.9804 | 311.9762 | 195.2525 | 100.0% | 4.689 | {'outer_limit': 150} |
| Released Java profile | 373.6061 | 311.6494 | 193.4418 | 100.0% | 2.450 | {'outer_limit': 150} |

## Paired map-level comparison

Positive delta means Paper Table A1 has higher/worse cost than the released-Java parameter profile.

- Mean relative delta: +0.2393%
- 95% bootstrap CI: [+0.0986, +0.4024]%
- W/L/T (Paper lower / Frozen lower / tie): 3/18/9
- Wilcoxon p: 0.000292778
- Rank-biserial effect: +0.8355

## By original paper size group

| Group | Paper table | Maps | Paper mean | Frozen mean | Delta % |
|---|---|---:|---:|---:|---:|
| 3_10 | Table 1 small | 3 | 137.3821 | 137.2172 | +0.1148% |
| 3_15 | Table 1 small | 3 | 183.9994 | 183.9994 | +0.0000% |
| 3_20 | Table 1 small | 3 | 219.8238 | 219.9898 | -0.0809% |
| 4_20 | Table 1 small | 3 | 250.3626 | 250.3197 | +0.0155% |
| 4_25 | Table 1 small | 3 | 294.7202 | 294.7828 | -0.0214% |
| 4_30 | Table 1 small | 3 | 342.1063 | 340.7559 | +0.3783% |
| 5_35 | Table 1 small | 3 | 405.3933 | 403.8122 | +0.3813% |
| 6_50 | Table 2 medium/large | 3 | 524.8590 | 523.0167 | +0.3489% |
| 7_65 | Table 2 medium/large | 3 | 641.4090 | 637.8928 | +0.5420% |
| 8_80 | Table 2 medium/large | 3 | 749.7487 | 744.2741 | +0.7148% |

## Interpretation boundary

The 30 original cases comprise 21 small Table 1 cases and 9 medium/large Table 2 cases. This run compares two parameter profiles; it does not reproduce the paper's Gurobi comparison or validate the official Java source's SABS physical behavior. Keep those claims separate.


## Exact parameter-profile differences

The result-row provenance hashes were checked against the two config files. The observed differences are:

| Parameter | Paper Table A1 profile | Released Java parameter profile |
|---|---:|---:|
| local_iterations | 500 | 100 |
| profile | paper supplementary parameter profile; distinct from author's Java code profile | frozen-v6 / Java-code parameter profile |
| weight_upper | 0.5 | 5.0 |

- Paper Table A1 config SHA256: 163e6dccbf904a09efe34a27fbc5dbc836d7fa03762d10a646e03cdc4f945b3d
- Released Java parameter config SHA256: bc7728c63336ec3ceb47d6986e94d3fd78fb4bcb0d45c6137e426e7a8bcb1ff4
