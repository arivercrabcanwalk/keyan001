# BC Global + M2 Global NoJoint — independent acceptance audit

Audit UTC: 2026-11-01T04:46:58.952149+00:00
Overall: PASS

## BC Global ablation

- Status: PASS
- Rows: 1944/1944
- Source hashes: ['6faccf7775a700286183e1588e42447f2a378ecf3f2c096ebf3f84680840d8ad']
- Three model seeds each passed manifest, 648-row, 648-solution, feasibility, repair-scope, task-identity and checkpoint-hash checks.

## M2 Global NoJoint

- Status: PASS
- Source hashes across 6s/12s: ['8a91e7df6a1f1f92617d33a76ba3f9157663403e776ff163048af6c27eb08977']
- Both budgets passed 480-row, 480-solution, 24-map, 10-seed, feasibility, status and repair-scope checks.
- Effective NoJoint exclusion was verified from raw counters: family-3 attempts/feasible/accepted/improved and operator IDs 12–16 were all zero.
- Full M2 Global Assignment retained nonzero family-3 activity in both budgets.

## Paired development results

| Budget | NoJoint relative cost delta | 95% CI | Wilcoxon p | Holm p |
|---:|---:|---:|---:|---:|
| 6s | +0.0019% | [-0.0558, +0.0707]% | 0.5417 | 1 |
| 12s | +0.0128% | [-0.0074, +0.0427]% | 0.791 | 1 |

## Interpretation boundary

- These are 24-map development-validation results, not formal blind-test evidence.
- BC checkpoints were trained under Local repair and evaluated with Global Assignment repair; BC feature zeroing is inference-time sensitivity analysis, not retrained causal ablation.
- M2 NoJoint is a true family-3 exclusion according to raw execution counters, but its paired cost contrasts do not establish a significant Joint-family marginal benefit.
- No RL independent gain is established by these experiments.

Audit script SHA256: c9e8f8763d3b3eab27b52a8fe35fc73bfeefe17fe7a0500ce26ec2a4a1933423
