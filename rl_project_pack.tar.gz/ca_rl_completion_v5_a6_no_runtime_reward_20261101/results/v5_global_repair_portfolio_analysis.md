# Non-PPO controller portfolio under global Assignment repair

The four new controllers were evaluated with global Assignment receiver scope using five solver seeds. M1D Global and M2 Global references use the same first five seeds from the completed 10-seed scope matrix. The reference code hash is recorded separately from the portfolio code hash because the runner registry was extended; the search, neighborhood, evaluator and objective modules are unchanged. Any competitive method must be rerun head-to-head under one frozen source version.

## Method summary

| Budget | Method | Mean cost | Median | SD | Feasibility | Solver s | End-to-end s | Steps |
|---:|---|---:|---:|---:|---:|---:|---:|---:|
| 6s | m1_global_asg | 458.0335 | 361.5166 | 265.2531 | 100.0% | 6.000 | 6.011 | 19490.4 |
| 6s | m3_global_asg | 460.1126 | 362.9049 | 267.2975 | 100.0% | 6.000 | 6.010 | 16934.5 |
| 6s | m4_global_asg | 457.6393 | 361.5932 | 263.8510 | 100.0% | 6.000 | 6.009 | 10990.7 |
| 6s | m5_global_asg | 458.2427 | 361.5324 | 265.1506 | 100.0% | 6.000 | 6.008 | 13031.7 |
| 12s | m1_global_asg | 458.0545 | 361.5166 | 265.4520 | 100.0% | 12.000 | 12.011 | 36846.8 |
| 12s | m3_global_asg | 459.6201 | 362.1611 | 266.8567 | 100.0% | 12.000 | 12.010 | 31483.0 |
| 12s | m4_global_asg | 457.3236 | 361.5254 | 263.4079 | 100.0% | 12.000 | 12.009 | 21963.2 |
| 12s | m5_global_asg | 457.7557 | 361.5166 | 264.6952 | 100.0% | 12.000 | 12.009 | 25627.9 |

## Comparisons against M2 Global

Negative delta means the new controller has lower cost. Eight-test Holm family (four controllers × two budgets).

| Budget | Method | Mean delta % | 95% CI | W/L/T maps | Wilcoxon p | Holm p |
|---:|---|---:|---:|---:|---:|---:|
| 6s | m1_global_asg | +0.1111% | [+0.0523, +0.1775] | 0/13/11 | 0.0002441 | 0.0009766 |
| 6s | m3_global_asg | +0.4578% | [+0.3023, +0.6240] | 1/21/2 | 3.338e-06 | 2.337e-05 |
| 6s | m4_global_asg | +0.1719% | [+0.0165, +0.4415] | 6/15/3 | 0.0888 | 0.1776 |
| 6s | m5_global_asg | +0.1653% | [+0.0998, +0.2414] | 0/18/6 | 7.629e-06 | 4.578e-05 |
| 12s | m1_global_asg | +0.1244% | [+0.0580, +0.2053] | 0/12/12 | 0.0004883 | 0.001465 |
| 12s | m3_global_asg | +0.3871% | [+0.2398, +0.5479] | 0/20/4 | 1.907e-06 | 1.526e-05 |
| 12s | m4_global_asg | +0.1482% | [-0.0217, +0.4216] | 6/15/3 | 0.2877 | 0.2877 |
| 12s | m5_global_asg | +0.1095% | [+0.0677, +0.1568] | 0/17/7 | 1.526e-05 | 7.629e-05 |

## Comparisons against M1D Global

Negative delta means the new controller has lower cost. Eight-test Holm family (four controllers × two budgets).

| Budget | Method | Mean delta % | 95% CI | W/L/T maps | Wilcoxon p | Holm p |
|---:|---|---:|---:|---:|---:|---:|
| 6s | m1_global_asg | +0.0954% | [+0.0444, +0.1571] | 1/12/11 | 0.0007324 | 0.003357 |
| 6s | m3_global_asg | +0.4421% | [+0.2874, +0.6102] | 1/21/2 | 6.676e-06 | 4.673e-05 |
| 6s | m4_global_asg | +0.1563% | [-0.0162, +0.4402] | 7/14/3 | 0.3205 | 0.6409 |
| 6s | m5_global_asg | +0.1497% | [+0.0690, +0.2428] | 1/17/6 | 0.0006714 | 0.003357 |
| 12s | m1_global_asg | +0.1155% | [+0.0493, +0.1920] | 2/10/12 | 0.002441 | 0.007324 |
| 12s | m3_global_asg | +0.3782% | [+0.2334, +0.5315] | 0/20/4 | 1.907e-06 | 1.526e-05 |
| 12s | m4_global_asg | +0.1393% | [-0.0257, +0.4105] | 6/15/3 | 0.5621 | 0.6409 |
| 12s | m5_global_asg | +0.1006% | [+0.0580, +0.1469] | 1/16/7 | 7.629e-05 | 0.0004578 |

## Interpretation

- Do not declare M2 Global the strongest controller until all comparisons are analyzed.
- The baseline/source-hash difference is limited to the runner method registry; search.py and neighborhood.py are the same. If any new controller is competitive, rerun finalists under one identical source version.
- Development validation only; no blind-test claim is allowed for historical geometry seeds 9–10.
