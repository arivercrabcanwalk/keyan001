# BC/PPO/A2C transfer under global Assignment repair

This is a transfer diagnostic: all learned checkpoints were trained with local Assignment repair. Global-scope evaluation changes the repair dynamics but keeps the same 75-D state, 51-action space, objective and non-Assignment operators.

## Mean costs

| Budget | Controller | Local repair | Global repair | Selected non-PPO baseline |
|---:|---|---:|---:|---:|
| 6s | BC | 458.2328 | 457.3231 | 457.2804 |
| 6s | PPO | 458.4512 | 457.6960 | 457.2804 |
| 6s | A2C | 458.1649 | 457.4125 | 457.2804 |
| 12s | BC | 458.0009 | 457.2031 | 456.8951 |
| 12s | PPO | 457.9664 | 457.4321 | 456.8951 |
| 12s | A2C | 457.9847 | 457.3144 | 456.8951 |

## Primary: global-repair learned controller vs selected non-PPO baseline

Negative delta means the learned controller has lower cost. Six-test Holm family (3 controllers × 2 budgets). The selected baseline is recorded in the JSON and must be identical at both budgets.

| Budget | Controller | Mean delta % | 95% CI | W/L/T maps | Wilcoxon p | Holm p |
|---:|---|---:|---:|---:|---:|---:|
| 6s | BC | +0.0104% | [-0.0324, +0.0459] | 4/9/11 | 0.1465 | 0.1465 |
| 6s | PPO | +0.0588% | [+0.0208, +0.0988] | 1/12/11 | 0.0105 | 0.03149 |
| 6s | A2C | +0.0210% | [-0.0206, +0.0560] | 2/11/11 | 0.03979 | 0.07959 |
| 12s | BC | +0.0416% | [+0.0144, +0.0741] | 1/11/12 | 0.003418 | 0.01367 |
| 12s | PPO | +0.0699% | [+0.0350, +0.1083] | 1/11/12 | 0.0009766 | 0.004883 |
| 12s | A2C | +0.0536% | [+0.0227, +0.0890] | 0/12/12 | 0.0004883 | 0.00293 |

## Secondary: global vs local repair for the same learned checkpoint family

Negative delta means local repair is lower cost. Six-test Holm family.

| Budget | Controller | Mean local-minus-global delta % | 95% CI | W/L/T maps | Wilcoxon p | Holm p |
|---:|---|---:|---:|---:|---:|---:|
| 6s | BC | +0.1261% | [+0.0641, +0.1968] | 1/15/8 | 0.0002136 | 0.001282 |
| 6s | PPO | +0.1039% | [+0.0511, +0.1635] | 1/15/8 | 0.0002136 | 0.001282 |
| 6s | A2C | +0.1058% | [+0.0563, +0.1598] | 1/13/10 | 0.0002441 | 0.001282 |
| 12s | BC | +0.1063% | [+0.0472, +0.1751] | 1/12/11 | 0.0007324 | 0.001465 |
| 12s | PPO | +0.0745% | [+0.0314, +0.1225] | 1/11/12 | 0.006836 | 0.006836 |
| 12s | A2C | +0.0932% | [+0.0493, +0.1425] | 0/12/12 | 0.0004883 | 0.001465 |

## Interpretation limits

- BC/PPO/A2C were trained under local repair. The global-scope results are transfer evidence, not matched-environment training evidence.
- A positive result should trigger matched global-scope BC teacher generation and PPO/A2C retraining before a final RL claim.
- The selected non-RL baseline is chosen only from the same-source 10-seed finalist confirmation; it may be M1D Global, M2 Global or LinUCB Global.
- This is development validation on the 24-map validation split, not blind-test evidence.

## Descriptive sensitivity: global learned controllers vs M1D Global

M1D Global was statistically tied with the selected M2 Global baseline in the same-source finalist confirmation. These comparisons are descriptive sensitivity checks and are not part of the primary six-test Holm family.

| Budget | Controller | Mean delta % | 95% CI | W/L/T maps | Wilcoxon p (descriptive) |
|---:|---|---:|---:|---:|---:|
| 6s | BC | +0.0213% | [-0.0032, +0.0499] | 4/8/12 | 0.3013 |
| 6s | PPO | +0.0698% | [+0.0302, +0.1191] | 0/12/12 | 0.0004883 |
| 6s | A2C | +0.0319% | [+0.0078, +0.0606] | 2/10/12 | 0.04248 |
| 12s | BC | +0.0277% | [+0.0027, +0.0580] | 4/8/12 | 0.09229 |
| 12s | PPO | +0.0561% | [+0.0224, +0.0936] | 2/10/12 | 0.003418 |
| 12s | A2C | +0.0397% | [+0.0087, +0.0801] | 2/10/12 | 0.006836 |
