# Phase 1 — affected-subproblem vs global reconstruction

Validation maps: 24; generator/solver seeds: 3; generated proposals: 712; unavailable: 800; candidate rows: 1731; task errors: 0.

The statistical unit is the map. Candidate proposals are averaged within map and are not treated as independent samples.

## Candidate repair-mode summary

| Operator | Generated proposals | Mode | Feasible / attempted | Feasibility % | Mean delta % (feasible) | Mean apply ms | Mean changed stations | Preservation pass % |
|---|---:|---|---:|---:|---:|---:|---:|---:|
| 5 cross_station_transfer | 189 | local_scoped | 189/189 | 100.0% | +0.3472 | 0.0216 | 2.00 | 100.0% |
| 5 cross_station_transfer | 189 | global_target_repair | 189/189 | 100.0% | -0.4312 | 0.0218 | 1.80 | — |
| 6 drone_reassignment | 216 | local_scoped | 216/216 | 100.0% | -0.0605 | 0.0202 | 1.00 | 100.0% |
| 6 drone_reassignment | 216 | global_target_repair | 216/216 | 100.0% | -0.5785 | 0.0208 | 1.26 | — |
| 12 joint_open_steal | 189 | local_scoped | 189/189 | 100.0% | +12.0472 | 0.0179 | 2.59 | 100.0% |
| 12 joint_open_steal | 189 | global_target_repair | 189/189 | 100.0% | +12.0427 | 0.0224 | 2.54 | — |
| 12 joint_open_steal | 189 | full_system_greedy | 189/189 | 100.0% | +11.9720 | 0.0196 | 2.67 | — |
| 13 joint_close_shift | 18 | local_scoped | 18/18 | 100.0% | -4.3945 | 0.0501 | 4.50 | 100.0% |
| 13 joint_close_shift | 18 | global_target_repair | 18/18 | 100.0% | -4.3945 | 0.0469 | 4.50 | — |
| 13 joint_close_shift | 18 | full_system_greedy | 18/18 | 100.0% | -4.3125 | 0.0309 | 4.50 | — |
| 14 joint_upgrade_absorb | 45 | local_scoped | 45/45 | 100.0% | +4.7129 | 0.0175 | 2.18 | 100.0% |
| 14 joint_upgrade_absorb | 45 | global_target_repair | 45/45 | 100.0% | +4.5006 | 0.0192 | 2.00 | — |
| 14 joint_upgrade_absorb | 45 | full_system_greedy | 45/45 | 100.0% | +5.8503 | 0.0181 | 2.22 | — |
| 15 joint_downgrade_reallocate | 28 | local_scoped | 28/28 | 100.0% | -4.3534 | 0.0281 | 1.93 | 100.0% |
| 15 joint_downgrade_reallocate | 28 | global_target_repair | 28/28 | 100.0% | -4.5360 | 0.0309 | 2.57 | — |
| 15 joint_downgrade_reallocate | 28 | full_system_greedy | 28/28 | 100.0% | -4.4449 | 0.0191 | 1.93 | — |
| 16 joint_swap_absorb | 27 | local_scoped | 27/27 | 100.0% | +0.2677 | 0.0549 | 6.48 | 100.0% |
| 16 joint_swap_absorb | 27 | global_target_repair | 27/27 | 100.0% | +0.2677 | 0.0509 | 6.48 | — |
| 16 joint_swap_absorb | 27 | full_system_greedy | 27/27 | 100.0% | -0.0370 | 0.0339 | 6.15 | — |

## Paired map-level cost comparisons

Negative left-minus-right values favor the left repair mode. Conditional cost comparisons include only proposals feasible under both modes.

| Operator | Comparison | Common feasible proposals | Maps | Mean map difference (pp) | 95% bootstrap CI | W/L/T maps | Wilcoxon p | Holm p (12 comparisons) |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| op5 | local_scoped_vs_global_target_repair | 189 | 21 | +0.7784 | [+0.5601, +1.0268] | 0/20/1 | 1.907e-06 | 2.098e-05 |
| op6 | local_scoped_vs_global_target_repair | 216 | 24 | +0.5181 | [+0.3426, +0.7269] | 1/23/0 | 8.345e-07 | 1.001e-05 |
| op12 | local_scoped_vs_global_target_repair | 189 | 21 | +0.0045 | [-0.2463, +0.2133] | 6/9/6 | 0.6387 | 1 |
| op12 | local_scoped_vs_full_system_greedy | 189 | 21 | +0.0752 | [-0.3267, +0.4866] | 10/9/2 | 0.8288 | 1 |
| op13 | local_scoped_vs_global_target_repair | 18 | 2 | +0.0000 | [+nan, +nan] | 0/0/2 | 1 | 1 |
| op13 | local_scoped_vs_full_system_greedy | 18 | 2 | -0.0820 | [+nan, +nan] | 2/0/0 | 1 | 1 |
| op14 | local_scoped_vs_global_target_repair | 45 | 5 | +0.2123 | [+0.0576, +0.3725] | 0/4/1 | 0.125 | 1 |
| op14 | local_scoped_vs_full_system_greedy | 45 | 5 | -1.1374 | [-2.1793, -0.3965] | 5/0/0 | 0.0625 | 0.5625 |
| op15 | local_scoped_vs_global_target_repair | 28 | 8 | +0.3214 | [+0.1352, +0.5396] | 0/6/2 | 0.03125 | 0.3125 |
| op15 | local_scoped_vs_full_system_greedy | 28 | 8 | +0.3027 | [-0.2060, +0.6789] | 2/6/0 | 0.25 | 1 |
| op16 | local_scoped_vs_global_target_repair | 27 | 3 | +0.0000 | [+nan, +nan] | 0/0/3 | 1 | 1 |
| op16 | local_scoped_vs_full_system_greedy | 27 | 3 | +0.3047 | [+nan, +nan] | 1/2/0 | 1 | 1 |

## Interpretation limits

- This is a candidate-level mechanism experiment from a common greedy incumbent, not a full solver-budget comparison.
- Global-target repair preserves the same selected target IDs but expands receiver scope to all open stations/drones.
- Full-system greedy applies the same station-type changes but reconstructs every target; selected IDs are not hard destination constraints in that mode.
- The full-system greedy rebuild is a specific deterministic reconstruction baseline, not a global optimum.
- Local preservation was checked against the computed touched scope. It is not proof that the scope is the mathematically minimal dependency closure.
- Use these results to decide which operators can legitimately be described as affected-subproblem repair. Do not generalize beyond the tested operators and maps.
