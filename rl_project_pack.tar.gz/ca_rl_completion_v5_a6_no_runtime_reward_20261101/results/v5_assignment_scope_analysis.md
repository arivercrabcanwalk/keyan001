# Assignment receiver-scope full-search validation

The experiment compares local Assignment repair with global receiver-scope repair in the full solver. All methods use the same 24 validation maps, solver seeds 101/102/103 and 6s/12s solver budgets.

## Method summary

| Budget | Method | Mean cost | Median | SD | Feasibility | Mean solver s | Mean end-to-end s | Mean steps |
|---:|---|---:|---:|---:|---:|---:|---:|---:|
| 6s | m1d | 458.0616 | 361.5166 | 265.9899 | 100.0% | 6.000 | 6.011 | 17754.1 |
| 6s | m1d_global_asg | 457.4904 | 361.5166 | 265.2489 | 100.0% | 6.000 | 6.011 | 18451.3 |
| 6s | m2 | 457.7496 | 361.8170 | 265.5434 | 100.0% | 6.000 | 6.010 | 14357.2 |
| 6s | m2_global_asg | 457.1394 | 361.5166 | 264.9488 | 100.0% | 6.000 | 6.009 | 14955.6 |
| 12s | m1d | 457.8831 | 361.5166 | 265.6962 | 100.0% | 12.000 | 12.012 | 35356.0 |
| 12s | m1d_global_asg | 457.3937 | 361.5166 | 265.1287 | 100.0% | 12.000 | 12.012 | 36729.1 |
| 12s | m2 | 457.5896 | 361.5844 | 265.4159 | 100.0% | 12.000 | 12.011 | 28413.0 |
| 12s | m2_global_asg | 457.0483 | 361.5166 | 264.7625 | 100.0% | 12.000 | 12.009 | 29597.5 |

## Paired map-level comparisons

Negative delta means the candidate method has lower cost than the reference.

| Budget | Candidate | Reference | Mean delta % | 95% bootstrap CI | W/L/T maps | Wilcoxon p | Holm p (6 tests) |
|---:|---|---|---:|---:|---:|---:|---:|
| 6s | m1d_global_asg | m1d | -0.0763% | [-0.1634, +0.0183] | 11/1/12 | 0.03418 | 0.06836 |
| 6s | m2_global_asg | m2 | -0.0890% | [-0.1411, -0.0397] | 11/1/12 | 0.003418 | 0.01367 |
| 6s | m1d_global_asg | m2_global_asg | +0.0536% | [+0.0102, +0.0987] | 2/10/12 | 0.04248 | 0.06836 |
| 12s | m1d_global_asg | m1d | -0.0687% | [-0.1246, -0.0126] | 11/2/11 | 0.01709 | 0.05127 |
| 12s | m2_global_asg | m2 | -0.0736% | [-0.1116, -0.0385] | 12/0/12 | 0.0004883 | 0.00293 |
| 12s | m1d_global_asg | m2_global_asg | +0.0489% | [+0.0212, +0.0818] | 0/12/12 | 0.0004883 | 0.00293 |

## Interpretation

- This is a development validation experiment, not a blind test.
- The global receiver scope applies only to Assignment-family operators 5 and 6; other families retain the original repair behavior.
- Use the paired map-level 6-test Holm family for claims. Do not select a new primary method from the historical test split.
- If global receiver scope does not produce corrected, stable improvement in the full solver, retain local repair despite the candidate-level microbenchmark.
