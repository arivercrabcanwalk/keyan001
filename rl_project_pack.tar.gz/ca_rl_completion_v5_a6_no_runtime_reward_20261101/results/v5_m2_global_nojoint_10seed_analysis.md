# M2 Global Joint-family leave-out confirmation (10 seeds)

All methods use Global Assignment repair and one common source version. Positive delta means removing the Joint family is worse than full M2 Global.

| Budget | Method | Mean cost | Median | SD | Feasibility | Solver s | End-to-end s |
|---:|---|---:|---:|---:|---:|---:|---:|
| 6s | m2_global_asg | 457.3311 | 361.5166 | 263.7547 | 100.0% | 6.000 | 6.011 |
| 6s | m2_global_nojoint | 457.3124 | 361.5166 | 263.6406 | 100.0% | 6.000 | 6.009 |
| 12s | m2_global_asg | 457.0084 | 361.5166 | 263.3910 | 100.0% | 12.000 | 12.011 |
| 12s | m2_global_nojoint | 457.0678 | 361.5166 | 263.3622 | 100.0% | 12.000 | 12.009 |

## Paired map-level comparison

| Budget | Mean delta % | 95% CI | W/L/T | Wilcoxon p | Holm p |
|---:|---:|---:|---:|---:|---:|
| 6s | +0.0019% | [-0.0558, +0.0707] | 8/5/11 | 0.5417 | 1 |
| 12s | +0.0128% | [-0.0074, +0.0427] | 5/7/12 | 0.791 | 1 |

Development validation only; do not use this result as blind-test evidence.
