# Current-source state/action ablation smoke — 2026-11-02

- Tasks: 240/240
- Errors: 0
- Feasible final outputs: 240/240
- Maps: 24 validation maps (geometry seeds 7–8)
- Solver seed: [101]
- Budget: 0.2s (engineering smoke only)
- Methods: m2_global_nojoint, m2_global_asg, m6_global_asg, m6_global_nojoint, m6_global_nomask, m6_global_zeroasg, m6_global_zerodrone, m6_global_zerohist, m6_global_zeroglobal, m6_global_nohighint
- PPO checkpoint SHA256: fbf2e88385700acbcdd9338c951f3b5edec8fb5f66bdfbd2be39e2ab7bf3ae68
- Run manifest SHA256: bcbf6cd34c9d7653f188a3f791f9b2c604e95bf26214d24f98cee4c59b2e40c5

All ten method aliases loaded and completed on all 24 validation maps with zero errors and 100% final feasibility. This is only a method-registry/engineering smoke; it does not establish comparative performance. The full 6s/12s matrix remains pending.
