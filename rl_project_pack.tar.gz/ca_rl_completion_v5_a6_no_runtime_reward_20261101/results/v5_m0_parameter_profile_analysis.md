# M0 parameter-profile validation — 10 solver seeds

Selected non-PPO reference: m2_global_asg. M0 profiles are V6 Python implementations under the one-SD SABS physical evaluator, not byte-for-byte Java execution.

| Budget | M0 method | Mean cost | Median | SD | Feasibility | Solver s | End-to-end s | Mean outer iterations |
|---:|---|---:|---:|---:|---:|---:|---:|---:|
| 6s | m0 | 459.5708 | 362.2044 | 265.7989 | 100.0% | 6.000 | 6.009 | 1337.2 |
| 6s | m0frozen | 460.0553 | 362.3786 | 266.2905 | 100.0% | 2.880 | 2.888 | 500.0 |
| 6s | m0paper | 461.9735 | 363.1791 | 268.3580 | 100.0% | 4.723 | 4.731 | 443.8 |
| 12s | m0 | 459.0184 | 361.5933 | 264.9741 | 100.0% | 12.000 | 12.009 | 2694.2 |
| 12s | m0frozen | 460.0553 | 362.3786 | 266.2905 | 100.0% | 2.926 | 2.934 | 500.0 |
| 12s | m0paper | 461.1578 | 363.1791 | 267.0811 | 100.0% | 5.520 | 5.528 | 500.0 |

## Primary: selected non-PPO baseline vs corrected M0 profiles

Negative delta means the selected joint-search baseline has lower cost than the M0 profile. Holm family covers two M0 profiles × two budgets.

| Budget | Baseline | M0 profile | Mean delta % | 95% CI | W/L/T maps | Wilcoxon p | Holm p |
|---:|---|---|---:|---:|---:|---:|---:|
| 6s | m2_global_asg | m0frozen | -0.5160% | [-0.6273, -0.4093] | 24/0/0 | 1.192e-07 | 4.768e-07 |
| 6s | m2_global_asg | m0paper | -0.8074% | [-1.0353, -0.5969] | 24/0/0 | 1.192e-07 | 4.768e-07 |
| 12s | m2_global_asg | m0frozen | -0.5655% | [-0.7020, -0.4409] | 24/0/0 | 1.192e-07 | 4.768e-07 |
| 12s | m2_global_asg | m0paper | -0.7621% | [-0.9831, -0.5702] | 24/0/0 | 1.192e-07 | 4.768e-07 |

## Parameter-profile comparison: paper Table A1 vs released Java profile

| Budget | Candidate | Reference | Mean delta % | 95% CI | Wilcoxon p | Holm p (2 tests) |
|---:|---|---|---:|---:|---:|---:|
| 6s | m0paper | m0frozen | +0.2956% | [+0.1588, +0.4551] | 4.768e-07 | 9.537e-07 |
| 12s | m0paper | m0frozen | +0.1994% | [+0.0868, +0.3355] | 0.0005927 | 0.0005927 |

## Legacy research-budget variant (descriptive only)

| Budget | Baseline vs m0 research-budget delta % | 95% CI | Wilcoxon p (descriptive) |
|---:|---:|---:|---:|
| 6s | -0.4378% | [-0.5323, -0.3446] | 1.192e-07 |
| 12s | -0.4159% | [-0.5274, -0.3158] | 4.768e-07 |
