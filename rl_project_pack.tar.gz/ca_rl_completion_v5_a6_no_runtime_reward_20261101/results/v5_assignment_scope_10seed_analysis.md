# Assignment receiver-scope full-search validation — 10 solver seeds

The experiment compares local Assignment repair with global receiver-scope repair in the full solver. All methods use the same 24 validation maps, solver seeds 101–110 and 6s/12s solver budgets. Statistical unit is the map; ten solver seeds are averaged within each map.

## Method summary

| Budget | Method | Mean cost | Median | SD | Feasibility | Mean solver s | Mean end-to-end s | Mean steps |
|---:|---|---:|---:|---:|---:|---:|---:|---:|
| 6s | m1d | 458.0013 | 361.5166 | 264.5646 | 100.0% | 6.000 | 6.011 | 17629.5 |
| 6s | m1d_global_asg | 457.4179 | 361.5166 | 263.8432 | 100.0% | 6.000 | 6.008 | 18271.4 |
| 6s | m2 | 457.8136 | 361.5166 | 264.4076 | 100.0% | 6.000 | 6.008 | 14192.9 |
| 6s | m2_global_asg | 457.2448 | 361.5166 | 263.7113 | 100.0% | 6.000 | 6.009 | 14733.7 |
| 12s | m1d | 457.8161 | 361.5166 | 264.4039 | 100.0% | 12.000 | 12.011 | 33013.8 |
| 12s | m1d_global_asg | 457.0564 | 361.5166 | 263.4560 | 100.0% | 12.000 | 12.009 | 34166.8 |
| 12s | m2 | 457.4016 | 361.5166 | 263.8476 | 100.0% | 12.000 | 12.009 | 26759.3 |
| 12s | m2_global_asg | 457.1075 | 361.5166 | 263.5414 | 100.0% | 12.000 | 12.009 | 27785.1 |

## Paired map-level comparisons

Negative delta means the candidate method has lower cost than the reference.

| Budget | Candidate | Reference | Mean delta % | 95% bootstrap CI | W/L/T maps | Wilcoxon p | Holm p (6 tests) |
|---:|---|---|---:|---:|---:|---:|---:|
| 6s | m1d_global_asg | m1d | -0.0820% | [-0.1322, -0.0383] | 13/2/9 | 0.002014 | 0.008057 |
| 6s | m2_global_asg | m2 | -0.0764% | [-0.1212, -0.0363] | 13/1/10 | 0.0002441 | 0.001465 |
| 6s | m1d_global_asg | m2_global_asg | +0.0264% | [-0.0152, +0.0757] | 4/8/12 | 0.2661 | 0.5322 |
| 12s | m1d_global_asg | m1d | -0.1023% | [-0.1558, -0.0528] | 13/0/11 | 0.0002441 | 0.001465 |
| 12s | m2_global_asg | m2 | -0.0430% | [-0.0766, -0.0144] | 9/3/12 | 0.021 | 0.06299 |
| 12s | m1d_global_asg | m2_global_asg | -0.0049% | [-0.0313, +0.0184] | 4/8/12 | 0.9697 | 0.9697 |

## Descriptive size-group effects (M2 Global vs M2)

| Budget | Size group | Maps | M2 mean cost | M2 Global mean cost | Relative difference |
|---:|---|---:|---:|---:|---:|
| 6s | 10_110 | 2 | 1003.8543 | 1002.1441 | -0.1704% |
| 6s | 3_10 | 2 | 147.4564 | 147.4564 | +0.0000% |
| 6s | 3_15 | 2 | 175.1580 | 175.1580 | +0.0000% |
| 6s | 3_20 | 2 | 237.7935 | 237.7935 | +0.0000% |
| 6s | 4_20 | 2 | 251.3268 | 251.3268 | +0.0000% |
| 6s | 4_25 | 2 | 292.0167 | 292.0126 | -0.0014% |
| 6s | 4_30 | 2 | 324.3667 | 324.3700 | +0.0010% |
| 6s | 5_35 | 2 | 390.5038 | 390.2742 | -0.0588% |
| 6s | 6_50 | 2 | 538.3555 | 537.7806 | -0.1068% |
| 6s | 7_65 | 2 | 605.7516 | 605.0075 | -0.1228% |
| 6s | 8_80 | 2 | 736.8064 | 735.0511 | -0.2382% |
| 6s | 9_95 | 2 | 790.3738 | 788.5633 | -0.2291% |
| 12s | 10_110 | 2 | 1002.2732 | 1001.5456 | -0.0726% |
| 12s | 3_10 | 2 | 147.4564 | 147.4564 | +0.0000% |
| 12s | 3_15 | 2 | 175.1580 | 175.1580 | +0.0000% |
| 12s | 3_20 | 2 | 237.7935 | 237.7935 | +0.0000% |
| 12s | 4_20 | 2 | 251.3268 | 251.3268 | +0.0000% |
| 12s | 4_25 | 2 | 292.0126 | 292.0126 | +0.0000% |
| 12s | 4_30 | 2 | 324.3667 | 324.3667 | +0.0000% |
| 12s | 5_35 | 2 | 390.3471 | 390.1481 | -0.0510% |
| 12s | 6_50 | 2 | 538.4125 | 537.3770 | -0.1923% |
| 12s | 7_65 | 2 | 605.0078 | 605.0618 | +0.0089% |
| 12s | 8_80 | 2 | 735.9956 | 735.2672 | -0.0990% |
| 12s | 9_95 | 2 | 788.6686 | 787.7759 | -0.1132% |

## Interpretation

- This is a development validation experiment, not a blind test.
- The global receiver scope applies only to Assignment-family operators 5 and 6; other families retain the original repair behavior.
- Use the paired map-level 6-test Holm family for claims. Do not select a new primary method from the historical test split.
- If global receiver scope does not produce corrected, stable improvement in the full solver, retain local repair despite the candidate-level microbenchmark.
