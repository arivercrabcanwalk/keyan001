from pathlib import Path
import json,socket,sys
assert socket.gethostname()=='EXECUTION_HOST','HN01_ONLY'
ROOT=Path(__file__).resolve().parent
sys.path[:0]=[str(ROOT/'MODIFIED_FILE/frozen')]
from route_method import load_input
from route_delivery import verify_payload
bundle=ROOT/'runs/MODIFIED/BUNDLE.json'
_,instance,anchor,ih=load_input(bundle)
rows=0
for path in sorted((ROOT/'runs/MODIFIED').glob('*/DECISION.json')):
 d=json.loads(path.read_text());p=json.loads((path.parent/'RAW_RESULT.json').read_text())
 assert d['delivery_status']=='ONTIME_VALID' and not d['itt_anchor_used']
 assert d['admission_wall_s']<=d['budget_s']
 ok,reason,score=verify_payload(p,instance,anchor,ih,p['method']);assert ok,reason
 if p['method']=='common_h':
  assert len(p['details']['passes'])==3
  assert [r['rho'] for r in p['details']['passes']]==[1.0,.9,.8]
 rows+=1
assert rows==4
r={'status':'SAVED_FOUR_COMPLETE_DELIVERIES_PASS','calls':rows,'training':0,'scientific_maps':0}
(ROOT/'runs/AUDIT.json').write_text(json.dumps(r)+'\n');print(json.dumps(r))
