"""Root-owned once-only bounded engineering; charged to new48h prep reserve."""
from pathlib import Path
import hashlib,json,os,resource,shutil,signal,socket,subprocess,sys,time

assert socket.gethostname()=='EXECUTION_HOST','HN01_ONLY'
ROOT=Path(__file__).resolve().parent;os.chdir(ROOT)
intent=json.loads(Path('RUN_INTENT.json').read_text());assert intent['status']=='FROZEN'
manifest={r['path']:r['sha256'] for r in json.loads(Path('FROZEN_MANIFEST.json').read_text())}
for path,sha in manifest.items():assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==sha,path
Path('runs').mkdir(exist_ok=False);receipts=[];errors=[]
root_start=time.perf_counter();root_cpu=time.process_time()
def execute(phase,command,cpu_cap,wall_cap):
 def limits():
  resource.setrlimit(resource.RLIMIT_CPU,(cpu_cap,cpu_cap+1))
  resource.setrlimit(resource.RLIMIT_AS,(intent['memory_bytes_cap'],intent['memory_bytes_cap']))
 before=resource.getrusage(resource.RUSAGE_CHILDREN);start=time.perf_counter();timed_out=False
 p=subprocess.Popen(command,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,
  preexec_fn=limits,start_new_session=True,
  env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1'))
 try:stdout,stderr=p.communicate(timeout=wall_cap)
 except subprocess.TimeoutExpired:
  timed_out=True
  os.killpg(p.pid,signal.SIGKILL)
  stdout,stderr=p.communicate()
 after=resource.getrusage(resource.RUSAGE_CHILDREN)
 r={'phase':phase,'command':command,'input':'INPUT.json; new35target_16trip_scale_fixture',
    'stdout_literal':stdout,'stderr_literal':stderr,'exit_status':p.returncode,'timeout':timed_out,
    'wall_s':time.perf_counter()-start,'child_cpu_s':after.ru_utime+after.ru_stime-before.ru_utime-before.ru_stime}
 receipts.append(r);Path('runs/COMMAND_RECEIPTS.json').write_text(json.dumps(receipts,indent=2)+'\n')
 print(json.dumps(r),flush=True)
 if p.returncode!=0 or timed_out:errors.append(phase)
 return p.returncode==0 and not timed_out
try:
 if execute('BASELINE',[sys.executable,'validate.py','BASELINE'],25,30):
  if execute('MODIFIED',[sys.executable,'validate.py','MODIFIED'],80,90):
   execute('AUDIT',[sys.executable,'audit.py'],45,55)
except Exception as e:
 errors.append(type(e).__name__+':'+str(e))
finally:
 Path('ROLLBACK_COPY').mkdir(exist_ok=False);shutil.copy2('MODIFIED_FILE/independent_control.py','ROLLBACK_COPY/independent_control.py')
 applied=execute('ROLLBACK_APPLY',['/bin/sh','ROLLBACK.sh',str(ROOT/'ROLLBACK_COPY')],2,5)
 restored=hashlib.sha256(Path('ROLLBACK_COPY/independent_control.py').read_bytes()).hexdigest()==manifest['MODIFIED_FILE/ORIGINALS/independent_control.py']
 rb=execute('ROLLBACK',[sys.executable,'validate.py','ROLLBACK'],25,30) if applied else False
 same=False
 if Path('runs/BASELINE/RESULT.json').exists() and Path('runs/ROLLBACK/RESULT.json').exists():
  a=json.loads(Path('runs/BASELINE/RESULT.json').read_text());b=json.loads(Path('runs/ROLLBACK/RESULT.json').read_text())
  same={k:v for k,v in a.items() if k not in ('phase','elapsed_s')}=={k:v for k,v in b.items() if k not in ('phase','elapsed_s')}
 retained=hashlib.sha256(Path('MODIFIED_FILE/independent_control.py').read_bytes()).hexdigest()==manifest['MODIFIED_FILE/independent_control.py']
 cpu=sum(r['child_cpu_s'] for r in receipts)+time.process_time()-root_cpu
 wall=time.perf_counter()-root_start
 ok=not errors and same and rb and restored and retained and cpu<=intent['cpu_seconds_total_cap'] and wall<=intent['wall_seconds_total_cap']
 result={'status':'FINITE_PRODUCTION_CHAIN_VERIFIED_NOT_SCIENTIFIC_G3' if ok else 'CLOSED_FAILED_NO_REPAIR',
  'errors':errors,'rollback_matches_baseline':same,'rollback_bytes_restored':restored,
  'main_modified_retained':retained,'repairs':0,'child_cpu_s':sum(r['child_cpu_s'] for r in receipts),
  'root_and_child_cpu_s':cpu,'phase_wall_s':sum(r['wall_s'] for r in receipts),'total_wall_s':wall,
  'training':0,'new_scientific_maps':0}
 Path('runs/SUMMARY.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,sort_keys=True))
 if not ok:sys.exit(1)
