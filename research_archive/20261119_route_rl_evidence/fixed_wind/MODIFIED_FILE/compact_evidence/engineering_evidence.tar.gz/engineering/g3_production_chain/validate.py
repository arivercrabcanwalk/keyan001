from pathlib import Path
import importlib.util,json,os,socket,sys,time
assert socket.gethostname()=='EXECUTION_HOST','HN01_ONLY'
ROOT=Path(__file__).resolve().parent
P=ROOT/'MODIFIED_FILE'
sys.path[:0]=[str(P/'frozen'),str(P)]
from baselines import problem,wind_scorer
from baselines.constant_wind_adapter import ConstantWindCtx
from route_method import load_input
from route_delivery import run
phase=sys.argv[1]
out=ROOT/'runs'/phase;out.mkdir(exist_ok=False)
spec=json.loads((ROOT/'INPUT.json').read_text())
g=spec['grid'];xy=[(g['origin'][0]+c*g['step'][0],g['origin'][1]+r*g['step'][1]) for r in range(g['rows']) for c in range(g['columns'])]+[tuple(p) for p in spec['extra_targets']]
lines=['CUST_NO XCOORD YCOORD ENERGY SERVICE_TIME']
for i,(x,y) in enumerate(xy,1):lines.append(f'{i} {x} {y} {spec["target_energy"]} {spec["service_minutes"]}')
for i,point in enumerate([spec['station0'],spec['station1']]):lines.append(f'{10001+i} {point[0]} {point[1]} 0 0')
instance_file=out/'INSTANCE.txt';instance_file.write_text('\n'.join(lines)+'\n')
instance=problem.read_instance(instance_file)
solution=problem.empty_solution(instance,spec['types'])
solution['routes']=[[[[i,i+1] for i in range(1,33,2)],[]],[[],[[33,34,35]]]]
solution['physics_sha256']=wind_scorer.physics_identity(instance,tuple(spec['wind']))
anchor=wind_scorer.CostAnchor.from_solution(instance,solution,wind=tuple(spec['wind']))
assert sum(map(len,solution['routes'][0]))==16
if phase in ('BASELINE','ROLLBACK'):
 loc=P/'ORIGINALS/independent_control.py' if phase=='BASELINE' else ROOT/'ROLLBACK_COPY/independent_control.py'
 sp=importlib.util.spec_from_file_location('old_control',loc);mod=importlib.util.module_from_spec(sp);sp.loader.exec_module(mod)
 ctx=ConstantWindCtx(instance,anchor.station_types,dict(anchor.target_station),wind=anchor.wind)
 try:mod.search_station(instance,anchor,0,anchor.makespan,{'base_seed':1,'rounds':1,'max_evaluations_per_station':1,'operator_order':['rebalance']},deadline=time.perf_counter()+1)
 except AssertionError as e:
  result={'status':'EXPECTED_ORIGINAL_14_TRIP_GUARD','exception':str(e),'trip_count':16}
 else:raise AssertionError('EXPECTED_GUARD_NOT_RAISED')
else:
 from public_t import rebalance_complete
 ctx=ConstantWindCtx(instance,anchor.station_types,dict(anchor.target_station),wind=anchor.wind)
 routes,receipt=rebalance_complete(instance,anchor,ctx,0,solution['routes'][0],time.perf_counter()+2)
 assert receipt['trip_count']==16 and receipt['status']=='APPROXIMATE_OR_TIMEOUT'
 probe=anchor.solution();probe['routes'][0]=routes
 assert wind_scorer.validate_candidate(instance,probe,anchor)['admissible']
 bundle=out/'BUNDLE.json'
 bundle.write_text(json.dumps({'schema':'physical_route_delivery_input_v1','instance_file':'INSTANCE.txt','parameters':instance.params.__dict__,'anchor':anchor.solution(),'wind':spec['wind'],'run_role':'NEW_HANDWRITTEN_SCALE_ENGINEERING_NOT_SCIENTIFIC_POPULATION'}))
 results=[]
 for D in spec['budgets_seconds']:
  for method in spec['methods']:
   target=out/(method+'_'+str(D))
   def command_factory(result):return [sys.executable,str(P/'common_h_worker.py'),'--bundle',str(bundle),'--result',str(result),'--budget',str(D),'--seed',str(spec['run_seed'])]
   r=run(bundle,target,budget_s=D,method=method,seed=spec['run_seed'],command_factory=command_factory if method=='common_h' else None)
   decision=json.loads((target/'DECISION.json').read_text())
   assert decision['delivery_status']=='ONTIME_VALID',decision
   raw=json.loads((target/'RAW_RESULT.json').read_text())
   if method=='common_h':
    detail=raw['details'];assert detail['rho']==[1.0,.9,.8] and len(detail['passes'])==3
    for passrow in detail['passes']:assert passrow['absolute_cutoff']<=detail['absolute_final_deadline']-.25+1e-9
    for si,bank in enumerate(detail['banks']):
     assert sum(row['anchor'] for row in bank)==1
     assert len({row['id'] for row in bank})==len(bank)
     for row in bank:
      sol=anchor.solution();sol['routes'][si]=row['routes'];sc=wind_scorer.score_solution(instance,sol,wind=anchor.wind)
      assert sc['original_feasible'] and sc['cost']==row['single_replacement_cost']
   results.append({'method':method,'D':D,'decision':decision})
 result={'status':'NEW_SCALE_COMPLETE_DELIVERY_PASS','initial_public_T':receipt,'calls':results,'training':0,'scientific_maps':0}
(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,sort_keys=True))
