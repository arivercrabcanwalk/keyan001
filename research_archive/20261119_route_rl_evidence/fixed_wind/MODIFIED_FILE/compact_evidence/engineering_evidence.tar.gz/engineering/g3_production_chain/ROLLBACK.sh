#!/bin/sh
set -eu
base=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
target=${1:?Supply independent copy}
test -d "$target"
cp "$base/MODIFIED_FILE/ORIGINALS/independent_control.py" "$target/independent_control.py"
printf '%s\n' 'ROLLBACK_BYTES_RESTORED'
