"""Shared S_const completion from public construction state; no learned decisions."""
import math
import time

from baselines import wind_scorer
from compiler import Compiler, canonical, digest, force, freeze, norm, routes
from global_env import RouteAction, CONSTRUCTION_CONTRACT


class CompletionDeadline(TimeoutError):
    pass


class Deadline:
    def __init__(self, started_at, budget_s, *, clock=time.perf_counter):
        if (not all(type(v) in (int, float) and math.isfinite(v) for v in (started_at, budget_s))
                or budget_s <= 0):
            raise ValueError('FINITE_POSITIVE_WHOLE_MAP_BUDGET_REQUIRED')
        self.started_at, self.budget_s, self.clock = started_at, budget_s, clock
        self.expires_at = started_at+budget_s
        if not math.isfinite(self.expires_at):
            raise ValueError('FINITE_DEADLINE_REQUIRED')

    def check(self):
        if self.clock() >= self.expires_at:
            raise CompletionDeadline('WHOLE_MAP_COMPLETION_DEADLINE')


def public_identity(observation):
    # Actions/masks are derived and contain RouteAction dataclasses. Bind the
    # physical public state itself, including every already executed RETURN.
    packet = {k: observation[k] for k in ('construction_contract', 'constant_wind',
              'active_station', 'station_order', 'global_cost_budget',
              'anchor_solution_sha256')}
    packet['all_station_states'] = {
        si: {k: state[k] for k in ('station_idx', 'station_type', 'station_id',
             'remaining_target_ids', 'slots', 'done')}
        for si, state in observation['all_station_states'].items()}
    return digest(packet)


def complete_solution(anchor, plan):
    solution = anchor.solution()
    solution['routes'] = [[[list(t) for t in routes(sl)] for sl in st] for st in plan]
    return solution


class CompletionSession(Compiler):
    def __init__(self, instance, anchor, observation, witness, deadline, *, max_candidates=4000):
        self.deadline = deadline
        self.check()
        if observation.get('construction_contract') != CONSTRUCTION_CONTRACT:
            raise ValueError('S_CONST_PUBLIC_CONSTRUCTOR_REQUIRED')
        if (tuple(observation['constant_wind']) != anchor.wind
                or observation['anchor_solution_sha256'] != anchor.solution_sha256
                or observation['global_cost_budget'] != anchor.cost):
            raise ValueError('PUBLIC_ANCHOR_OR_WIND_OR_CAP_MISMATCH')
        self.instance, self.anchor, self.observation = instance, anchor, observation
        self.mode, self.limit = 'shared_deferred_compensation', max_candidates
        if type(max_candidates) is not int or max_candidates < 1:
            raise ValueError('POSITIVE_CANDIDATE_LIMIT_REQUIRED')
        anchor.verify(instance)
        sc = wind_scorer.validate_candidate(instance, witness, anchor)
        self.check()
        if not sc['admissible']:
            raise ValueError('INADMISSIBLE_COMPLETION_WITNESS')
        if sc['M_return'] > anchor.makespan+1e-7:
            raise ValueError('WITNESS_WORSE_THAN_ANCHOR')
        self.targets = {r.id: (r.x, r.y, r.energy, r.service) for r in instance.targets}
        self.station_nodes = [(r.x, r.y) for r in instance.stations]
        self.assigned = [set() for _ in instance.stations]
        for nid, si in anchor.target_station:
            self.assigned[si].add(nid)
        self.types = anchor.station_types
        self.p = instance.params
        self.wind = anchor.wind
        self.cap = anchor.cost
        self.counters = {k: 0 for k in ('local_expansions', 'remote_expansions', 'candidate_strings',
                         'station_scores', 'global_scores', 'envelope_builds', 'envelope_queries',
                         'remote_cache_hits', 'deferred_queries')}
        self.cache = {}
        active_keys = {si for si, ids in enumerate(self.assigned) if ids}
        public = observation['all_station_states']
        if set(public) != active_keys:
            raise ValueError('PUBLIC_STATION_POOL_MISMATCH')
        projected = []
        for si, station in enumerate(witness['routes']):
            self.check()
            state = public.get(si)
            pair, seen = [], set()
            for k, raw in enumerate(station):
                trips = freeze(raw)
                if any(not t for t in trips):
                    raise ValueError('EMPTY_WITNESS_TRIPS_REQUIRE_NORMALIZATION')
                slot = None if state is None else state['slots'].get(k)
                if slot is None:
                    if trips:
                        raise ValueError('DISABLED_SLOT_HAS_ROUTE')
                    pair.append(((), (), (), ()))
                    continue
                done, prefix = freeze(slot['closed_trips']), freeze(slot['current_trip'])
                if trips[:len(done)] != done:
                    raise ValueError('WITNESS_REWRITES_CLOSED_TRIPS')
                rest = trips[len(done):]
                if prefix and (not rest or rest[0][:len(prefix)] != prefix):
                    raise ValueError('WITNESS_REWRITES_OPEN_PREFIX')
                tail = rest[0][len(prefix):] if rest else ()
                planned = norm((done, prefix, tail, rest[1:]))
                self._verify_public_slot(si, k, slot, done, prefix)
                seen.update(a for tr in done for a in tr)
                seen.update(prefix)
                pair.append(planned)
            if state is not None:
                if (state['station_idx'] != si or state['station_type'] != self.types[si]
                        or state['station_id'] != instance.stations[si].id
                        or set(state['remaining_target_ids']) != self.assigned[si]-seen):
                    raise ValueError('PUBLIC_EXECUTED_OR_REMAINING_MISMATCH')
            projected.append(tuple(pair))
        self.witness = tuple(projected)
        self.source_identity = public_identity(observation)
        self.root = self.global_score(self.witness)
        self.check()
        if not self.root['valid'] or abs(self.root['cost']-sc['cost']) > 1e-7:
            raise ValueError('PREFIX_PROJECTION_PHYSICS_MISMATCH')

    def check(self):
        self.deadline.check()

    def leg(self, a, b):
        self.check()
        dx, dy = b[0]-a[0], b[1]-a[1]
        norm2 = dx*dx+dy*dy
        if not norm2:
            return 0.
        wx, wy = self.wind
        v = wx*dx+wy*dy
        d = self.p.speed**2-wx*wx-wy*wy
        return norm2/(math.sqrt(v*v+d*norm2)+v)

    def _partial(self, si, trip):
        depot = self.station_nodes[si]
        x, elapsed, energy = depot, 0., 0.
        for nid in trip:
            nx, ny, use, service = self.targets[nid]
            travel = self.leg(x, (nx, ny))
            elapsed += travel+service
            energy += self.p.flight_energy*travel+use
            x = nx, ny
        return elapsed, energy, x

    def _verify_public_slot(self, si, k, slot, done, prefix):
        elapsed, energy, pos = self._partial(si, prefix)
        closed = 0.
        for trip in done:
            t, _, x = self._partial(si, trip)
            closed += t+self.leg(x, self.station_nodes[si])
        expected_pos = prefix[-1] if prefix else self.instance.stations[si].id
        expected = {'trip_energy': energy, 'trip_elapsed': elapsed, 'cumulative_duty': closed,
                    'battery_capacity': self.p.large_battery if k == 0 else self.p.small_battery,
                    'duty_limit': self.p.small_duration if self.types[si] == 1 else self.p.large_duration}
        if slot['current_pos'] != expected_pos:
            raise ValueError('PUBLIC_POSITION_MISMATCH')
        for key, value in expected.items():
            tol = 1e-12 if key in ('trip_energy', 'battery_capacity') else 1e-7
            if (type(slot[key]) not in (float, int) or not math.isfinite(slot[key])
                    or abs(value-slot[key]) > tol):
                raise ValueError('PUBLIC_CLOCK_OR_RESOURCE_MISMATCH:'+key)

    def station_score(self, si, station):
        self.check()
        self.counters['station_scores'] += 1
        kind = self.types[si]
        duties, energies, ids, valid = [], [], [], True
        radius = self.p.small_radius if kind == 1 else self.p.large_radius
        duty_limit = self.p.small_duration if kind == 1 else self.p.large_duration
        depot = self.station_nodes[si]
        for k, sl in enumerate(station):
            duty, ee = 0., []
            for trip in routes(sl):
                self.check()
                if kind == 0 or (kind == 1 and k == 0):
                    valid = False
                t, e, pos = self._partial(si, trip)
                back = self.leg(pos, depot)
                duty += t+back
                ee.append(e+self.p.flight_energy*back)
                for nid in trip:
                    ids.append(nid)
                    nx, ny, _, _ = self.targets[nid]
                    valid &= math.hypot(nx-depot[0], ny-depot[1]) <= radius+1e-7
            capacity = self.p.large_battery if k == 0 else self.p.small_battery
            valid &= duty <= duty_limit+1e-7 and all(e <= capacity+1e-12 for e in ee)
            duties.append(duty)
            energies.append(ee)
        valid &= sorted(ids) == sorted(self.assigned[si])
        return {'valid': bool(valid), 'duties': duties, 'energies': energies,
                'operating': duties[0]+duties[1], 'M': max(duties)}

    def global_score(self, plan):
        self.check()
        self.counters['global_scores'] += 1
        records = [self.station_score(si, st) for si, st in enumerate(plan)]
        operating, fixed = 0., 0.
        for si, r in enumerate(records):
            for duty in r['duties']:
                operating += duty
            if self.types[si] == 1:
                fixed += self.p.small_station_cost+self.p.small_drone_cost
            elif self.types[si] == 2:
                fixed += self.p.large_station_cost+self.p.small_drone_cost+self.p.large_drone_cost
        return {'valid': all(r['valid'] for r in records), 'cost': fixed+self.p.time_cost*operating,
                'M': max((r['M'] for r in records), default=0.), 'stations': records}

    def _preserves(self, plan, bounds):
        for st, boundst in zip(plan, bounds):
            for sl, bound in zip(st, boundst):
                if sl[0] != bound[0] or sl[1] != bound[1]:
                    raise ValueError('COMPLETION_REWRITES_EXECUTED_TARGET_OR_RETURN')

    def query_action(self, action, H=None):
        if not isinstance(action, RouteAction) or type(action.slot) is not int:
            raise ValueError('PHYSICAL_ROUTE_ACTION_REQUIRED')
        if action.target_id is not None and type(action.target_id) is not int:
            raise ValueError('INTEGER_TARGET_OR_RETURN_REQUIRED')
        result = {'supported': False, 'reason': 'deadline', 'source_identity': self.source_identity}
        try:
            self.check()
            si = self.observation['active_station']
            legal = any(action == a and ok for a, ok in zip(self.observation['actions'], self.observation['mask']))
            if si is None or not legal:
                return dict(result, reason='public_mask_excluded', action=[si, action.slot, action.target_id])
            H = self.root['M'] if H is None else H
            if type(H) not in (int, float) or not math.isfinite(H) or H < 0 or H > self.anchor.makespan+1e-7:
                raise ValueError('FINITE_THRESHOLD_NO_WORSE_THAN_ANCHOR_REQUIRED')
            result = super().query(si, action.slot, action.target_id, H)
            result['source_identity'] = self.source_identity
            if result['supported']:
                locked = list(self.witness)
                locked[si] = force(self.witness[si], action.slot, action.target_id)
                plan = freeze(result['plan'])
                self._preserves(plan, locked)
                solution = complete_solution(self.anchor, plan)
                self.check()
                sc = wind_scorer.validate_candidate(self.instance, solution, self.anchor)
                self.check()
                if not sc['admissible'] or sc['M_return'] > H+1e-7:
                    raise ValueError('FINAL_COMPLETE_WITNESS_VALIDATION_FAILED')
                result.update(solution=solution, solution_sha256=sc['solution_sha256'])
            return result
        except CompletionDeadline:
            return {'supported': False, 'reason': 'deadline', 'source_identity': self.source_identity,
                    'action': [self.observation['active_station'], action.slot, action.target_id],
                    'partial_counters': dict(self.counters)}

    def commit(self, env, result):
        self.check()
        if public_identity(env.observation()) != self.source_identity:
            raise ValueError('STALE_PUBLIC_PREFIX')
        if not result.get('supported') or result.get('source_identity') != self.source_identity:
            raise ValueError('NO_COMPLETE_SUPPORTED_ACTION')
        si, k, a = result['action']
        action = RouteAction(k, a)
        if si != env.active_station or not env.legal(action):
            raise ValueError('PHYSICAL_ACTION_MISMATCH')
        sc = wind_scorer.validate_candidate(self.instance, result['solution'], self.anchor)
        if not sc['admissible'] or sc['solution_sha256'] != result['solution_sha256']:
            raise ValueError('COMPLETION_CHANGED_BEFORE_COMMIT')
        H = result.get('H')
        if (type(H) not in (int, float) or not math.isfinite(H) or H < 0
                or H > self.anchor.makespan+1e-7 or sc['M_return'] > H+1e-7):
            raise ValueError('COMPLETION_THRESHOLD_MISMATCH')
        locked = list(self.witness)
        locked[si] = force(self.witness[si], k, a)
        self._preserves(freeze(result['plan']), locked)
        if complete_solution(self.anchor, freeze(result['plan'])) != result['solution']:
            raise ValueError('COMPLETION_PLAN_SOLUTION_MISMATCH')
        self.check()
        obs, reward, done, info = env.step(action)
        return {'observation': obs, 'reward': reward, 'done': done, 'info': info,
                'witness': result['solution']}
