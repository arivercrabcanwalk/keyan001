"""Exact original Context.minimum arithmetic on immutable action-bank views."""
from collections import defaultdict
from copy import deepcopy
from types import SimpleNamespace
import math
from schedule_credit import Context
from baselines import wind_scorer


def threshold_view(banks, fixed, time_cost, cap):
    # One fresh cache per action/bank identity. No anchor/deletion API is used.
    if not banks or any(not math.isfinite(v) or v < 0 for v in (fixed,time_cost,cap)):
        raise ValueError('FINITE_NONNEGATIVE_COST_DOMAIN_REQUIRED')
    seen = set()
    for bank in banks:
        for row in bank:
            if row['id'] in seen:
                raise ValueError('COPY_ID_MUST_BE_UNIQUE')
            seen.add(row['id'])
            duties = row['duties']
            if len(duties)!=2 or any(not math.isfinite(v) or v<0 for v in duties):
                raise ValueError('FINITE_NONNEGATIVE_TWO_SLOT_DUTIES_REQUIRED')
            if row['m'] != max(duties):
                raise ValueError('FULL_RETURN_MISMATCH')
    return SimpleNamespace(banks=banks, fixed=fixed, time_cost=time_cost, cap=cap,
                           cache={}, work=defaultdict(int))


def best_complete(banks, instance, anchor, check):
    if any(not b for b in banks):
        return None
    fixed = sum(instance.fixed(k) for k in anchor.station_types)
    view = threshold_view(banks, fixed, instance.params.time_cost, anchor.cost)
    thresholds = sorted({r['m'] for b in banks for r in b})
    lo, hi, found = 0, len(thresholds)-1, None
    while lo <= hi:
        check()
        mid = (lo+hi)//2
        result = Context.minimum(view, thresholds[mid])
        if result is not None and wind_scorer.cost_within_cap(result[1], anchor.cost):
            found = (thresholds[mid], result)
            hi = mid-1
        else:
            lo = mid+1
    if found is None:
        return None
    h, (selected, cost) = found
    solution = anchor.solution()
    for si, row in enumerate(selected):
        solution['routes'][si] = deepcopy(row['routes'])
    score = wind_scorer.validate_candidate(instance, solution, anchor)
    check()
    assert score['admissible'] and score['cost'] == cost and score['M_return'] <= h
    return {'solution':solution,'score':score,'H':h,'selected':selected}


def full_routes(module, station):
    return [[list(trip) for trip in module.routes(sl)] for sl in station]


def legacy_table(module, station, enabled, scorer, limit, check):
    rows, buckets = [], {}
    for candidate in module.neighborhood(station, limit, check):
        receipt = scorer(candidate)
        check()
        if receipt is None:
            continue
        actions = module.next_tokens(candidate, enabled)
        ri = len(rows)
        rows.append({'station':candidate,'score':receipt,'actions':actions,
                     'route_hash':module.digest(candidate)})
        for action in actions:
            buckets.setdefault(module.canonical(action),[]).append(ri)
    return {'rows':rows,'buckets':buckets,'status':'OLD_SINGLE_RELOCATION_COMPLETE'}
