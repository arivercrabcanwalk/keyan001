"""First live AIR2 table/bucket/complete-physical-prefix engineering."""
from copy import deepcopy
from pathlib import Path
import hashlib
import importlib.util
import json
import math
import socket
import sys
import time

assert socket.gethostname() == 'EXECUTION_HOST', 'HN01_ONLY'
ROOT = Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'frozen'))
phase = sys.argv[1]
path = ROOT/({'BASELINE':'ORIGINALS/boundary_before.py','MODIFIED':'MODIFIED_FILE.py',
             'ROLLBACK':'ROLLBACK_COPY/MODIFIED_FILE.py'}[phase])
spec = importlib.util.spec_from_file_location('compiler',path)
module = importlib.util.module_from_spec(spec)
sys.modules['compiler'] = module
spec.loader.exec_module(module)
from prefix_completion import CompletionSession, Deadline, complete_solution
from global_env import FullMapRouteEnv, RouteAction, StationRouteEnv
from baselines import problem, wind_scorer
from common import legacy_table, best_complete, full_routes, threshold_view
from schedule_credit import Context

inp=json.loads((ROOT/'INPUT.json').read_text())
out=ROOT/'runs'/phase
out.mkdir(exist_ok=False)
started=time.perf_counter()
deadline=Deadline(started,80.0 if phase=='MODIFIED' else 25.0)
targets=tuple(problem.Node(i,*row) for i,row in enumerate(inp['targets'],1))
stations=tuple(problem.Node(10001+i,*xy,0,0) for i,xy in enumerate(inp['stations']))
instance=problem.Instance(inp['id'],targets,stations,
                         hashlib.sha256((ROOT/'INPUT.json').read_bytes()).hexdigest(),problem.Parameters())
assert instance.params.speed==900 and instance.params.flight_energy==.018
assert all(t.energy==.2 and t.service==10 for t in targets)
assert all(math.hypot(a.x-b.x,a.y-b.y)>=200 for i,a in enumerate(targets) for b in targets[i+1:])
solution=problem.empty_solution(instance,inp['types'])
solution['routes']=inp['routes']
solution['physics_sha256']=wind_scorer.physics_identity(instance,tuple(inp['wind']))
anchor=wind_scorer.CostAnchor.from_solution(instance,solution,wind=tuple(inp['wind']))
counts={'scorer_calls':0,'valid_physical_rows':0,'action_boundary_checks':0,
        'new_group_order_rows_vs_old1reloc':0,'public_prefix_snapshots':0}


def group_id(station):
    return tuple(sorted(trip for sl in station for trip in module.routes(sl)))


def build(env,W,label,compare_old=False):
    session=CompletionSession(instance,anchor,env.observation(),W,deadline,
                              max_candidates=inp['row_limit'])
    counts['public_prefix_snapshots']+=1
    tables,banks=[],[]
    for si,station in enumerate(session.witness):
        enabled=(1,) if anchor.station_types[si]==1 else (0,1)
        def scorer(candidate):
            counts['scorer_calls']+=1
            ss=session.station_score(si,candidate)
            if not ss['valid']:return None
            full=W.copy()
            full['routes']=deepcopy(W['routes'])
            full['routes'][si]=full_routes(module,candidate)
            sc=wind_scorer.score_solution(instance,full,wind=anchor.wind)
            session.check()
            assert sc['original_feasible']
            assert tuple(sorted(sc['target_station'].items()))==anchor.target_station
            duties=[r['duty_min'] for r in sc['slot_duty'] if r['station']==si]
            assert all(abs(a-b)<=1e-7 for a,b in zip(duties,ss['duties']))
            return {'duties':duties,'m':max(duties),'single_cost':sc['cost'],
                    'single_over_cap':not wind_scorer.cost_within_cap(sc['cost'],anchor.cost)}
        if phase=='MODIFIED':
            table=module.build_action_table(station,enabled,scorer,
                         row_limit=inp['row_limit'],check=session.check)
        else:
            table=legacy_table(module,station,enabled,scorer,inp['row_limit'],session.check)
        session.check()
        old_groups=set()
        if phase=='MODIFIED' and compare_old:
            old=legacy_table(module,station,enabled,scorer,inp['row_limit'],session.check)
            old_groups={group_id(r['station']) for r in old['rows']}
        expected={}
        bank=[]
        for j,row in enumerate(table['rows']):
            candidate=row['station']
            assert all(candidate[k][:2]==station[k][:2] for k in (0,1))
            # Independent interpretation from full trips and actual prefix.
            actions=[]
            for k in enabled:
                done,prefix,_,_=candidate[k]
                todo=module.routes(candidate[k])[len(done):]
                if todo:
                    assert todo[0][:len(prefix)]==prefix
                    actions.append((k,todo[0][len(prefix)] if len(todo[0])>len(prefix) else None))
            assert tuple(actions)==row['actions']
            for k,a in actions:
                expected.setdefault(module.canonical((k,a)),[]).append(j)
                post=module.advance_next_token(candidate,k,a)
                lock=module.force(station,k,a)
                assert full_routes(module,post)==full_routes(module,candidate)
                assert all(post[d][:2]==lock[d][:2] for d in (0,1))
                counts['action_boundary_checks']+=1
            if old_groups and group_id(candidate) not in old_groups:
                counts['new_group_order_rows_vs_old1reloc']+=1
            receipt=row['score']
            bank.append({'id':f'S{si}:{j}','duties':receipt['duties'],'m':receipt['m'],
                         'routes':full_routes(module,candidate),'plan':candidate,
                         'actions':row['actions'],'single_cost':receipt['single_cost'],
                         'single_over_cap':receipt['single_over_cap']})
        assert table['buckets']==expected
        counts['valid_physical_rows']+=len(bank)
        tables.append(table);banks.append(bank)
    best=best_complete(banks,instance,anchor,deadline.check)
    assert best is not None
    # Every executable action has a complete global witness, not a local mask only.
    si=env.active_station
    supported={}
    if si is not None:
        for action_key,ids in tables[si]['buckets'].items():
            slot,target=json.loads(action_key)
            if not env.legal(RouteAction(slot,target)):continue
            restricted=list(banks)
            restricted[si]=[banks[si][j] for j in ids]
            result=best_complete(restricted,instance,anchor,deadline.check)
            if result is not None and result['score']['M_return']<=session.root['M']+1e-7:
                pre_plan=tuple(r['plan'] for r in result['selected'])
                post=list(pre_plan);post[si]=module.advance_next_token(pre_plan[si],slot,target)
                locked=list(session.witness);locked[si]=module.force(session.witness[si],slot,target)
                session._preserves(tuple(post),tuple(locked))
                assert complete_solution(anchor,tuple(post))==result['solution']
                supported[action_key]=(result,tuple(post))
    packet={'label':label,'public_identity':session.source_identity,'witness':W,
            'prefix_plan':session.witness,
            'banks':banks,'best_score':best['score'],'supported_actions':list(supported),
            'root_M':session.root['M']}
    (out/(label+'.json')).write_text(json.dumps(packet,sort_keys=True)+'\n')
    return session,banks,best,supported


snapshots=[]
for label in ['EMPTY','OPEN_TARGET_1','CLOSED_LD_FIRST_SORTIE']:
    env=FullMapRouteEnv(instance,anchor)
    if label!='EMPTY':env.step(RouteAction(0,1))
    if label=='CLOSED_LD_FIRST_SORTIE':
        env.step(RouteAction(0,2));env.step(RouteAction(0,3));env.step(RouteAction(0,None))
    session,banks,best,supported=build(env,anchor.solution(),label,compare_old=True)
    assert supported
    snapshots.append({'label':label,'bank_rows':[len(b) for b in banks],
                       'supported_actions':len(supported),'best_M':best['score']['M_return'],
                       'best_cost':best['score']['cost']})

# One deterministic real physical episode, with all discovered witnesses counted.
env=FullMapRouteEnv(instance,anchor)
W=anchor.solution();trace=[];first_pool=None;pool_best=anchor.makespan
while not env.done:
    assert len(trace)<inp['max_episode_actions']
    label='LIVE_%02d'%len(trace)
    session,banks,best,supported=build(env,W,label)
    assert supported
    pool_best=min(pool_best,best['score']['M_return'])
    if first_pool is None:first_pool=pool_best
    key=min(supported,key=lambda key:(supported[key][0]['score']['M_return'],
                                     supported[key][0]['score']['cost'],key))
    result,post=supported[key];slot,target=json.loads(key);si=env.active_station
    old_closed=env.station_envs[si].cumulative_duty[slot]
    action=RouteAction(slot,target)
    env.step(action)
    if target is None:assert env.station_envs[si].cumulative_duty[slot]>=old_closed
    W=result['solution']
    # Rebuild from real public prefix; rejects rewrites, bad duty, stale identities.
    CompletionSession(instance,anchor,env.observation(),W,deadline,max_candidates=inp['row_limit'])
    trace.append({'action':[si,slot,target],'chosen_M':result['score']['M_return'],
                  'F_first_pool':first_pool,'F_pool_so_far':pool_best})
    (out/'LIVE_TRACE.json').write_text(json.dumps(trace,indent=2)+'\n')
final=wind_scorer.validate_candidate(instance,env.candidate(),anchor)
assert final['admissible']
if phase=='MODIFIED':assert counts['new_group_order_rows_vs_old1reloc']>0
result={'phase':phase,'status':'FINITE_COMPLETE_CHAIN_PASS','source_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
        'method':'AIR2' if phase=='MODIFIED' else 'OLD_SINGLE_RELOCATION',
        'snapshots':snapshots,'counts':counts,'episode_physical_actions':len(trace),
        'anchor_M':anchor.makespan,'final_M':final['M_return'],'final_cost':final['cost'],
        'F_first_pool':first_pool,'F_final_pool':pool_best,'elapsed_s':time.perf_counter()-started,
        'training':0,'new_scientific_maps':0,'G0_G3_scientific_pass':False}
(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,sort_keys=True))
