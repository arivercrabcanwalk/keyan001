"""Independent original-scorer audit of saved complete rows; no regeneration."""
from copy import deepcopy
from pathlib import Path
import hashlib
import json
import socket
import sys
import itertools

assert socket.gethostname()=='EXECUTION_HOST','HN01_ONLY'
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'frozen'))
from baselines import problem,wind_scorer
from common import threshold_view
inp=json.loads((ROOT/'INPUT.json').read_text())
instance=problem.Instance(inp['id'],tuple(problem.Node(i,*r) for i,r in enumerate(inp['targets'],1)),
 tuple(problem.Node(10001+i,*xy,0,0) for i,xy in enumerate(inp['stations'])),
 hashlib.sha256((ROOT/'INPUT.json').read_bytes()).hexdigest(),problem.Parameters())
rows_checked=0;actions_checked=0;packets=0

# Independent three-target EMPTY-domain construction: recursive insertion into
# ordered blocks, rather than the compiler's permutations/cuts. All numerical
# work and the original scorer stay on EXECUTION_HOST.
def ordered_blocks(ids):
 states={()}
 for a in ids:
  new=set()
  for blocks in states:
   for j,block in enumerate(blocks):
    for pos in range(len(block)+1):
     new.add(blocks[:j]+(block[:pos]+(a,)+block[pos:],)+blocks[j+1:])
   if len(blocks)<2:
    for j in range(len(blocks)+1):new.add(blocks[:j]+((a,),)+blocks[j:])
  states=new
 return states

packet=json.loads((ROOT/'runs/MODIFIED/EMPTY.json').read_text())
base=packet['witness']['routes'][1]
source=[(k,j,tuple(tr)) for k in range(2) for j,tr in enumerate(base[k])]
expected={json.dumps(base,separators=(',',':'))}
for count in (1,2):
 for chosen in itertools.combinations(source,count):
  chosen_ids={(k,j) for k,j,tr in chosen}
  untouched=[[tuple(tr) for j,tr in enumerate(base[k]) if (k,j) not in chosen_ids] for k in range(2)]
  ids=sorted(a for k,j,tr in chosen for a in tr)
  for blocks in ordered_blocks(ids):
   for owners in itertools.product(range(2),repeat=len(blocks)):
    routes=[[list(tr) for tr,owner in zip(blocks,owners) if owner==k]+[list(tr) for tr in untouched[k]] for k in range(2)]
    if any(len(tr)>[4,3][k] for k in range(2) for tr in routes[k]):continue
    sol=deepcopy(packet['witness']);sol['routes'][1]=routes
    sc=wind_scorer.score_solution(instance,sol,wind=tuple(inp['wind']))
    if sc['original_feasible']:expected.add(json.dumps(routes,separators=(',',':')))
observed={json.dumps(row['routes'],separators=(',',':')) for row in packet['banks'][1]}
assert expected==observed,{'missing':len(expected-observed),'extra':len(observed-expected)}
for phase in ['BASELINE','MODIFIED']:
 for file in sorted((ROOT/'runs'/phase).glob('*.json')):
  if file.name in ('RESULT.json','LIVE_TRACE.json'):continue
  packet=json.loads(file.read_text());packets+=1
  for si,bank in enumerate(packet['banks']):
   for row in bank:
    for k,(done,prefix,suffix,future) in enumerate(row['plan']):
     assert [done,prefix]==packet['prefix_plan'][si][k][:2]
     full=done+([prefix+suffix] if prefix or suffix else [])+future
     assert full==row['routes'][k]
     assert all(len(tr)<=[4,3][k] for tr in full)
    solution=deepcopy(packet['witness']);solution['routes'][si]=row['routes']
    score=wind_scorer.score_solution(instance,solution,wind=tuple(inp['wind']))
    assert score['original_feasible']
    duties=[r['duty_min'] for r in score['slot_duty'] if r['station']==si]
    assert duties==row['duties'] and max(duties)==row['m']
    assert score['cost']==row['single_cost']
    actions_checked+=len(row['actions']);rows_checked+=1
 # Independently ensure actual final public episode preserved every target once.
 trace=json.loads((ROOT/'runs'/phase/'LIVE_TRACE.json').read_text())
 visited=[r['action'][2] for r in trace if r['action'][2] is not None]
 assert sorted(visited)==list(range(1,len(inp['targets'])+1))
 # Repeat actions after RETURN are not permitted; trace has distinct target IDs.
 assert len(visited)==len(set(visited))
bad=[([{'id':'a','duties':[1,2],'m':3}],),
     ([{'id':'a','duties':[-1,2],'m':2}],),
     ([{'id':'a','duties':[1,float('nan')],'m':1}],),
     ([{'id':'a','duties':[1,2],'m':2},{'id':'a','duties':[2,1],'m':2}],)]
rejects=0
for banks in bad:
 try:threshold_view(banks,0.,.5,100.)
 except ValueError:rejects+=1
assert rejects==4
result={'status':'INDEPENDENT_SAVED_ROWS_PASS','packets':packets,
 'independent_empty_station1_domain_rows':len(expected),
 'rows_rescored_including_prefix_repetitions':rows_checked,'action_records':actions_checked,
 'invalid_threshold_views_rejected':rejects,'new_scientific_maps':0,'training':0}
(ROOT/'runs/AUDIT.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,sort_keys=True))
