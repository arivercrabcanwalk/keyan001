#!/bin/sh
set -eu
base=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
target=${1:?Supply an independent copy directory}
test -d "$target"
cp "$base/ORIGINALS/boundary_before.py" "$target/MODIFIED_FILE.py"
printf '%s\n' 'ROLLBACK_BYTES_RESTORED'
