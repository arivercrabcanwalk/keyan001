#!/bin/sh
set -eu
target=${1:?Supply independent copy}
test -f "$target/MODIFIED_FILE.py"
rm "$target/MODIFIED_FILE.py"
printf '%s\n' 'ORIGINAL_GUARD_ABSENT'
