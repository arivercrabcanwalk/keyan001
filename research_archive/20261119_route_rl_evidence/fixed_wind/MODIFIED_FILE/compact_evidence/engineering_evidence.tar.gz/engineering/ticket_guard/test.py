from pathlib import Path
import hashlib,json,os,resource,shutil,socket,subprocess,sys,time
assert socket.gethostname()=='EXECUTION_HOST','HN01_ONLY'
ROOT=Path(__file__).resolve().parent;os.chdir(ROOT);Path('runs').mkdir(exist_ok=False)
manifest=json.loads(Path('FROZEN_MANIFEST.json').read_text())
for r in manifest:assert hashlib.sha256(Path(r['path']).read_bytes()).hexdigest()==r['sha256']
before=resource.getrusage(resource.RUSAGE_CHILDREN);own=time.process_time();started=time.monotonic();receipts=[]
def call(phase,args,expected):
 p=subprocess.run(args,capture_output=True,text=True,timeout=12)
 r={'phase':phase,'command':args,'input':'frozen GUARD_INPUT.json; no physics/model/scientific data','stdout_literal':p.stdout,'stderr_literal':p.stderr,'exit_status':p.returncode};receipts.append(r)
 Path('runs/COMMAND_RECEIPTS.json').write_text(json.dumps(receipts,indent=2)+'\n');assert p.returncode==expected,r
# A new guard did not previously exist. Baseline/rollback verify that source state,
# not an artificial solver comparison.
call('BASELINE',[sys.executable,'-c',"from pathlib import Path; assert not Path('ORIGINAL_ABSENT.py').exists(); print('ORIGINAL_GUARD_ABSENT')"],0)
base=[sys.executable,'MODIFIED_FILE.py','--ledger','runs/guard_ledger.jsonl','--ticket-cap-seconds','30','--termination-reserve-seconds','2','--reserved-cpu-seconds','5','--wall-cap-seconds','8']
call('MODIFIED_NORMAL',base+['--out','runs/normal','--row-id','normal','--',sys.executable,'-c',"print('CHILD_COMPLETED')"],0)
job="import os; p=os.fork();\nif p==0: os.setsid()\nprint('OWNED_PID='+str(os.getpid()),flush=True)\nwhile True: pass"
call('MODIFIED_CPU_STOP',base+['--out','runs/stop','--row-id','stop','--',sys.executable,'-c',job],4)
a=json.loads(Path('runs/normal/TERMINAL.json').read_text());b=json.loads(Path('runs/stop/TERMINAL.json').read_text())
assert a['budget_and_cleanup_pass'] and b['budget_and_cleanup_pass']
assert b['stop_reason']=='CPU_STOP_BEFORE_RESERVED_LIMIT' and not b['remaining_descendants']
# Terminal row must be refused without launching it again.
call('MODIFIED_NO_RELAUNCH',base+['--out','runs/duplicate','--row-id','normal','--',sys.executable,'-c',"print('MUST_NOT_RUN')"],1)
assert not Path('runs/duplicate/STDOUT.txt').exists()
Path('ROLLBACK_COPY').mkdir();shutil.copy2('MODIFIED_FILE.py','ROLLBACK_COPY/MODIFIED_FILE.py')
call('ROLLBACK',['/bin/sh','ROLLBACK.sh',str(ROOT/'ROLLBACK_COPY')],0)
assert not Path('ROLLBACK_COPY/MODIFIED_FILE.py').exists()
assert hashlib.sha256(Path('MODIFIED_FILE.py').read_bytes()).hexdigest()==next(r['sha256'] for r in manifest if r['path']=='MODIFIED_FILE.py')
after=resource.getrusage(resource.RUSAGE_CHILDREN)
r={'status':'CONSERVATIVE_CPU_STOP_NESTED_SESSION_CLEANUP_AND_NO_RELAUNCH_PASS','source_absent_before_and_after_independent_rollback':True,'main_modified_retained':True,'training':0,'scientific_maps':0,'cpu_seconds_children':after.ru_utime+after.ru_stime-before.ru_utime-before.ru_stime,'cpu_seconds_root_and_children':after.ru_utime+after.ru_stime-before.ru_utime-before.ru_stime+time.process_time()-own,'wall_seconds':time.monotonic()-started}
assert r['cpu_seconds_root_and_children']<15 and r['wall_seconds']<25
Path('runs/SUMMARY.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,sort_keys=True))
