from pathlib import Path
from collections import Counter
import hashlib,json,socket,sys,time
assert socket.gethostname()=='EXECUTION_HOST'
P=Path('/root/rivermind-data/liu_f3_g3_authorized_20261114_v1');R=P/'recovery_v2';V=P/'execution_v1'
sys.path.insert(0,str(R/'MODIFIED_FILE'))
from source_closure import verify,sha
closure=verify(R)
reg=json.loads((V/'REGISTRATION.json').read_text())
events=[json.loads(x) for x in (R/'EVENTS.jsonl').read_text().splitlines()]
ae=[x for x in events if x['event']=='AUTHOR_TERMINAL'];ce=[x for x in events if x['event']=='CONTROL_TERMINAL']
assert len(ae)==len({x['row_id'] for x in ae})==72
assert len(ce)==len({x['row_id'] for x in ce})==2880
ad={x['row_id']:x for x in ae};cd={x['row_id']:x for x in ce}
assert set(ad)=={x['row_id'] for x in reg['authors']}
assert set(cd)=={x['row_id'] for x in reg['controls']}
rows=[]
for a in reg['authors']:
 e=ad[a['row_id']];runfile=Path(e['run_file']);run=json.loads(runfile.read_text());q=json.loads((runfile.parent/'QUALIFICATION.json').read_text())
 assert e['qualified'] and run['main_returned'] and run['wind_witness_qualified'] and q['source_record_qualified'] and q['wind_witness_qualified']
 assert not run.get('final_output_issues') and not run.get('audit_exception')
 base=V if a['row_id']=='A000' else R
 t=json.loads((base/'guards/authors'/a['row_id']/'TERMINAL.json').read_text())
 assert t['exit_status']==0 and t['budget_and_cleanup_pass'] and not t['remaining_descendants'] and t['stop_reason'] is None
 rows.append({'row_id':a['row_id'],'run_file':str(runfile),'run_sha256':sha(runfile),'qualification_sha256':sha(runfile.parent/'QUALIFICATION.json')})
by_arm=Counter();by_cell=Counter();control_rows=[]
for c in reg['controls']:
 row=c['row_id'];g=R/'guards/controls'/row
 f=json.loads((g/'FINAL_DELIVERY.json').read_text());t=json.loads((g/'TERMINAL.json').read_text());decpath=Path(f['controller_decision_file']);d=json.loads(decpath.read_text());rawpath=decpath.parent/'RAW_RESULT.json'
 assert f['registration']==c and f['row_id']==row and f['status']=='ONTIME_VALID'
 assert t['row_id']==row and t['exit_status']==0 and t['budget_and_cleanup_pass'] and t['stop_reason'] is None and not t['remaining_descendants']
 assert t['method_deadline_seconds']==c['deadline_s'] and t['complete_process_ontime'] and t['process_exit_observed_elapsed_s']<=c['deadline_s']
 assert d['accepted'] and d['delivery_status']=='ONTIME_VALID' and d['exit_status']==0 and not d['timed_out'] and d['budget_s']==c['deadline_s']
 assert d['raw_validation']['admissible'] and d['raw_validation']['original_feasible']
 assert sha(rawpath)==d['raw_output_sha256']
 assert not f['itt_is_virtual_no_improvement'] and f['itt_M_return']==d['itt_M_return'] and f['itt_cost']==d['itt_cost']
 assert f['itt_M_return']<=f['anchor_M_return'] and f['itt_cost']-f['anchor_cost']<=1e-7
 method='strong' if c['method']=='native_strong_minmax_ALNS' else 'common_h'
 assert d['method']==method and d['seed']==c['run_seed']
 bundle=R/'bundles'/c['map_id'].split(':')[-2].replace('x','x')
 by_arm[(c['method'],c['deadline_s'])]+=1;by_cell[(c['map_id'],c['wind_id'])]+=1
 control_rows.append({'row_id':row,'final_delivery_sha256':sha(g/'FINAL_DELIVERY.json'),'decision_sha256':sha(decpath),'raw_sha256':sha(rawpath),'terminal_sha256':sha(g/'TERMINAL.json')})
assert len(by_cell)==72 and set(by_cell.values())=={40}
assert len(by_arm)==4 and set(by_arm.values())=={720}
final=json.loads((R/'FINAL_SUMMARY.json').read_text());progress=json.loads((R/'PROGRESS.json').read_text());outer=json.loads((R/'scientific_batch_guard/TERMINAL.json').read_text())
assert final['authors_qualified']==72 and final['controls_ontime_valid']==2880 and final['controls_failed']==0 and final['authors_failed']==0
assert progress['state']=='REGISTERED_BATCH_TERMINAL'
assert outer['exit_status']==0 and outer['budget_and_cleanup_pass'] and not outer['remaining_descendants'] and outer['stop_reason'] is None
assert not (R/'scientific_batch_guard/STDERR.txt').read_text()
report={'status':'ALL_72_AUTHOR_AND_2880_CONTROL_TERMINAL_RECEIPTS_VERIFIED','as_of_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'completed_at_beijing':'2026-11-14 17:53:52','registered_maps':24,'authors_qualified':72,'controls_ontime_valid':2880,'missing_rows':0,'duplicate_terminal_events':0,'cell_count':72,'controls_per_cell':40,'arms':[{'method':k[0],'deadline_s':k[1],'rows':v} for k,v in sorted(by_arm.items())],'source_closure_files_verified':len(closure['source_files']),'source_closure_sha256':sha(R/'SOURCE_CLOSURE.json'),'raw_control_hashes_verified':2880,'all_complete_process_deadlines_pass':True,'all_row_cleanup_pass':True,'outer_driver_exit_status':0,'outer_guard_cleanup_pass':True,'source_or_method_changes':0,'new_draws':0,'new_author_solves':0,'new_control_solves':0,'training':0,'Formal':0,'scientific_G0_G3_adjudication_not_inferred':True,'audit_source_sha256':sha(Path(__file__))}
(R/'COMPLETION_RECEIPT_AUDIT.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
(R/'COMPLETION_ROW_HASHES.json').write_text(json.dumps({'authors':rows,'controls':control_rows},indent=2)+'\n')
print(json.dumps(report,sort_keys=True))
