from pathlib import Path
import hashlib,json,sys,time,socket
assert socket.gethostname()=='EXECUTION_HOST'
root=Path('/root/rivermind-data/liu_f3_g3_authorized_20261114_v1/execution_v1');sys.path.insert(0,str(root/'MODIFIED_FILE'))
from source_closure import verify
import generator_v2 as gen
closure=verify(root)
registration=json.loads((root/'REGISTRATION.json').read_text());population=json.loads((root/'POPULATION_MANIFEST.json').read_text());prior=json.loads((root/'exclusions/LATEST_EXPOSED_UNION.json').read_text())
oldraw={r['raw_sha256'] for r in prior['records']};oldgeo={r['canonical_geometry_sha256'] for r in prior['records']}
raws=set();geos=set();rows=[]
for cell in population['records']:
 if cell['status']!='generated':rows.append({'id':cell['short_id'],'status':cell['status']});continue
 file=root/'population'/cell['short_id']/'instance.txt';raw=file.read_bytes();nodes=gen.parse_instance_text(raw.decode());rh=hashlib.sha256(raw).hexdigest();gh=gen.canonical_geometry_identity(nodes)
 assert rh==cell['raw_sha256'] and gh==cell['canonical_geometry_sha256']
 assert rh not in oldraw and gh not in oldgeo and rh not in raws and gh not in geos
 assert [sum(n.kind=='site' for n in nodes),sum(n.kind=='target' for n in nodes)]==cell['family']
 raws.add(rh);geos.add(gh);rows.append({'id':cell['short_id'],'raw_sha256':rh,'canonical_geometry_sha256':gh,'status':'SAVED_FILE_AND_DUAL_DISJOINT_PASS'})
assert len(rows)==24 and len(registration['authors'])==72 and len(registration['controls'])==2880
result={'status':'REGISTERED_24_POPULATION_AND_SOURCE_READBACK_PASS','snapshot_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'generated_maps':len(raws),'unique_canonical_maps':len(geos),'prior_raw_identities':len(oldraw),'prior_canonical_identities':len(oldgeo),'raw_or_canonical_collisions':0,'registered_authors':72,'registered_controls':2880,'source_closure_files_verified':len(closure['source_files']),'rows':rows,'this_audit_only_reopened_saved_maps':True,'new_draws':0,'new_solves':0,'audit_source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(root/'POPULATION_READBACK_AUDIT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='rows'},sort_keys=True))
